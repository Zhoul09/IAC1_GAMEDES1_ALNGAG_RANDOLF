extends CharacterBody2D
class_name MilitaryUnitBase

signal died(unit: MilitaryUnitBase)
signal health_changed(hp: float, max_hp: float)
signal fired(unit: MilitaryUnitBase)

@export var def_id: String = "rifle_soldier"

enum St { HOLD, ENGAGE, REPOSITION, RELOAD, WITHDRAW, DEAD }

var def: Dictionary = {}
var max_hp: float = 100.0
var hp: float = 100.0
var damage: float = 9.0
var weapon_range: float = 190.0
var attack_interval: float = 0.45
var move_speed: float = 95.0
var accuracy_spread: float = 6.0
var burst: int = 3

var level: int = 1
var selected: bool = false
var dead: bool = false
var state: St = St.HOLD
var target: Node2D = null
var post: Vector2 = Vector2.ZERO
var facing_vec := Vector2.DOWN

var _attack_cd := 0.0
var _retarget_cd := 0.0
var _aim := 0.0
var _aim_time := 0.22
var _burst_left := 0
var _burst_cd := 0.0
var _reload := 0.0
var _recoil := 0.0
var _knock := Vector2.ZERO
var _still := 0.0
var _firing_recent := 0.0
var _reposition_cd := 0.0
var _strafe_dir := 1.0

var _path: PackedVector2Array = PackedVector2Array()
var _path_i := 0
var _has_order := false
var _wander_cd := 0.0

var _sprite: AnimatedSprite2D
var _ring: AnimatedSprite2D
var _sheet: String = "res://assets/sprites/chars/rifle_soldier.png"
var _hurt_timer: float = 0.0
var _muzzle: AnimatedSprite2D
var _anim := ""
var _hit_flash := 0.0
var _rng := RandomNumberGenerator.new()
var _face_cd := 0.0
var _stuck := 0.0
var _stuck_events := 0
var _blocked_t := 0.0
var _slide_time := 0.0
var _slide_dir := Vector2.ZERO
var _last_pos := Vector2.ZERO

@onready var world: Node2D = get_parent().get_parent() if get_parent() else null

func _ready() -> void:
	add_to_group("military")
	collision_layer = 2
	collision_mask = 1
	_rng.randomize()
	_strafe_dir = 1.0 if _rng.randf() < 0.5 else -1.0
	_apply_def()
	post = global_position
	_build_visuals()
	GameManager.register_unit(self)

func _apply_def() -> void:
	def = GameConfig.unit(def_id)
	if def.is_empty():
		push_error("Unknown unit definition: " + def_id)
		return
	max_hp = float(def.get("max_hp", 100))
	hp = max_hp
	damage = float(def.get("damage", 9))
	weapon_range = float(def.get("range", 190))
	attack_interval = float(def.get("attack_interval", 0.45))
	move_speed = float(def.get("speed", 95))
	accuracy_spread = float(def.get("accuracy_spread", 6.0))
	burst = int(def.get("burst", 3))
	_aim_time = float(def.get("aim_time", 0.22))

func _build_visuals() -> void:
	_sprite = AnimatedSprite2D.new()
	_sprite.name = "Body"
	_sheet = String(def.get("sheet", "res://assets/sprites/chars/rifle_soldier.png"))
	_sprite.sprite_frames = SpriteLib.character_frames(_sheet)
	_sprite.offset = Vector2(0, float(def.get("sprite_offset_y", -13)))
	_sprite.play("breath_down")
	add_child(_sprite)

	_ring = AnimatedSprite2D.new()
	_ring.name = "SelectionRing"
	_ring.sprite_frames = SpriteLib.sequence_frames(
			"res://assets/sprites/fx/select_ring.png", "loop", 8, 12.0, true)
	_ring.play("loop")
	_ring.visible = false
	_ring.offset = Vector2(0, 3)
	add_child(_ring)

	_muzzle = AnimatedSprite2D.new()
	_muzzle.name = "Muzzle"
	var muzzle_file := "muzzle_heavy" if String(def.get("muzzle", "rifle")) == "heavy" else "muzzle_rifle"
	_muzzle.sprite_frames = SpriteLib.sequence_frames(
			"res://assets/sprites/fx/%s.png" % muzzle_file, "fire", 10, 26.0, false)
	_muzzle.visible = false
	_muzzle.z_index = 3
	add_child(_muzzle)

	if has_node("Collision"):
		$Collision.position = Vector2(0, -6)

func _physics_process(delta: float) -> void:
	if dead or GameManager.simulation_over or GameManager.paused:
		return
	_attack_cd = maxf(0.0, _attack_cd - delta)
	_retarget_cd -= delta
	_burst_cd -= delta
	_reload = maxf(0.0, _reload - delta)
	_reposition_cd -= delta
	_hit_flash = maxf(0.0, _hit_flash - delta)
	_face_cd = maxf(0.0, _face_cd - delta)
	_firing_recent = maxf(0.0, _firing_recent - delta)
	_recoil = maxf(0.0, _recoil - delta)
	_tick_hurt(delta)
	if _hit_flash <= 0.0:
		_sprite.modulate = Color.WHITE
	if _knock.length_squared() > 1.0:
		velocity = _knock
		move_and_slide()
		_knock = _knock.lerp(Vector2.ZERO, clampf(12.0 * delta, 0.0, 1.0))
		return

	if _retarget_cd <= 0.0:
		_retarget_cd = 0.16 + _rng.randf() * 0.14
		_acquire_target()

	var busy := false
	if _target_ok(target):
		var d := global_position.distance_to(target.global_position)
		var los := _clear_shot(target)
		if d <= weapon_range and los:
			busy = true
			_face_vec(target.global_position - global_position)
			if _aim <= 0.0:
				_aim = _aim_time
			else:
				_aim -= delta
				if _aim <= 0.0 and _reload <= 0.0:
					_shoot_cycle(delta)
			if state != St.RELOAD:
				state = St.ENGAGE
			_brake(delta)
		elif d <= weapon_range * 1.55:
			if _reposition_cd <= 0.0 or _path.size() == 0 or _path_i >= _path.size():
				_reposition_cd = 1.4
				_pick_firing_spot()
			busy = true
			state = St.REPOSITION
			_follow_path(delta, 0.8)
		else:
			busy = true
			_face_vec(target.global_position - global_position)
			_chase(delta)

	if hp < max_hp * 0.28 and _target_ok(target) \
			and global_position.distance_to(target.global_position) < weapon_range * 0.55:
		state = St.WITHDRAW
		_retreat(delta)
		return

	if busy:
		return
	_aim = 0.0
	if _has_order:
		state = St.HOLD
		_follow_path(delta, 1.0)
		return
	state = St.HOLD
	_still += delta
	_brake(delta)
	if _still > 0.6:
		_idle_scan(delta)

func _idle_scan(delta: float) -> void:
	_wander_cd -= delta
	if _wander_cd > 0.0:
		return
	_wander_cd = _rng.randf_range(1.6, 3.4)
	var base := (post - global_position)
	if base.length() > 26.0:
		_face_vec(base)
		return
	_face_vec(facing_vec.rotated(_rng.randf_range(-0.9, 0.9)))

func _shoot_cycle(delta: float) -> void:
	if _burst_left <= 0:
		_burst_left = burst
	if _burst_cd > 0.0:
		return
	_fire(target)
	_burst_left -= 1
	if _burst_left > 0:
		_burst_cd = attack_interval * 0.55
	else:
		_burst_cd = attack_interval
		if _rng.randf() < 0.35:
			_reload = _rng.randf_range(0.5, 1.0)
			state = St.RELOAD
	delta = delta

func _fire(t: Node2D) -> void:
	if not _target_ok(t):
		return
	var muzzle_pos := muzzle_point()
	var aim_point: Vector2 = t.global_position + Vector2(0, -8)
	var drift := accuracy_spread * (1.0 + _recoil * 1.6) * 0.5
	var hit := aim_point + Vector2(_rng.randf_range(-drift, drift),
			_rng.randf_range(-drift, drift) * 0.6)
	GameManager.fx.tracer(muzzle_pos, hit, float(def.get("bullet_speed", 1400)),
			_muzzle_colour())
	GameManager.fx.muzzle(_muzzle, _facing_name())
	GameManager.fx.muzzle_gas(muzzle_pos, facing_vec)
	GameManager.fx.spark(hit)
	GameManager.fx.shell_casing(muzzle_pos + facing_vec.orthogonal() * 4.0)
	if _sprite:
		var kick := create_tween()
		kick.tween_property(_sprite, "position", -facing_vec * 1.5, 0.045)
		kick.tween_property(_sprite, "position", Vector2.ZERO, 0.09)
	Sfx.play(String(def.get("shot_sound", "rifle_shot")), -10.0, 0.09, global_position, 0.02)
	_recoil = minf(1.0, _recoil + 0.35)
	_firing_recent = 2.5
	fired.emit(self)
	var dmg := damage * _rng.randf_range(0.9, 1.12)
	if _rng.randf() < 0.07:
		dmg *= 0.5
	if _target_ok(t):
		t.take_damage(dmg, self)
		if t is Zombie:
			_alert_nearby()

func muzzle_point() -> Vector2:
	var anchor := SpriteLib.muzzle_offset(_sheet, _facing_name(),
			facing_vec * 13.0 + Vector2(0, -12))
	return global_position + anchor

func _muzzle_colour() -> Color:
	if String(def.get("muzzle", "rifle")) == "heavy":
		return Color(1.0, 0.72, 0.35)
	if def_id == "armored_vehicle":
		return Color(1.0, 0.82, 0.45)
	return Color(1.0, 0.9, 0.62)

func _alert_nearby() -> void:
	for n in GameManager.agents_near(global_position, 260.0):
		if n is Zombie and not n.dead:
			n.hear(global_position)

func firing_recently() -> bool:
	return _firing_recent > 0.0

func _acquire_target() -> void:
	var best: Node2D = null
	var best_score := INF
	for n in GameManager.agents_near(global_position, weapon_range * 1.15):
		if not (n is Zombie) or n.dead:
			continue
		var d: float = global_position.distance_to(n.global_position)
		if d > weapon_range * 1.15:
			continue
		if not _clear_shot(n):
			continue
		var score := d
		if n.target is Civilian:
			score *= 0.7
		elif n.target is MilitaryUnitBase:
			score *= 0.85
		if score < best_score:
			best_score = score
			best = n
	target = best

func _target_ok(t: Node2D) -> bool:
	return t != null and is_instance_valid(t) and t.get("dead") != true

func _clear_shot(t: Node2D) -> bool:
	if not GameManager.city:
		return true
	return GameManager.city.pathfinder.line_of_sight(global_position, t.global_position)

func order_move(world_pos: Vector2, own_offset: Vector2 = Vector2.ZERO) -> void:
	if dead:
		return
	var wanted: Vector2 = GameManager.city.clamp_to_world(world_pos + own_offset)
	var pf: Pathfinder = GameManager.city.pathfinder
	var dest: Vector2 = wanted
	if not pf.walkable_world(wanted):
		dest = GameManager.city.free_cell_near_world(wanted, 2)
	post = dest
	_path = pf.find_path(global_position, dest)
	_path_i = 0
	_has_order = _path.size() > 0
	_stuck = 0.0
	_last_pos = global_position
	_aim = 0.0

func _follow_path(delta: float, speed_scale: float) -> void:
	if _path_i >= _path.size():
		_has_order = false
		_brake(delta)
		return
	var wp: Vector2 = _path[_path_i]
	if global_position.distance_to(wp) < 12.0:
		_path_i += 1
		_stuck = 0.0
		return
	_move_towards(wp, delta, speed_scale)
	_check_stuck(delta)

func _unwedge(dir: Vector2) -> Vector2:
	if not test_move(global_transform, dir * 7.0):
		return dir
	var left: Vector2 = dir.orthogonal()
	for side in [left, -left]:
		if not test_move(global_transform, side * 7.0):
			return (dir * 0.45 + side).normalized()
	return dir

func _check_stuck(delta: float) -> void:
	if global_position.distance_to(_last_pos) > 5.0:
		_last_pos = global_position
		_stuck = 0.0
		return
	_stuck += delta
	if _stuck < 0.55:
		return
	_stuck_events += 1
	_stuck = 0.0
	_last_pos = global_position
	var pf: Pathfinder = GameManager.city.pathfinder
	if _stuck_events >= 2:
		_stuck_events = 0
		global_position = GameManager.city.free_spot_near(global_position, 9.0, 4)
		velocity = Vector2.ZERO
	elif not pf.walkable_world(global_position):
		global_position = GameManager.city.free_cell_near_world(global_position, 3)
	var goal: Vector2 = post if post != Vector2.ZERO else _path[_path.size() - 1]
	_path = pf.find_path(global_position, goal)
	_path_i = 0
	if _path.is_empty():
		_has_order = false

func _chase(delta: float) -> void:
	if post.distance_to(target.global_position) > weapon_range * 1.7:
		_brake(delta)
		return
	_move_towards(target.global_position, delta, 0.9)

func _retreat(delta: float) -> void:
	var away := (global_position - target.global_position).normalized()
	var dest := post + away * 40.0
	dest = GameManager.city.free_cell_near_world(dest, 3)
	_move_towards(dest, delta, 1.15)
	_face_vec(target.global_position - global_position)

func _pick_firing_spot() -> void:
	var to_t := (target.global_position - global_position).normalized()
	var side := to_t.orthogonal() * _strafe_dir
	for step in [26.0, 46.0, -26.0, -46.0]:
		var cand: Vector2 = global_position + side * step + to_t * 22.0
		cand = GameManager.city.free_cell_near_world(cand, 2)
		if GameManager.city.pathfinder.line_of_sight(cand, target.global_position):
			_path = GameManager.city.pathfinder.find_path(global_position, cand)
			_path_i = 0
			return
	_strafe_dir = -_strafe_dir

func _move_towards(dest: Vector2, delta: float, speed_scale: float) -> void:
	var to := dest - global_position
	if to.length() < 1.0:
		return
	var dir := to.normalized()
	if _slide_time > 0.0:
		_slide_time -= delta
		dir = _slide_dir
	dir = _unwedge(dir)
	var sep := _separation()
	var vel := (dir + sep * 0.8).normalized() * move_speed * speed_scale
	velocity = velocity.lerp(vel, clampf(14.0 * delta, 0.0, 1.0))
	var before := global_position
	move_and_slide()
	if global_position.distance_squared_to(before) < 0.09 and velocity.length() > 24.0:
		_blocked_t += delta
		if _blocked_t > 0.12 and _slide_time <= 0.0:
			_blocked_t = 0.0
			for side in [1.0, -1.0]:
				var tangent: Vector2 = dir.orthogonal() * side
				if not test_move(global_transform, tangent * 7.0):
					_slide_dir = tangent
					_slide_time = 0.5
					break
	else:
		_blocked_t = maxf(0.0, _blocked_t - delta)
	if velocity.length() > 4.0:
		_facing_from_velocity()
		if _aim <= 0.0:
			_set_anim("walk_" + _facing_name())
		else:
			_set_anim("action_" + _facing_name())

func _brake(delta: float) -> void:
	velocity = velocity.lerp(Vector2.ZERO, clampf(16.0 * delta, 0.0, 1.0))
	if velocity.length() > 6.0:
		move_and_slide()
	if _anim != "action_" + _facing_name() and _anim != "walk_" + _facing_name():
		pass

func _separation() -> Vector2:
	var push := Vector2.ZERO
	for other in GameManager.agents_near(global_position, 56.0):
		if other == self or not (other is MilitaryUnitBase):
			continue
		var d: Vector2 = global_position - other.global_position
		var dist := d.length()
		if dist > 0.1 and dist < 56.0:
			push += d.normalized() * (1.0 - dist / 56.0) * 1.4
	return push

func _facing_from_velocity() -> void:
	var v := velocity
	if v.length_squared() < 36.0 or _face_cd > 0.0:
		return
	if absf(v.x) > absf(v.y) * 1.35:
		facing_vec = Vector2(signf(v.x), 0)
	elif absf(v.y) > absf(v.x) * 1.35:
		facing_vec = Vector2(0, signf(v.y))
	else:
		return
	_face_cd = 0.14

func _face_vec(v: Vector2) -> void:
	if v.length_squared() < 0.01:
		return
	facing_vec = v.normalized()
	var f := _facing_name()
	if _anim != "action_" + f:
		_set_anim("action_" + f if _aim > 0.0 and _burst_left >= 0 and state == St.ENGAGE
				else "breath_" + f)

func _facing_name() -> String:
	if absf(facing_vec.x) > absf(facing_vec.y):
		return "right" if facing_vec.x > 0 else "left"
	return "down" if facing_vec.y > 0 else "up"

func _set_anim(a: String, restart: bool = false) -> void:
	if _hurt_timer > 0.0 and not a.begins_with("hurt_"):
		return
	if a == _anim and not restart:
		return
	_anim = a
	if _sprite.sprite_frames.has_animation(a):
		_sprite.play(a)

func apply_knockback(v: Vector2) -> void:
	if dead:
		return
	_knock = v
	_aim = 0.0
	_burst_left = 0
	_hit_flash = 0.1
	_sprite.modulate = Color(1.5, 1.2, 1.2)

func set_selected(on: bool) -> void:
	selected = on
	if _ring:
		_ring.visible = on
	queue_redraw()

func take_damage(amount: float, _source: Node = null) -> void:
	if dead:
		return
	hp = maxf(0.0, hp - amount)
	_hit_flash = 0.09
	_sprite.modulate = Color(1.5, 0.7, 0.7)
	_aim = 0.0
	_hurt_timer = 0.32
	_set_anim("hurt_" + _facing_name(), true)
	health_changed.emit(hp, max_hp)
	queue_redraw()
	GameManager.fx.blood_burst(global_position + Vector2(0, -12), 0.7)
	Sfx.play("hit_flesh", -14.0, 0.12, global_position, 0.05)
	if hp <= 0.0:
		_die()

func _tick_hurt(delta: float) -> void:
	if _hurt_timer <= 0.0:
		return
	_hurt_timer = maxf(0.0, _hurt_timer - delta)
	if _hurt_timer <= 0.0 and _sprite.sprite_frames.has_animation("breath_" + _facing_name()):
		_anim = ""
		_set_anim("breath_" + _facing_name(), true)

func _die() -> void:
	if dead:
		return
	dead = true
	state = St.DEAD
	velocity = Vector2.ZERO
	set_physics_process(false)
	remove_from_group("military")
	var col := get_node_or_null("Collision")
	if col:
		col.set_deferred("disabled", true)
	GameManager.fx.death_puff(global_position)
	GameManager.fx.dust(global_position)
	GameManager.fx.shake(2.2)
	GameManager.city.add_blood_decal(global_position)
	if _sprite:
		var tw := create_tween()
		tw.tween_property(_sprite, "modulate", Color(0.6, 0.5, 0.5, 0.0), 0.6)
		tw.parallel().tween_property(_sprite, "rotation_degrees", 80.0, 0.5)
		tw.parallel().tween_property(_sprite, "position", _sprite.position + Vector2(0, 4), 0.5)
	Sfx.play("hit_flesh", -5.0, 0.1, global_position)
	died.emit(self)
	GameManager.on_unit_died(self)
	await get_tree().create_timer(0.65).timeout
	queue_free()

func heal_full() -> void:
	hp = max_hp
	health_changed.emit(hp, max_hp)
	queue_redraw()

func upgrade() -> void:
	level = 2
	damage += float(def.get("upgrade_damage", 4))
	var bonus := float(def.get("upgrade_hp", 30))
	max_hp += bonus
	hp = minf(max_hp, hp + bonus)
	if def_id == "rifle_soldier":
		weapon_range += 12.0
	burst += 1
	_aim_time = maxf(0.08, _aim_time - 0.04)
	health_changed.emit(hp, max_hp)
	queue_redraw()

func repair() -> void:
	hp = max_hp
	health_changed.emit(hp, max_hp)
	queue_redraw()

func health_ratio() -> float:
	return hp / maxf(1.0, max_hp)

func _draw() -> void:
	var show := hp < max_hp - 0.01
	if not show and not selected and not GameConfig.show_health_bars:
		return
	var w := 22.0
	var h := 3.0
	var y := -34.0
	var bg := Color(0.06, 0.07, 0.09, 0.85)
	var col := Color(0.42, 0.78, 0.45) if health_ratio() > 0.55 else (
			Color(0.85, 0.72, 0.3) if health_ratio() > 0.28 else Color(0.78, 0.26, 0.24))
	draw_rect(Rect2(-w * 0.5 - 1, y - 1, w + 2, h + 2), bg)
	draw_rect(Rect2(-w * 0.5, y, w * health_ratio(), h), col)
	if level > 1:
		draw_rect(Rect2(-w * 0.5, y - 5, 4, 3), Color(0.45, 0.8, 0.9))
	if state == St.ENGAGE and _aim > 0.0:
		var tip := facing_vec * 26.0 + Vector2(0, -10)
		var l := tip + facing_vec.orthogonal() * 3.0
		var r := tip - facing_vec.orthogonal() * 3.0
		draw_line(Vector2(0, -10), l, Color(0.9, 0.55, 0.35, 0.7), 1.0)
		draw_line(Vector2(0, -10), r, Color(0.9, 0.55, 0.35, 0.7), 1.0)
