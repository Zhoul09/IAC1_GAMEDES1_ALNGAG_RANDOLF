extends RefCounted
class_name Pathfinder

const DIAG := 1.41421356

var w: int = 0
var h: int = 0
var tile: int = 32
var blocked: PackedByteArray = PackedByteArray()
var dynamic: Dictionary = {}

func setup(grid_w: int, grid_h: int, tile_px: int, blocked_grid: Array) -> void:
	w = grid_w
	h = grid_h
	tile = tile_px
	blocked.resize(w * h)
	blocked.fill(0)
	for y in min(h, blocked_grid.size()):
		var row = blocked_grid[y]
		for x in min(w, row.size()):
			if int(row[x]) != 0:
				blocked[y * w + x] = 1

func world_to_cell(p: Vector2) -> Vector2i:
	return Vector2i(int(floor(p.x / tile)), int(floor(p.y / tile)))

func cell_to_world(c: Vector2i) -> Vector2:
	return Vector2(c.x * tile + tile * 0.5, c.y * tile + tile * 0.5)

func in_bounds(c: Vector2i) -> bool:
	return c.x >= 0 and c.y >= 0 and c.x < w and c.y < h

func walkable(c: Vector2i) -> bool:
	if not in_bounds(c):
		return false
	if blocked[c.y * w + c.x] != 0:
		return false
	return not dynamic.has(c)

func walkable_world(p: Vector2) -> bool:
	return walkable(world_to_cell(p))

func set_dynamic(cell: Vector2i, on: bool) -> void:
	if not in_bounds(cell):
		return
	if on:
		dynamic[cell] = int(dynamic.get(cell, 0)) + 1
	else:
		var n := int(dynamic.get(cell, 0)) - 1
		if n <= 0:
			dynamic.erase(cell)
		else:
			dynamic[cell] = n

func nearest_walkable(cell: Vector2i, radius: int = 6) -> Vector2i:
	if walkable(cell):
		return cell
	for r in range(1, radius + 1):
		for dy in range(-r, r + 1):
			for dx in range(-r, r + 1):
				if absi(dx) != r and absi(dy) != r:
					continue
				var c := Vector2i(cell.x + dx, cell.y + dy)
				if walkable(c):
					return c
	return Vector2i(-1, -1)

func nearest_walkable_world(p: Vector2, radius: int = 6) -> Vector2:
	var c := nearest_walkable(world_to_cell(p), radius)
	if c.x < 0:
		return p
	return cell_to_world(c)

func cell_cost(c: Vector2i) -> float:
	return 1.0

func line_of_sight(a: Vector2, b: Vector2, ignore_goal: bool = true) -> bool:
	var steps := int(maxf(1.0, a.distance_to(b) / (tile * 0.35)))
	var goal := world_to_cell(b)
	for i in range(steps + 1):
		var t := float(i) / float(steps)
		var p := a.lerp(b, t)
		var c := world_to_cell(p)
		if not walkable(c):
			if ignore_goal and c == goal:
				continue
			return false
	return true

func find_path(start_world: Vector2, goal_world: Vector2, max_nodes: int = 3500) -> PackedVector2Array:
	var start_c := nearest_walkable(world_to_cell(start_world), 4)
	var goal_c := nearest_walkable(world_to_cell(goal_world), 8)
	var out := PackedVector2Array()
	if start_c.x < 0 or goal_c.x < 0:
		return out
	if start_c == goal_c:
		out.append(cell_to_world(goal_c))
		return out
	if line_of_sight(start_world, cell_to_world(goal_c), false):
		out.append(cell_to_world(goal_c))
		return out

	var start_i := start_c.y * w + start_c.x
	var goal_i := goal_c.y * w + goal_c.x
	var g := {start_i: 0.0}
	var f := {start_i: _heuristic(start_c, goal_c)}
	var came := {}
	var open := _Heap.new()
	open.push(start_i, f[start_i])
	var closed := {}
	var expanded := 0
	while open.size() > 0 and expanded < max_nodes:
		var cur: int = open.pop_min()
		if closed.has(cur):
			continue
		closed[cur] = true
		expanded += 1
		if cur == goal_i:
			return _reconstruct(came, cur, goal_c, start_world)
		var cx := cur % w
		var cy := cur / w
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1),
				Vector2i(1, 1), Vector2i(1, -1), Vector2i(-1, 1), Vector2i(-1, -1)]:
			var nc := Vector2i(cx + d.x, cy + d.y)
			if not walkable(nc):
				continue
			if d.x != 0 and d.y != 0:
				if not walkable(Vector2i(cx + d.x, cy)) or not walkable(Vector2i(cx, cy + d.y)):
					continue
			var ni := nc.y * w + nc.x
			if closed.has(ni):
				continue
			var step := DIAG if (d.x != 0 and d.y != 0) else 1.0
			var ng: float = g[cur] + step * cell_cost(nc)
			if not g.has(ni) or ng < g[ni]:
				g[ni] = ng
				f[ni] = ng + _heuristic(nc, goal_c)
				came[ni] = cur
				open.push(ni, f[ni])
	if expanded >= max_nodes:
		return PackedVector2Array()
	return out

func _heuristic(a: Vector2i, b: Vector2i) -> float:
	var dx := absi(a.x - b.x)
	var dy := absi(a.y - b.y)
	return float(maxi(dx, dy)) + (DIAG - 1.0) * float(mini(dx, dy))

func _reconstruct(came: Dictionary, cur: int, goal_c: Vector2i,
		start_world: Vector2) -> PackedVector2Array:
	var cells: Array[Vector2i] = []
	var node := cur
	while came.has(node):
		cells.push_front(Vector2i(node % w, node / w))
		node = came[node]
	if cells.is_empty():
		cells.append(goal_c)
	var pts := PackedVector2Array()
	var anchor := start_world
	var i := 0
	while i < cells.size():
		var j := cells.size() - 1
		var found := -1
		while j > i:
			if line_of_sight(anchor, cell_to_world(cells[j]), true):
				found = j
				break
			j -= 1
		if found == -1:
			found = i
		pts.append(cell_to_world(cells[found]))
		anchor = cell_to_world(cells[found])
		i = found + 1
	if pts.is_empty():
		pts.append(cell_to_world(goal_c))
	return pts

class _Heap:
	var items: Array = []

	func size() -> int:
		return items.size()

	func push(value: int, priority: float) -> void:
		items.append([priority, value])
		var i := items.size() - 1
		while i > 0:
			var parent := (i - 1) / 2
			if items[i][0] < items[parent][0]:
				var tmp = items[i]
				items[i] = items[parent]
				items[parent] = tmp
				i = parent
			else:
				break

	func pop_min() -> int:
		var top = items[0]
		var last = items.pop_back()
		if items.size() > 0:
			items[0] = last
			var i := 0
			var n := items.size()
			while true:
				var l := i * 2 + 1
				var r := l + 1
				var smallest := i
				if l < n and items[l][0] < items[smallest][0]:
					smallest = l
				if r < n and items[r][0] < items[smallest][0]:
					smallest = r
				if smallest == i:
					break
				var tmp = items[i]
				items[i] = items[smallest]
				items[smallest] = tmp
				i = smallest
		return top[1]
