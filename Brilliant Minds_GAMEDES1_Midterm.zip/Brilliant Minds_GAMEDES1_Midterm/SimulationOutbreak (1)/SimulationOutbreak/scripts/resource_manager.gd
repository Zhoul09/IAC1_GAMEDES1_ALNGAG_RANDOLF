extends Node
class_name ResourceManager

signal gold_changed(gold: int, delta: int)
signal purchase_failed(reason: String)
signal purchase_succeeded(kind: String, id: String, cost: int)

var gold: int = 100
var total_earned: int = 0
var total_spent: int = 0

func reset() -> void:
	gold = int(GameConfig.eco("initial_gold", 100.0))
	total_earned = 0
	total_spent = 0
	gold_changed.emit(gold, 0)

func can_afford(cost: int) -> bool:
	return gold >= cost

func add_gold(amount: int, _reason: String = "") -> void:
	if amount == 0:
		return
	gold = maxi(0, gold + amount)
	total_earned += maxi(0, amount)
	gold_changed.emit(gold, amount)

func kill_reward() -> int:
	return int(GameConfig.eco("zombie_kill_reward", 5.0))

func spend(cost: int, kind: String, id: String) -> bool:
	if cost > gold:
		purchase_failed.emit("NEED %d MORE GOLD" % (cost - gold))
		return false
	gold -= cost
	total_spent += cost
	gold_changed.emit(gold, -cost)
	purchase_succeeded.emit(kind, id, cost)
	return true

func unit_cost(id: String) -> int:
	return int(GameConfig.unit(id).get("cost", 50))

func defense_cost(id: String) -> int:
	return int(GameConfig.defense(id).get("cost", 100))

func upgrade_cost() -> int:
	return int(GameConfig.eco("upgrade_cost", 75.0))

func repair_cost(ratio: float) -> int:
	var base: float = float(GameConfig.eco("repair_cost_ratio", 0.4))
	return maxi(10, int(round(75.0 * base * (1.0 - ratio) * 2.0)))
