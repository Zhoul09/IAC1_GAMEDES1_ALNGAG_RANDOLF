extends StaticBody2D
class_name DefenseStructure

signal destroyed(structure: DefenseStructure)
signal health_changed(hp: float, max_hp: float)

var def_id: String = "barricade"
var def: Dictionary = {}
var max_hp: float = 320.0
var hp: float = 320.0
var damage: float = 0.0
var weapon_range: float = 0.0
var attack_interval: float = 0.0
var level: int = 1
var dead: bool = false
var selected: bool = false

var _sprite: Sprite2D
var _gun: Node2D
var _attack_cd: float = 0.0
var _blocked_cells: Array[Vector2i] = []
var _hit_flash: float = 0.0
var _ring: AnimatedSprite2D
var _muzzle: AnimatedSprite2D
var _target: Node2D = null
var _retarget := 0.0

func setup(id: String) -> void:
	def_id = id
	def = GameConfig.defense(id)

func _ready() -> void:
	add_to_group("defenses")
	collision_layer = 16
	collision_mask = 0
	if def.is_empty():
		def = GameConfig.defense(def_id)
	max_hp = float(def.get("max_hp", 320))
	hp = max_hp
	damage = float(def.get("damage", 0))
	weapon_range = float(def.get("range", 0))
	attack_interval = float(def.get("attack_interval", 0))
	_settle_on_open_ground()
	_build_visuals()
	_block_cells()
	GameManager.register_defense(self)

func _settle_on_open_ground() -> void:
	if GameManager.city == null:
		return
	var pf: Pathfinder = GameManager.city.pathfinder
	var cell: Vector2i = pf.world_to_cell(global_position)
	if pf.walkable(cell):
		return
	var alt: Vector2i = pf.nearest_walkable(cell, 3)
	if alt.x >= 0:
		global_position = pf.cell_to_world(alt)

func _build_visuals() -> void:
	_sprite = Sprite2D.new()
	_sprite.texture = SpriteLib.texture(String(def.get("sprite",
			"res://assets/sprites/props/sandbag_wall.png")))
	_sprite.offset = Vector2(0, -_sprite.texture.get_height() * 0.5 + 8)
	add_child(_sprite)

	if float(def.get("damage", 0)) > 0.0:
		var turret_path := String(def.get("turret_sprite", ""))
		if turret_path != "":
			var gun_tex := SpriteLib.texture(turret_path)
			if gun_tex:
				_gun = Sprite2D.new()
				_gun.texture = gun_tex
				_gun.offset = Vector2(0, -gun_tex.get_height() * 0.5 - 4)
				add_child(_gun)
		_muzzle = AnimatedSprite2D.new()
		_muzzle.sprite_frames = SpriteLib.sequence_frames(
				"res://assets/sprites/fx/muzzle_heavy.png", "fire", 10, 26.0, false)
		_muzzle.visible = false
		_muzzle.z_index = 3
		add_child(_muzzle)

	_ring = AnimatedSprite2D.new()
	_ring.sprite_frames = SpriteLib.sequence_frames(
			"res://assets/sprites/fx/select_ring.png", "loop", 8, 12.0, true)
	_ring.play("loop")
	_ring.visible = false
	_ring.offset = Vector2(0, 4)
	add_child(_ring)

	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = Vector2(38, 22) if def_id == "barricade" else Vector2(30, 22)
	shape.shape = rect
	shape.position = Vector2(0, -8)
	add_child(shape)

func _block_cells() -> void:
	var pf: Pathfinder = GameManager.city.pathfinder
	var base := pf.world_to_cell(global_position)
	var cells := [base]
	for c in cells:
		if pf.in_bounds(c):
			pf.set_dynamic(c, true)
			_blocked_cells.append(c)

func _physics_process(delta: float) -> void:
	if dead or GameManager.simulation_over or GameManager.paused:
		return
	_hit_flash = maxf(0.0, _hit_flash - delta)
	if _hit_flash <= 0.0 and _sprite:
		_sprite.modulate = Color.WHITE
	if damage <= 0.0:
		return
	_attack_cd = maxf(0.0, _attack_cd - delta)
	_retarget -= delta
	if _retarget <= 0.0:
		_retarget = 0.25
		_select_target()
	if _target != null and is_instance_valid(_target) and not _target.dead:
		if global_position.distance_to(_target.global_position) <= weapon_range:
			_aim(_target.global_position)
			if _attack_cd <= 0.0:
				_attack_cd = attack_interval
				_fire(_target)
			return
	_target = null

func _select_target() -> void:
	var best: Node2D = null
	var best_d := INF
	for z in GameManager.zombies:
		if z == null or not is_instance_valid(z) or z.dead:
			continue
		var d: float = global_position.distance_to(z.global_position)
		if d <= weapon_range and d < best_d:
			best = z
			best_d = d
	_target = best

func _aim(p: Vector2) -> void:
	var ang := (p - (global_position + Vector2(0, -18))).angle()
	if _gun != null:
		_gun.rotation = ang + PI * 0.5
	if _muzzle:
		_muzzle.position = Vector2(0, -22) + Vector2(cos(ang), sin(ang)) * 20.0
		_muzzle.rotation = ang

func _fire(t: Node2D) -> void:
	if t == null or not is_instance_valid(t):
		return
	var from: Vector2 = global_position + Vector2(0, -22)
	var to: Vector2 = t.global_position + Vector2(0, -8)
	GameManager.fx.tracer(from, to, 1300.0)
	if _muzzle:
		_muzzle.visible = true
		_muzzle.play("fire")
		GameManager.fx.register_muzzle_auto_hide(_muzzle)
	Sfx.play("turret_shot", -11.0, 0.1, global_position, 0.03)
	if is_instance_valid(t) and not t.dead:
		t.take_damage(damage * randf_range(0.9, 1.1), self)

func take_damage(amount: float, _source: Node = null) -> void:
	if dead:
		return
	hp = maxf(0.0, hp - amount)
	_hit_flash = 0.1
	if _sprite:
		_sprite.modulate = Color(1.5, 1.2, 1.0)
	health_changed.emit(hp, max_hp)
	queue_redraw()
	Sfx.play("structure_hit", -12.0, 0.12, global_position, 0.08)
	GameManager.fx.impact_lite(global_position + Vector2(0, -10))
	if hp <= 0.0:
		_destroy()

func _destroy() -> void:
	if dead:
		return
	dead = true
	set_physics_process(false)
	remove_from_group("defenses")
	for c in _blocked_cells:
		GameManager.city.pathfinder.set_dynamic(c, false)
	_blocked_cells.clear()
	var col := get_child_count()
	for child in get_children():
		if child is CollisionShape2D:
			child.set_deferred("disabled", true)
	GameManager.fx.explosion(global_position + Vector2(0, -10))
	Sfx.play("structure_break", -6.0, 0.08, global_position)
	GameManager.city.add_blood_decal(global_position)
	destroyed.emit(self)
	GameManager.on_defense_destroyed(self)
	if _sprite:
		var tw := create_tween()
		tw.tween_property(_sprite, "modulate", Color(0.3, 0.28, 0.26, 0.0), 0.8)
		tw.parallel().tween_property(_sprite, "position", _sprite.position + Vector2(0, 6), 0.8)
	await get_tree().create_timer(0.85).timeout
	queue_free()

func set_selected(on: bool) -> void:
	selected = on
	if _ring:
		_ring.visible = on
	queue_redraw()

func upgrade() -> void:
	level = 2
	var bonus := float(def.get("upgrade_hp", 150))
	max_hp += bonus
	hp = minf(max_hp, hp + bonus)
	if damage > 0.0:
		damage += float(def.get("upgrade_damage", 5))
		weapon_range += 15.0
	health_changed.emit(hp, max_hp)
	queue_redraw()

func repair() -> void:
	hp = max_hp
	health_changed.emit(hp, max_hp)
	queue_redraw()

func health_ratio() -> float:
	return hp / maxf(1.0, max_hp)

func _draw() -> void:
	if hp >= max_hp - 0.01 and not selected and not GameConfig.show_health_bars:
		return
	var w := 34.0
	var y := -30.0
	draw_rect(Rect2(-w * 0.5 - 1, y - 1, w + 2, 5), Color(0.06, 0.07, 0.09, 0.85))
	var col := Color(0.45, 0.75, 0.85) if health_ratio() > 0.5 else Color(0.8, 0.45, 0.3)
	draw_rect(Rect2(-w * 0.5, y, w * health_ratio(), 3), col)
