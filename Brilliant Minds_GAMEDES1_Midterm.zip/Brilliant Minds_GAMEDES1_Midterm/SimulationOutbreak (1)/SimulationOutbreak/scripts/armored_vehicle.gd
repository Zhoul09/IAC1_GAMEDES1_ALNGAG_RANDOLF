extends MilitaryUnitBase

func _ready() -> void:
	def_id = "armored_vehicle"
	super._ready()
