extends Node2D
class_name Weather

const RAIN_TEX := "res://assets/sprites/fx/rain.png"

var rain: CPUParticles2D
var _enabled := true

func setup(_camera: CameraController) -> void:
	name = "Weather"
	z_index = 60
	rain = CPUParticles2D.new()
	rain.name = "Rain"
	rain.texture = SpriteLib.texture(RAIN_TEX)
	rain.amount = int(GameConfig.balance_setting("atmosphere", "rain_particles", 180))
	rain.lifetime = 1.3
	rain.preprocess = 1.2
	rain.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	rain.emission_rect_extents = Vector2(900, 60)
	rain.direction = Vector2(-0.22, 1.0)
	rain.spread = 2.5
	rain.gravity = Vector2(-60, 1200)
	rain.initial_velocity_min = 360.0
	rain.initial_velocity_max = 560.0
	rain.scale_amount_min = 0.7
	rain.scale_amount_max = 1.3
	rain.color = Color(0.62, 0.72, 0.88, 0.30)
	rain.position = Vector2(0, -300)
	add_child(rain)

func _process(_delta: float) -> void:
	if not _enabled or rain == null:
		return
	var cam: CameraController = GameManager.camera
	if cam == null:
		return
	var view := get_viewport_rect().size / maxf(0.2, cam.zoom.x)
	rain.position = cam.global_position + Vector2(0, -view.y * 0.62)
	rain.emission_rect_extents = Vector2(view.x * 0.75, 40.0)
