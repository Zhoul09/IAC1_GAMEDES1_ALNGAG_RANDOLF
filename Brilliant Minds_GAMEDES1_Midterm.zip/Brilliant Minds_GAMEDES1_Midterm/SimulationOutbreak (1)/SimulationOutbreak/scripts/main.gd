extends Node2D

const CIVILIAN_SCENE := "res://scenes/units/Civilian.tscn"

var world: Node2D
var obstacles: Node2D
var city: CityMap
var effects: Effects
var camera: CameraController
var ui_layer: CanvasLayer
var hud: Hud
var pause_menu: PauseMenu
var game_over_screen: GameOverScreen
var input_controller: InputController
var night: NightLighting
var weather: Weather

func _ready() -> void:
	randomize()
	_build_world()
	_build_camera()
	_build_ui()
	GameManager.start_session(self, city, world, effects, camera, hud)
	_spawn_civilians()
	_connect_ui()
	Sfx.listening = true
	Sfx.play_music("music_loop")
	Sfx.play_ambience("ambience")
	GameManager.begin_play()

func _build_world() -> void:
	world = Node2D.new()
	world.name = "World"
	world.y_sort_enabled = true
	add_child(world)

	city = CityMap.new()
	city.name = "CityMap"
	add_child(city)

	obstacles = Node2D.new()
	obstacles.name = "Obstacles"
	add_child(obstacles)

	city.build(world, obstacles)

	night = NightLighting.new()
	add_child(night)
	night.setup(world, city)

	effects = Effects.new()
	effects.name = "Effects"
	add_child(effects)

	weather = Weather.new()
	add_child(weather)
	weather.setup(null)

func _build_camera() -> void:
	camera = CameraController.new()
	camera.name = "Camera2D"
	add_child(camera)
	camera.setup(city.world_size, city.player_start + Vector2(0, -40))
	camera.make_current()

	input_controller = InputController.new()
	input_controller.name = "InputController"
	add_child(input_controller)
	input_controller.setup(city, camera, world)

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	ui_layer.name = "UI"
	ui_layer.layer = 10
	add_child(ui_layer)

	hud = preload("res://scenes/ui/HUD.tscn").instantiate()
	ui_layer.add_child(hud)

	pause_menu = preload("res://scenes/ui/PauseMenu.tscn").instantiate()
	ui_layer.add_child(pause_menu)

	game_over_screen = preload("res://scenes/ui/GameOverScreen.tscn").instantiate()
	ui_layer.add_child(game_over_screen)

func _connect_ui() -> void:
	hud.deploy_requested.connect(_on_deploy_requested)
	hud.pause_requested.connect(func(): GameManager.toggle_pause())
	hud.speed_requested.connect(func(): GameManager.cycle_speed())
	GameManager.selection_validity_changed.connect(func(valid, reason):
		if input_controller.deploy_kind != "":
			hud.set_selection_hint("" if valid else reason))
	GameManager.game_over.connect(func(_s):
		GameManager.set_paused(false))

func _on_deploy_requested(kind: String, id: String) -> void:
	if GameManager.simulation_over or GameManager.paused:
		return
	input_controller.begin_deploy(kind, id)

func _spawn_civilians() -> void:
	var scene: PackedScene = load(CIVILIAN_SCENE)
	if scene == null:
		push_error("Civilian scene missing")
		return
	for data in GameConfig.city.get("civilians", []):
		var c: Civilian = scene.instantiate()
		c.position = Vector2(float(data["x"]), float(data["y"]))
		c.group_id = String(data["group"])
		c.variant = int(data.get("variant", 0))
		world.add_child(c)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause_game"):
		if not GameManager.simulation_over:
			GameManager.toggle_pause()
			get_viewport().set_input_as_handled()
	elif event.is_action_pressed("select_all"):
		GameManager.select_all_units()
	elif event.is_action_pressed("speed_toggle"):
		GameManager.cycle_speed()
