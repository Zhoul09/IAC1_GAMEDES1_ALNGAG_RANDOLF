extends Control
class_name Hud

signal deploy_requested(kind: String, id: String)
signal pause_requested
signal speed_requested

var theme_res: Theme

var _gold_label: Label
var _wave_label: Label
var _civ_label: Label
var _mil_label: Label
var _zombie_label: Label
var _status_label: Label
var _banner: PanelContainer
var _banner_label: Label
var _banner_timer: Timer
var _wave_panel: PanelContainer
var _wave_info: Label
var _wave_button: Button
var _speed_button: Button
var _notify_box: VBoxContainer
var _deploy_panel: DeploymentPanel
var _unit_panel: UnitPanel
var _threats: Control
var _warning_positions: Array = []
var _warning_edges: Array = []
var _civ_alert_cd := 0.0
var _district_names := {"C1": "C1 RESIDENTIAL", "C2": "C2 COMMERCIAL", "C3": "C3 OUTER"}

var _gold_flash := 0.0
var _site_rows: Dictionary = {}
var _base_bar: ProgressBar
var _base_panel: PanelContainer

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	theme_res = UiTheme.build()
	theme = theme_res
	_build_vignette()
	_build()
	_pass_through_input(self)
	_connect_signals()
	_refresh()

func _build_site_panel() -> void:
	var panel := PanelContainer.new()
	panel.theme_type_variation = "HudPanel"
	panel.set_anchors_preset(Control.PRESET_TOP_LEFT)
	panel.offset_left = 10
	panel.offset_top = 46
	panel.offset_right = 250
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 3)
	panel.add_child(box)

	box.add_child(UiTheme.make_label("SITES TO HOLD", UiTheme.C_ACCENT, 8))

	var base_row := HBoxContainer.new()
	base_row.add_theme_constant_override("separation", 6)
	box.add_child(base_row)
	base_row.add_child(UiTheme.make_label("POST", UiTheme.C_DIM, 8))
	_base_bar = ProgressBar.new()
	_base_bar.custom_minimum_size = Vector2(150, 8)
	_base_bar.show_percentage = false
	_base_bar.max_value = 100.0
	_base_bar.value = 100.0
	base_row.add_child(_base_bar)

	for id in ["BASE", "SHELTER_A", "SHELTER_B"]:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		box.add_child(row)
		var nm := UiTheme.make_label("--", UiTheme.C_TEXT, 8)
		nm.custom_minimum_size = Vector2(96, 0)
		row.add_child(nm)
		var civ := UiTheme.make_label("0", UiTheme.C_TEXT, 8)
		civ.custom_minimum_size = Vector2(34, 0)
		civ.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(civ)
		var bar := ProgressBar.new()
		bar.custom_minimum_size = Vector2(64, 8)
		bar.show_percentage = false
		bar.max_value = 12.0
		bar.value = 0.0
		row.add_child(bar)
		_site_rows[id] = {"panel": panel, "name": nm, "civ": civ, "bar": bar}

func _on_site_changed(site_id: String, threat: int, civilians: int) -> void:
	var row: Dictionary = _site_rows.get(site_id, {})
	if row.is_empty():
		return
	var entry: Dictionary = GameManager.site_status.get(site_id, {})
	var label := String(entry.get("name", site_id))
	if site_id == "BASE":
		label = "COMMAND"
	elif site_id == "SHELTER_A":
		label = "SHELTER A"
	elif site_id == "SHELTER_B":
		label = "SHELTER B"
	(row["name"] as Label).text = label
	(row["civ"] as Label).text = str(civilians)
	var bar: ProgressBar = row["bar"]
	bar.max_value = 12.0
	bar.value = float(threat)
	var hot := threat >= 2
	(row["name"] as Label).add_theme_color_override("font_color",
			UiTheme.C_DANGER if hot else (UiTheme.C_WARN if threat == 1 else UiTheme.C_TEXT))
	(row["civ"] as Label).add_theme_color_override("font_color",
			UiTheme.C_DANGER if civilians <= 3 else UiTheme.C_TEXT)

func _on_base_integrity(value: float) -> void:
	if _base_bar == null:
		return
	_base_bar.value = value
	var ratio := value / 100.0
	var col := Color(0.42, 0.78, 0.45) if ratio > 0.6 else (
			Color(0.85, 0.72, 0.3) if ratio > 0.3 else Color(0.78, 0.26, 0.24))
	var fill := StyleBoxFlat.new()
	fill.bg_color = col
	fill.set_corner_radius_all(2)
	_base_bar.add_theme_stylebox_override("fill", fill)

func _build_vignette() -> void:
	var tint := ColorRect.new()
	tint.name = "NightWash"
	tint.color = Color(0.05, 0.09, 0.18, 0.10)
	tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(tint)
	var vig := TextureRect.new()
	vig.name = "Vignette"
	vig.texture = SpriteLib.texture("res://assets/sprites/fx/vignette.png")
	vig.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vig.stretch_mode = TextureRect.STRETCH_SCALE
	vig.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vig.modulate = Color(1, 1, 1, 0.75)
	vig.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vig)

func _connect_signals() -> void:
	GameManager.stats_updated.connect(_refresh)
	GameManager.selection_changed.connect(_on_selection_changed)
	GameManager.feedback.connect(_on_feedback)
	GameManager.game_over.connect(_on_game_over)
	GameManager.speed_changed.connect(_on_speed_changed)
	GameManager.gold.gold_changed.connect(_on_gold_changed)
	GameManager.waves.intermission_tick.connect(_on_intermission)
	GameManager.waves.wave_progress.connect(_on_wave_progress)
	GameManager.waves.wave_warning.connect(_on_wave_warning)
	GameManager.waves.wave_started.connect(_on_wave_started)
	GameManager.waves.wave_completed.connect(_on_wave_completed)
	GameManager.civilian_killed.connect(_on_civilian_killed)
	GameManager.site_threat_changed.connect(_on_site_changed)
	GameManager.base_integrity_changed.connect(_on_base_integrity)

func _build() -> void:
	var top := PanelContainer.new()
	top.theme_type_variation = "HudPanel"
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(top)
	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 18)
	top.add_child(bar)

	var gold_box := _stat_box("res://assets/sprites/ui/icon_gold.png", "GOLD")
	_gold_label = gold_box[1]
	bar.add_child(gold_box[0])
	bar.add_child(_vsep())
	var wave_box := _stat_box("res://assets/sprites/ui/icon_wave.png", "WAVE")
	_wave_label = wave_box[1]
	bar.add_child(wave_box[0])
	bar.add_child(_vsep())
	var civ_box := _stat_box("res://assets/sprites/ui/icon_civilian.png", "CIVILIANS")
	_civ_label = civ_box[1]
	bar.add_child(civ_box[0])
	bar.add_child(_vsep())
	var mil_box := _stat_box("res://assets/sprites/ui/icon_military.png", "MILITARY")
	_mil_label = mil_box[1]
	bar.add_child(mil_box[0])
	bar.add_child(_vsep())
	var z_box := _stat_box("res://assets/sprites/ui/icon_zombie.png", "INFECTED")
	_zombie_label = z_box[1]
	bar.add_child(z_box[0])

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bar.add_child(spacer)

	_status_label = UiTheme.make_label("STANDBY", UiTheme.C_DIM, 16)
	bar.add_child(_status_label)

	_speed_button = UiTheme.make_button("1X", "SmallButton")
	_speed_button.tooltip_text = "Simulation speed (T)"
	_speed_button.pressed.connect(func(): speed_requested.emit())
	bar.add_child(_speed_button)

	var pause_button := UiTheme.make_button("II", "SmallButton")
	pause_button.tooltip_text = "Pause (Space)"
	pause_button.pressed.connect(func(): pause_requested.emit())
	bar.add_child(pause_button)

	_build_site_panel()

	_banner = PanelContainer.new()
	_banner.theme_type_variation = "HudPanel"
	_banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_banner.offset_left = -230
	_banner.offset_right = 230
	_banner.offset_top = 54
	_banner.offset_bottom = 96
	_banner.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_banner.visible = false
	_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_banner)
	_banner_label = UiTheme.make_label("INCOMING", UiTheme.C_WARN, 16)
	_banner_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_banner.add_child(_banner_label)
	_banner_timer = Timer.new()
	_banner_timer.one_shot = true
	_banner_timer.wait_time = 3.0
	_banner_timer.timeout.connect(func(): _banner.visible = false)
	add_child(_banner_timer)

	_notify_box = VBoxContainer.new()
	_notify_box.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_notify_box.offset_left = -352
	_notify_box.offset_right = -12
	_notify_box.offset_top = 54
	_notify_box.offset_bottom = 320
	_notify_box.custom_minimum_size = Vector2(340, 0)
	_notify_box.alignment = BoxContainer.ALIGNMENT_BEGIN
	_notify_box.add_theme_constant_override("separation", 4)
	_notify_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_notify_box)

	_wave_panel = PanelContainer.new()
	_wave_panel.theme_type_variation = "HudPanel"
	_wave_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_wave_panel.offset_left = -170
	_wave_panel.offset_right = 170
	_wave_panel.offset_top = 104
	_wave_panel.offset_bottom = 156
	_wave_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_wave_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_wave_panel.custom_minimum_size = Vector2(300, 0)
	_wave_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_wave_panel)
	var wv := VBoxContainer.new()
	wv.alignment = BoxContainer.ALIGNMENT_CENTER
	wv.add_theme_constant_override("separation", 4)
	_wave_panel.add_child(wv)
	_wave_info = UiTheme.make_label("", UiTheme.C_TEXT, 16)
	_wave_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	wv.add_child(_wave_info)
	_wave_button = UiTheme.make_button("START NEXT WAVE", "AccentButton")
	_wave_button.pressed.connect(func(): GameManager.waves.start_next_wave_now())
	wv.add_child(_wave_button)

	var bottom := Control.new()
	bottom.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	bottom.offset_left = 10
	bottom.offset_right = -10
	bottom.offset_top = -162
	bottom.offset_bottom = -8
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bottom)
	var strip := HBoxContainer.new()
	strip.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	strip.add_theme_constant_override("separation", 10)
	strip.alignment = BoxContainer.ALIGNMENT_BEGIN
	strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_child(strip)

	_threats = preload("res://scripts/ui/threat_markers.gd").new()
	_threats.name = "ThreatMarkers"
	add_child(_threats)

	_deploy_panel = preload("res://scenes/ui/DeploymentPanel.tscn").instantiate()
	_deploy_panel.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_deploy_panel.size_flags_vertical = Control.SIZE_SHRINK_END
	strip.add_child(_deploy_panel)
	_deploy_panel.deploy_selected.connect(func(kind, id): deploy_requested.emit(kind, id))

	var gap := Control.new()
	gap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	strip.add_child(gap)

	_unit_panel = preload("res://scenes/ui/UnitPanel.tscn").instantiate()
	_unit_panel.size_flags_horizontal = Control.SIZE_SHRINK_END
	_unit_panel.size_flags_vertical = Control.SIZE_SHRINK_END
	strip.add_child(_unit_panel)

func _pass_through_input(node: Node) -> void:
	for child in node.get_children():
		if child is BaseButton or child is Slider or child is LineEdit \
				or child is OptionButton or child is TabBar or child is ItemList:
			pass
		elif child is Control:
			(child as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
		_pass_through_input(child)

func deploy_panel_ref() -> Control:
	return _deploy_panel

func unit_panel_ref() -> Control:
	return _unit_panel

func _vsep() -> Control:
	var c := ColorRect.new()
	c.color = Color(0.65, 0.7, 0.72, 0.22)
	c.custom_minimum_size = Vector2(1, 22)
	c.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	return c

func _stat_box(icon_path: String, caption: String) -> Array:
	var box := HBoxContainer.new()
	box.add_theme_constant_override("separation", 5)
	box.add_child(UiTheme.make_icon(icon_path, Vector2(20, 20)))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", -4)
	box.add_child(v)
	var cap := UiTheme.make_label(caption, UiTheme.C_DIM, 8)
	v.add_child(cap)
	var val := UiTheme.make_label("0", UiTheme.C_TEXT, 16)
	v.add_child(val)
	return [box, val]

func _refresh() -> void:
	if GameManager.gold == null:
		return
	_gold_label.text = str(GameManager.gold.gold)
	_civ_label.text = "%d/%d" % [GameManager.population.remaining, GameManager.population.initial]
	var ratio := GameManager.population.survival_ratio()
	_civ_label.add_theme_color_override("font_color",
			UiTheme.C_TEXT if ratio > 0.6 else (UiTheme.C_WARN if ratio > 0.3 else UiTheme.C_DANGER))
	_mil_label.text = "%d" % GameManager.units.size()
	_zombie_label.text = "%d" % GameManager.zombies.size()
	_wave_label.text = "%d" % maxi(1, GameManager.waves.wave)
	_status_label.text = GameManager.waves.state_name()
	_deploy_panel.refresh()
	_unit_panel.refresh()

func _on_gold_changed(_gold: int, delta: int) -> void:
	_refresh()
	if delta != 0:
		_gold_label.add_theme_color_override("font_color",
				UiTheme.C_OK if delta > 0 else UiTheme.C_DANGER)
		var tw := create_tween()
		tw.tween_interval(0.35)
		tw.tween_callback(func():
			_gold_label.add_theme_color_override("font_color", UiTheme.C_TEXT))

func _on_selection_changed() -> void:
	_unit_panel.refresh()

func _on_speed_changed(scale: float) -> void:
	_speed_button.text = "%dX" % int(scale)

func _on_intermission(seconds_left: float, wave_next: int) -> void:
	if GameManager.waves.state != WaveManager.State.INTERMISSION:
		return
	_wave_panel.visible = true
	_wave_button.visible = true
	_wave_info.text = "NEXT WAVE %d IN %ds" % [wave_next, int(ceil(seconds_left))]
	_wave_info.add_theme_color_override("font_color", UiTheme.C_GOLD)

func _on_wave_started(wave: int, edges: Array) -> void:
	_wave_panel.visible = true
	_wave_button.visible = false
	_wave_info.text = "WAVE %d  -  %s" % [wave, _edges_text(edges)]
	_wave_info.add_theme_color_override("font_color", UiTheme.C_DANGER)

func _on_wave_progress(wave: int, alive: int, total: int) -> void:
	if GameManager.waves.state == WaveManager.State.INTERMISSION:
		return
	_wave_panel.visible = true
	_wave_button.visible = false
	_wave_info.text = "WAVE %d  -  %d/%d INFECTED" % [wave, alive, total]
	_wave_info.add_theme_color_override("font_color", UiTheme.C_TEXT)

func _on_wave_completed(wave: int, reward: int) -> void:
	_wave_info.text = "WAVE %d CLEARED  +%d GOLD" % [wave, reward]
	_wave_info.add_theme_color_override("font_color", UiTheme.C_OK)

func _on_wave_warning(wave: int, edges: Array, positions: Array, _seconds: float) -> void:
	_show_banner("INCOMING WAVE %d  -  %s" % [wave, _edges_text(edges)], UiTheme.C_WARN, 3.4)
	_warning_positions = positions.duplicate()
	_warning_edges = edges.duplicate()
	_update_threats()

func _on_civilian_killed(civilian: Civilian) -> void:
	if _civ_alert_cd > 0.0:
		return
	_civ_alert_cd = 1.6
	var gid: String = civilian.group_id if is_instance_valid(civilian) else ""
	if _district_names.has(gid):
		_show_banner("CIVILIANS LOST IN %s" % _district_names[gid], UiTheme.C_DANGER, 2.2)

func _update_threats() -> void:
	if _threats == null:
		return
	var list: Array = []
	var state: int = GameManager.waves.state
	if state == WaveManager.State.WARNING:
		for i in _warning_positions.size():
			var edge: String = String(_warning_edges[i % maxi(1, _warning_edges.size())])
			list.append({"pos": _warning_positions[i], "color": Color(1.0, 0.45, 0.32),
					"label": _edges_text([edge]) + " INCOMING", "live": false})
	else:
		var count := 0
		for z in GameManager.zombies:
			if z == null or not is_instance_valid(z) or z.dead:
				continue
			list.append({"pos": z.global_position, "color": Color(1.0, 0.58, 0.45),
					"label": "", "live": true})
			count += 1
			if count >= 8:
				break
	_threats.set_threats(list)

func _edges_text(edges: Array) -> String:
	var names := {"n": "NORTH", "s": "SOUTH", "e": "EAST", "w": "WEST"}
	var out := []
	for e in edges:
		out.append(names.get(String(e), String(e)))
	return " + ".join(out)

func _show_banner(text: String, color: Color, duration: float) -> void:
	_banner_label.text = text
	_banner_label.add_theme_color_override("font_color", color)
	_banner.visible = true
	_banner_timer.wait_time = duration
	_banner_timer.start()
	var tw := create_tween()
	_banner.pivot_offset = _banner.size * 0.5
	tw.tween_property(_banner, "modulate", Color(1.25, 1.15, 1.0), 0.12)
	tw.tween_property(_banner, "modulate", Color.WHITE, 0.25)

func _on_feedback(text: String, kind: String) -> void:
	var color := UiTheme.C_TEXT
	match kind:
		"error": color = UiTheme.C_DANGER
		"success": color = UiTheme.C_OK
		"warning": color = UiTheme.C_WARN
		"info": color = UiTheme.C_ACCENT
	var panel := PanelContainer.new()
	panel.theme_type_variation = "HudPanel"
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.size_flags_horizontal = Control.SIZE_SHRINK_END
	panel.custom_minimum_size = Vector2(330, 0)
	var l := UiTheme.make_label(text, color, 16)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(306, 0)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	panel.add_child(l)
	_notify_box.add_child(panel)
	if _notify_box.get_child_count() > 5:
		var old := _notify_box.get_child(0)
		_notify_box.remove_child(old)
		var old_tw: Tween = old.get_meta("toast_tween", null)
		if old_tw != null and old_tw.is_valid():
			old_tw.kill()
		old.queue_free()
	panel.modulate.a = 0.0
	var tw := create_tween()
	panel.set_meta("toast_tween", tw)
	tw.tween_property(panel, "modulate:a", 1.0, 0.12)
	tw.tween_interval(2.6)
	tw.tween_property(panel, "modulate:a", 0.0, 0.5)
	tw.tween_callback(_retire_toast.bind(panel))

func _retire_toast(panel: PanelContainer) -> void:
	if is_instance_valid(panel):
		panel.queue_free()

func _on_game_over(_stats: Dictionary) -> void:
	_banner.visible = false
	set_process(true)

func deploy_index(i: int) -> void:
	_deploy_panel.activate_index(i)

func set_selection_hint(text: String) -> void:
	_unit_panel.set_hint(text)

func _process(delta: float) -> void:
	_civ_alert_cd = maxf(0.0, _civ_alert_cd - delta)
	_update_threats()
	_status_label.text = GameManager.waves.state_name() if not GameManager.paused else "PAUSED"
	_zombie_label.text = "%d" % GameManager.zombies.size()
	_mil_label.text = "%d" % GameManager.units.size()
	if GameManager.waves != null and GameManager.waves.state == WaveManager.State.INTERMISSION:
		var s: float = GameManager.waves.seconds_to_next()
		if s > 0.0:
			_wave_panel.visible = true
			_wave_button.visible = true
			_wave_info.text = "NEXT WAVE %d IN %ds" % [GameManager.waves.wave + 1, int(ceil(s))]
			_wave_info.add_theme_color_override("font_color", UiTheme.C_GOLD)
	elif GameManager.waves != null and GameManager.waves.state == WaveManager.State.WARNING:
		_wave_panel.visible = true
		_wave_button.visible = false
