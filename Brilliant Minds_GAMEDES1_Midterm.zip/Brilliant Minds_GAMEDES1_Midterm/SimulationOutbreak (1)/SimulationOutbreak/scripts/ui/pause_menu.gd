extends Control
class_name PauseMenu

var _panel: PanelContainer
var _settings_box: VBoxContainer

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UiTheme.build()
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	_build()
	GameManager.simulation_paused.connect(func(): visible = true)
	GameManager.simulation_resumed.connect(func(): visible = false)
	GameManager.game_over.connect(func(_s): visible = false)

func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.04, 0.72)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)

	_panel = PanelContainer.new()
	_panel.theme_type_variation = "HudPanel"
	_panel.set_anchors_preset(Control.PRESET_CENTER)
	_panel.custom_minimum_size = Vector2(380, 0)
	_panel.position = Vector2(-190, -190)
	add_child(_panel)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	_panel.add_child(v)

	var title := UiTheme.make_label("SIMULATION PAUSED", UiTheme.C_GOLD, 24)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(title)

	var sub := UiTheme.make_label("ALL COMBAT, MOVEMENT AND WAVE TIMERS ARE FROZEN",
			UiTheme.C_DIM, 8)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(sub)

	v.add_child(_spacer(4))
	v.add_child(_button("RESUME", func(): GameManager.set_paused(false)))
	v.add_child(_button("RESTART SIMULATION", func(): GameManager.restart()))
	v.add_child(_button("SETTINGS", func(): _settings_box.visible = not _settings_box.visible))
	v.add_child(_button("RETURN TO MAIN MENU", func(): GameManager.return_to_menu()))

	_settings_box = VBoxContainer.new()
	_settings_box.visible = false
	_settings_box.add_theme_constant_override("separation", 4)
	v.add_child(_settings_box)
	_settings_box.add_child(_slider_row("MASTER", GameConfig.master_volume,
			func(v2): GameConfig.master_volume = v2; GameConfig.save_settings()))
	_settings_box.add_child(_slider_row("MUSIC", GameConfig.music_volume,
			func(v2): GameConfig.music_volume = v2; GameConfig.save_settings()))
	_settings_box.add_child(_slider_row("EFFECTS", GameConfig.sfx_volume,
			func(v2): GameConfig.sfx_volume = v2; GameConfig.save_settings()))
	_settings_box.add_child(_toggle_row("SCREEN SHAKE", GameConfig.screen_shake,
			func(on): GameConfig.screen_shake = on; GameConfig.save_settings()))

	var hint := UiTheme.make_label("SPACE RESUME   -   F5 RESTART FROM MENU", UiTheme.C_DIM, 8)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(_spacer(4))
	v.add_child(hint)

func _spacer(h: int) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	return c

func _button(text: String, cb: Callable) -> Button:
	var b := UiTheme.make_button(text)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(func():
		Sfx.play("ui_click", -8.0)
		cb.call())
	return b

func _slider_row(label: String, value: float, cb: Callable) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var l := UiTheme.make_label(label, UiTheme.C_DIM, 8)
	l.custom_minimum_size = Vector2(64, 0)
	row.add_child(l)
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = value
	s.custom_minimum_size = Vector2(200, 12)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.value_changed.connect(func(v): cb.call(v))
	row.add_child(s)
	return row

func _toggle_row(label: String, value: bool, cb: Callable) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var l := UiTheme.make_label(label, UiTheme.C_DIM, 8)
	l.custom_minimum_size = Vector2(64, 0)
	row.add_child(l)
	var check := CheckButton.new()
	check.button_pressed = value
	check.toggled.connect(func(on): cb.call(on))
	row.add_child(check)
	return row
