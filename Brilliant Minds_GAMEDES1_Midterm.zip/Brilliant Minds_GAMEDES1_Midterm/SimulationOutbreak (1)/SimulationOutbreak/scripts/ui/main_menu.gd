extends Control
const BUILD_ID := "v8 2026-10-30"

var _settings_panel: PanelContainer
var _help_panel: PanelContainer
var _audio_cache: Dictionary = {}

func _ready() -> void:
	theme = UiTheme.build()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	GameManager.session_active = false
	GameManager.simulation_over = false
	GameManager.paused = false
	get_tree().paused = false
	Engine.time_scale = 1.0
	Sfx.stop_ambience()
	Sfx.play_music("menu_bed")
	_build()

func _build() -> void:
	var bg := TextureRect.new()
	bg.texture = SpriteLib.texture("res://assets/sprites/ui/key_art.png")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	var vignette := ColorRect.new()
	vignette.color = Color(0.02, 0.03, 0.05, 0.35)
	vignette.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vignette)

	var col := VBoxContainer.new()
	col.set_anchors_preset(Control.PRESET_CENTER_LEFT)
	col.position = Vector2(56, -150)
	col.custom_minimum_size = Vector2(430, 0)
	col.add_theme_constant_override("separation", 6)
	add_child(col)

	var title_plate := PanelContainer.new()
	title_plate.theme_type_variation = "HudPanel"
	title_plate.custom_minimum_size = Vector2(430, 0)
	title_plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var title_box := VBoxContainer.new()
	title_box.add_theme_constant_override("separation", 8)
	title_plate.add_child(title_box)
	col.add_child(title_plate)

	var title := UiTheme.make_label("SIMULATION OUTBREAK", UiTheme.C_TEXT, 26)
	title_box.add_child(title)
	var title2 := UiTheme.make_label("ZOMBIE GAME", UiTheme.C_DANGER, 26)
	title_box.add_child(title2)
	var sub := UiTheme.make_label("COMMAND THE LAST DEFENDERS OF A CITY THAT IS ALREADY LOST",
			UiTheme.C_DIM, 8)
	title_box.add_child(sub)
	var credit := UiTheme.make_label("VERSION 1   -   BRILLIANT MINDS   -   BSCS 1AC1   -   19/09/2026",
			UiTheme.C_ACCENT, 8)
	title_box.add_child(credit)
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 18)
	col.add_child(spacer)

	var start := UiTheme.make_button("START SIMULATION", "AccentButton")
	start.custom_minimum_size = Vector2(300, 0)
	start.pressed.connect(_on_start)
	_setup_hover(start)
	col.add_child(start)

	var settings := UiTheme.make_button("SETTINGS")
	settings.custom_minimum_size = Vector2(300, 0)
	settings.pressed.connect(func():
		_audio_cache["click"] = true
		Sfx.play("ui_click", -6.0)
		_settings_panel.visible = not _settings_panel.visible
		_help_panel.visible = false)
	_setup_hover(settings)
	col.add_child(settings)

	var help := UiTheme.make_button("CONTROLS")
	help.custom_minimum_size = Vector2(300, 0)
	help.pressed.connect(func():
		Sfx.play("ui_click", -6.0)
		_help_panel.visible = not _help_panel.visible
		_settings_panel.visible = false)
	_setup_hover(help)
	col.add_child(help)

	var quit := UiTheme.make_button("EXIT")
	quit.custom_minimum_size = Vector2(300, 0)
	quit.pressed.connect(func():
		Sfx.play("ui_click", -6.0)
		get_tree().quit())
	_setup_hover(quit)
	col.add_child(quit)

	var footer := UiTheme.make_label("ORIGINAL ARTWORK  -  PROCEDURAL AUDIO  -  GODOT 4.7  -  BUILD %s" % BUILD_ID,
			UiTheme.C_DIM, 8)
	footer.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	footer.position = Vector2(56, -34)
	add_child(footer)

	_build_settings()
	_build_help()

func _setup_hover(b: Button) -> void:
	b.mouse_entered.connect(func(): Sfx.play("ui_hover", -14.0, 0.05))

func _build_settings() -> void:
	_settings_panel = PanelContainer.new()
	_settings_panel.theme_type_variation = "HudPanel"
	_settings_panel.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
	_settings_panel.position = Vector2(-380, -150)
	_settings_panel.custom_minimum_size = Vector2(340, 0)
	_settings_panel.visible = false
	add_child(_settings_panel)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	_settings_panel.add_child(v)
	v.add_child(UiTheme.make_label("SETTINGS", UiTheme.C_GOLD, 24))
	v.add_child(_slider_row("MASTER", GameConfig.master_volume,
			func(x): GameConfig.master_volume = x; GameConfig.save_settings()))
	v.add_child(_slider_row("MUSIC", GameConfig.music_volume,
			func(x): GameConfig.music_volume = x; GameConfig.save_settings()))
	v.add_child(_slider_row("EFFECTS", GameConfig.sfx_volume,
			func(x): GameConfig.sfx_volume = x; GameConfig.save_settings()))
	v.add_child(_toggle_row("SCREEN SHAKE", GameConfig.screen_shake,
			func(on): GameConfig.screen_shake = on; GameConfig.save_settings()))
	v.add_child(_toggle_row("HEALTH BARS ALWAYS VISIBLE", GameConfig.show_health_bars,
			func(on): GameConfig.show_health_bars = on; GameConfig.save_settings()))
	var note := UiTheme.make_label("SETTINGS ARE SAVED IMMEDIATELY", UiTheme.C_DIM, 8)
	v.add_child(note)

func _build_help() -> void:
	_help_panel = PanelContainer.new()
	_help_panel.theme_type_variation = "HudPanel"
	_help_panel.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
	_help_panel.position = Vector2(-420, -190)
	_help_panel.custom_minimum_size = Vector2(380, 0)
	_help_panel.visible = false
	add_child(_help_panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 2)
	_help_panel.add_child(v)
	v.add_child(UiTheme.make_label("FIELD MANUAL", UiTheme.C_GOLD, 24))
	var lines := [
		"LEFT CLICK            SELECT UNIT",
		"LEFT DRAG (GROUND)    DRAG THE MAP",
		"LEFT DRAG (ON UNITS)  BOX SELECT",
		"SHIFT + DRAG          BOX SELECT ALWAYS",
		"MIDDLE DRAG           DRAG THE MAP",
		"RIGHT CLICK           MOVE ORDER",
		"MOUSE WHEEL           ZOOM AT CURSOR",
		"WASD / ARROWS         PAN CAMERA",
		"1 - 5                 DEPLOY FROM PANEL",
		"E                     SELECT ALL",
		"SPACE                 PAUSE / RESUME",
		"T                     SIMULATION SPEED",
		"ESC                   CANCEL / PAUSE",
		"",
		"PROTECT THE CIVILIANS IN C1, C2 AND C3.",
		"INFECTED ENTER FROM ANY CITY EDGE:",
		"WATCH THE WARNING MARKERS, SHIFT UNITS",
		"AND SPEND GOLD ON NEW SQUADS.",
	]
	for l in lines:
		var lbl := UiTheme.make_label(l, UiTheme.C_TEXT if l.length() > 0 else UiTheme.C_DIM, 8)
		v.add_child(lbl)

func _slider_row(label: String, value: float, cb: Callable) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var l := UiTheme.make_label(label, UiTheme.C_DIM, 8)
	l.custom_minimum_size = Vector2(72, 0)
	row.add_child(l)
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = value
	s.custom_minimum_size = Vector2(180, 12)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.value_changed.connect(func(x): cb.call(x))
	row.add_child(s)
	return row

func _toggle_row(label: String, value: bool, cb: Callable) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var l := UiTheme.make_label(label, UiTheme.C_DIM, 8)
	l.custom_minimum_size = Vector2(230, 0)
	row.add_child(l)
	var c := CheckButton.new()
	c.button_pressed = value
	c.toggled.connect(func(on): cb.call(on))
	row.add_child(c)
	return row

func _on_start() -> void:
	Sfx.play("ui_confirm", -6.0)
	Sfx.stop_music()
	Sfx.play_music("music_loop")
	Sfx.play_ambience("ambience")
	get_tree().change_scene_to_file("res://scenes/main/Main.tscn")
