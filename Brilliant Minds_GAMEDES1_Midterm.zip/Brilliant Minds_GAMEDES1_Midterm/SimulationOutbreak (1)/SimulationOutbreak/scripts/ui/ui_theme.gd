extends RefCounted
class_name UiTheme

const FONT := "res://assets/fonts/cc_ops_pixel.ttf"
const UI := "res://assets/sprites/ui/"

const C_TEXT := Color("#e6e0cd")
const C_DIM := Color("#9aa294")
const C_GOLD := Color("#e8c069")
const C_DANGER := Color("#cf5b4c")
const C_OK := Color("#8fc98c")
const C_ACCENT := Color("#63b9ae")
const C_WARN := Color("#e0a448")
const C_PANEL := Color(0.055, 0.067, 0.086, 0.94)

static var _cached: Theme = null

static func tex(path: String) -> Texture2D:
	if ResourceLoader.exists(path):
		return load(path)
	return null

static func panel_style(path: String = UI + "panel.png", margin: int = 8) -> StyleBoxTexture:
	var sb := StyleBoxTexture.new()
	sb.texture = tex(path)
	sb.texture_margin_left = margin
	sb.texture_margin_top = margin
	sb.texture_margin_right = margin
	sb.texture_margin_bottom = margin
	sb.content_margin_left = 10
	sb.content_margin_right = 10
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	return sb

static func flat_style(color: Color, border: Color, border_w: int = 1) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.border_color = border
	sb.border_width_left = border_w
	sb.border_width_right = border_w
	sb.border_width_top = border_w
	sb.border_width_bottom = border_w
	sb.content_margin_left = 8
	sb.content_margin_right = 8
	sb.content_margin_top = 5
	sb.content_margin_bottom = 5
	return sb

static func button_style(state: String) -> StyleBoxTexture:
	var sb := StyleBoxTexture.new()
	sb.texture = tex(UI + "button_%s.png" % state)
	sb.texture_margin_left = 6
	sb.texture_margin_top = 6
	sb.texture_margin_right = 6
	sb.texture_margin_bottom = 6
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 7
	sb.content_margin_bottom = 7
	return sb

static func build() -> Theme:
	if _cached != null:
		return _cached
	var th := Theme.new()
	var font: Font = load(FONT) if ResourceLoader.exists(FONT) else null
	if font:
		th.default_font = font
	th.default_font_size = 16

	th.set_stylebox("panel", "PanelContainer", panel_style())
	th.set_stylebox("panel", "Panel", panel_style())
	var hud_panel := panel_style()
	hud_panel.content_margin_left = 10
	hud_panel.content_margin_right = 10
	hud_panel.content_margin_top = 6
	hud_panel.content_margin_bottom = 6
	th.set_type_variation("HudPanel", "PanelContainer")
	th.set_stylebox("panel", "HudPanel", hud_panel)

	th.set_color("font_color", "Label", C_TEXT)
	th.set_color("font_shadow_color", "Label", Color(0, 0, 0, 0.55))
	th.set_constant("shadow_offset_x", "Label", 1)
	th.set_constant("shadow_offset_y", "Label", 1)
	th.set_font_size("font_size", "Label", 16)

	th.set_type_variation("DimLabel", "Label")
	th.set_color("font_color", "DimLabel", C_DIM)
	th.set_font_size("font_size", "DimLabel", 16)

	th.set_type_variation("SmallLabel", "Label")
	th.set_font_size("font_size", "SmallLabel", 8)
	th.set_color("font_color", "SmallLabel", C_DIM)

	th.set_type_variation("TitleLabel", "Label")
	th.set_font_size("font_size", "TitleLabel", 32)
	th.set_color("font_color", "TitleLabel", C_TEXT)

	th.set_type_variation("H2Label", "Label")
	th.set_font_size("font_size", "H2Label", 24)
	th.set_color("font_color", "H2Label", C_GOLD)

	var normal := button_style("normal")
	var hover := button_style("hover")
	var pressed := button_style("pressed")
	var disabled := button_style("disabled")
	var accent := button_style("accent")
	th.set_stylebox("normal", "Button", normal)
	th.set_stylebox("hover", "Button", hover)
	th.set_stylebox("pressed", "Button", pressed)
	th.set_stylebox("disabled", "Button", disabled)
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_color("font_color", "Button", C_TEXT)
	th.set_color("font_hover_color", "Button", Color("#f4efdd"))
	th.set_color("font_pressed_color", "Button", C_GOLD)
	th.set_color("font_disabled_color", "Button", Color(0.55, 0.55, 0.5, 0.7))
	th.set_font_size("font_size", "Button", 16)

	th.set_type_variation("AccentButton", "Button")
	th.set_stylebox("normal", "AccentButton", accent)
	th.set_stylebox("hover", "AccentButton", hover)
	th.set_stylebox("pressed", "AccentButton", pressed)
	th.set_stylebox("disabled", "AccentButton", disabled)
	th.set_font_size("font_size", "AccentButton", 16)

	th.set_type_variation("SmallButton", "Button")
	th.set_font_size("font_size", "SmallButton", 8)
	th.set_stylebox("normal", "SmallButton", normal)
	th.set_stylebox("hover", "SmallButton", hover)
	th.set_stylebox("pressed", "SmallButton", pressed)
	th.set_stylebox("disabled", "SmallButton", disabled)

	var bg := flat_style(Color(0.06, 0.07, 0.09, 0.9), Color(0.25, 0.28, 0.32), 1)
	bg.content_margin_top = 0
	bg.content_margin_bottom = 0
	var fill := flat_style(Color(0.36, 0.62, 0.40), Color(0, 0, 0, 0), 0)
	fill.content_margin_top = 0
	fill.content_margin_bottom = 0
	th.set_stylebox("background", "ProgressBar", bg)
	th.set_stylebox("fill", "ProgressBar", fill)
	th.set_font_size("font_size", "ProgressBar", 8)
	th.set_color("font_color", "ProgressBar", C_TEXT)

	th.set_stylebox("slider", "HSlider", flat_style(Color(0.1, 0.12, 0.14), Color(0.3, 0.33, 0.36), 1))
	th.set_stylebox("grabber_area", "HSlider", flat_style(Color(0.35, 0.62, 0.58), Color(0, 0, 0, 0), 0))

	var tip := flat_style(Color(0.06, 0.07, 0.09, 0.97), C_ACCENT, 1)
	th.set_stylebox("panel", "TooltipPanel", tip)
	th.set_color("font_color", "TooltipLabel", C_TEXT)
	th.set_font_size("font_size", "TooltipLabel", 8)

	_cached = th
	return th

static func make_label(text: String, color: Color = C_TEXT, size: int = 16,
		variation: String = "") -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_color_override("font_color", color)
	if size != 16:
		l.add_theme_font_size_override("font_size", size)
	if variation != "":
		l.theme_type_variation = variation
	return l

static func make_icon(path: String, size: Vector2 = Vector2(20, 20)) -> TextureRect:
	var tr := TextureRect.new()
	var t := tex(path)
	if t:
		tr.texture = t
	tr.custom_minimum_size = size
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	return tr

static func make_button(text: String, variation: String = "") -> Button:
	var b := Button.new()
	b.text = text
	if variation != "":
		b.theme_type_variation = variation
	b.focus_mode = Control.FOCUS_NONE
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	return b
