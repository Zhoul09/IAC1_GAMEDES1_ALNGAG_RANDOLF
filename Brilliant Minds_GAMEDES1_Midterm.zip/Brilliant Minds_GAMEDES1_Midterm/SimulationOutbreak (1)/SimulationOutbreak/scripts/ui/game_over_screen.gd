extends Control
class_name GameOverScreen

var _panel: PanelContainer
var _rows: VBoxContainer
var _reason: Label
var _rank: Label

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = UiTheme.build()
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	_build()
	GameManager.game_over.connect(_on_game_over)

func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.025, 0.03, 0.82)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)

	_panel = PanelContainer.new()
	_panel.theme_type_variation = "HudPanel"
	_panel.set_anchors_preset(Control.PRESET_CENTER)
	_panel.custom_minimum_size = Vector2(430, 0)
	_panel.position = Vector2(-215, -210)
	add_child(_panel)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	_panel.add_child(v)

	var title := UiTheme.make_label("CITY LOST", UiTheme.C_DANGER, 32)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(title)
	_reason = UiTheme.make_label("", UiTheme.C_WARN, 8)
	_reason.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(_reason)
	v.add_child(_hline())

	_rows = VBoxContainer.new()
	_rows.add_theme_constant_override("separation", 2)
	v.add_child(_rows)

	_rank = UiTheme.make_label("", UiTheme.C_GOLD, 16)
	_rank.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(_rank)
	v.add_child(_hline())

	var buttons := HBoxContainer.new()
	buttons.add_theme_constant_override("separation", 8)
	v.add_child(buttons)
	var restart := UiTheme.make_button("RESTART SIMULATION", "AccentButton")
	restart.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	restart.pressed.connect(func(): GameManager.restart())
	buttons.add_child(restart)
	var menu := UiTheme.make_button("MAIN MENU")
	menu.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	menu.pressed.connect(func(): GameManager.return_to_menu())
	buttons.add_child(menu)

func _hline() -> Control:
	var c := ColorRect.new()
	c.color = Color(0.7, 0.75, 0.7, 0.2)
	c.custom_minimum_size = Vector2(0, 1)
	return c

func _on_game_over(stats: Dictionary) -> void:
	visible = true
	_reason.text = String(stats.get("reason", "SIMULATION ENDED"))
	for c in _rows.get_children():
		c.queue_free()
	_row("WAVES SURVIVED", str(stats.get("waves_survived", 0)))
	_row("WAVE REACHED", str(stats.get("wave_reached", 0)))
	_row("SURVIVAL TIME", String(stats.get("time_text", "00:00")))
	_row("CIVILIANS REMAINING", "%d / %d" % [int(stats.get("civilians_remaining", 0)),
			int(stats.get("civilians_total", GameManager.population.initial))])
	_row("CIVILIANS LOST", str(stats.get("civilians_lost", 0)))
	_row("INFECTED ELIMINATED", str(stats.get("zombies_killed", 0)))
	_row("MILITARY LOSSES", str(stats.get("military_lost", 0)))
	_row("MILITARY SURVIVING", str(stats.get("military_alive", 0)))
	_row("FINAL GOLD", str(stats.get("gold", 0)))
	var waves := int(stats.get("waves_survived", 0))
	var civ := int(stats.get("civilians_remaining", 0))
	var rank := "CADET"
	if waves >= 12 and civ >= 60:
		rank = "CITY GUARDIAN"
	elif waves >= 9 and civ >= 40:
		rank = "VETERAN COMMANDER"
	elif waves >= 6:
		rank = "FIELD CAPTAIN"
	elif waves >= 3:
		rank = "SQUAD LEADER"
	_rank.text = "RATING: %s" % rank

func _row(label: String, value: String) -> void:
	var h := HBoxContainer.new()
	var l := UiTheme.make_label(label, UiTheme.C_DIM, 16)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(l)
	var r := UiTheme.make_label(value, UiTheme.C_TEXT, 16)
	r.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(r)
	_rows.add_child(h)
