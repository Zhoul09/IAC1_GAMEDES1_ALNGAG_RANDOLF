extends PanelContainer
class_name DeploymentPanel

signal deploy_selected(kind: String, id: String)

var _cards: Array = []
var _entries: Array = []

func _ready() -> void:
	theme = UiTheme.build()
	theme_type_variation = "HudPanel"
	mouse_filter = Control.MOUSE_FILTER_STOP
	custom_minimum_size = Vector2(636, 0)
	_build()
	GameManager.gold.gold_changed.connect(func(_g, _d): refresh())
	GameManager.stats_updated.connect(refresh)

func _build() -> void:
	_entries = []
	for id in ["rifle_soldier", "heavy_gunner", "armored_vehicle"]:
		_entries.append({"kind": "unit", "id": id})
	for id in ["barricade", "turret"]:
		_entries.append({"kind": "defense", "id": id})

	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 4)
	add_child(root)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 8)
	root.add_child(header)
	header.add_child(UiTheme.make_label("DEPLOYMENT", UiTheme.C_ACCENT, 16))
	header.add_child(UiTheme.make_label("[1-5] SELECT   RIGHT CLICK CANCEL", UiTheme.C_DIM, 8))

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	root.add_child(row)

	for i in _entries.size():
		var e: Dictionary = _entries[i]
		row.add_child(_make_card(e, i))

func _make_card(entry: Dictionary, index: int) -> Control:
	var is_unit: bool = entry["kind"] == "unit"
	var def: Dictionary = GameConfig.unit(entry["id"]) if is_unit else GameConfig.defense(entry["id"])
	var cost: int = int(def.get("cost", 50))
	var card := PanelContainer.new()
	card.theme = theme
	card.custom_minimum_size = Vector2(118, 140)
	card.mouse_filter = Control.MOUSE_FILTER_STOP
	var sb := UiTheme.flat_style(Color(0.09, 0.10, 0.12, 0.96), Color(0.28, 0.31, 0.34), 1)
	sb.content_margin_left = 5
	sb.content_margin_right = 5
	sb.content_margin_top = 4
	sb.content_margin_bottom = 4
	card.add_theme_stylebox_override("panel", sb)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 2)
	card.add_child(v)

	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 4)
	v.add_child(top)
	var portrait := UiTheme.make_icon(String(def.get("portrait", "")), Vector2(32, 32))
	portrait.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	top.add_child(portrait)
	var name_v := VBoxContainer.new()
	name_v.add_theme_constant_override("separation", 0)
	name_v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(name_v)
	var short_label := UiTheme.make_label(String(def.get("short", entry["id"])), UiTheme.C_TEXT, 8)
	name_v.add_child(short_label)
	var cost_label := UiTheme.make_label("%d" % cost, UiTheme.C_GOLD, 16)
	name_v.add_child(cost_label)
	var key_label := UiTheme.make_label(str(index + 1), UiTheme.C_DIM, 8)
	key_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	key_label.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	top.add_child(key_label)

	var role := UiTheme.make_label(String(def.get("role", "")), UiTheme.C_DIM, 8)
	role.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	role.custom_minimum_size = Vector2(104, 24)
	role.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(role)

	var button := UiTheme.make_button("DEPLOY", "SmallButton")
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.pressed.connect(func(): _activate(entry))
	v.add_child(button)

	card.gui_input.connect(func(ev):
		if ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT:
			_activate(entry)
	)
	card.tooltip_text = "%s\n%s" % [String(def.get("name", "")), String(def.get("role", ""))]
	_cards.append({"entry": entry, "card": card, "button": button, "cost": cost,
			"cost_label": cost_label})
	return card

func _activate(entry: Dictionary) -> void:
	if GameManager.simulation_over:
		return
	deploy_selected.emit(String(entry["kind"]), String(entry["id"]))

func activate_index(i: int) -> void:
	if i >= 0 and i < _entries.size():
		_activate(_entries[i])

func refresh() -> void:
	if GameManager.gold == null:
		return
	for c in _cards:
		var affordable: bool = GameManager.gold.can_afford(int(c["cost"]))
		c["button"].disabled = GameManager.simulation_over
		var col: Color = UiTheme.C_GOLD if affordable else Color(0.55, 0.45, 0.4)
		c["cost_label"].add_theme_color_override("font_color", col)
		c["card"].modulate = Color(1, 1, 1, 1.0 if affordable else 0.62)
