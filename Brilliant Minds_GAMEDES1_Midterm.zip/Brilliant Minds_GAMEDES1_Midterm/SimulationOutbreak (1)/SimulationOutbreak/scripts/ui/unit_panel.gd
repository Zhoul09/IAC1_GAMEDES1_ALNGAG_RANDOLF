extends PanelContainer
class_name UnitPanel

var _title: Label
var _subtitle: Label
var _role: Label
var _hp_bar: ProgressBar
var _hp_label: Label
var _upgrade_button: Button
var _repair_button: Button
var _hint: Label
var _target = null

func _ready() -> void:
	theme = UiTheme.build()
	theme_type_variation = "HudPanel"
	mouse_filter = Control.MOUSE_FILTER_STOP
	custom_minimum_size = Vector2(330, 0)
	_build()
	GameManager.selection_changed.connect(refresh)
	GameManager.stats_updated.connect(refresh)
	refresh()

func _build() -> void:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 3)
	add_child(v)
	_title = UiTheme.make_label("NO SELECTION", UiTheme.C_DIM, 16)
	v.add_child(_title)
	_subtitle = UiTheme.make_label("", UiTheme.C_DIM, 8)
	v.add_child(_subtitle)
	_hp_bar = ProgressBar.new()
	_hp_bar.custom_minimum_size = Vector2(0, 10)
	_hp_bar.show_percentage = false
	_hp_bar.max_value = 100
	_hp_bar.value = 100
	v.add_child(_hp_bar)
	_hp_label = UiTheme.make_label("", UiTheme.C_DIM, 8)
	v.add_child(_hp_label)
	_role = UiTheme.make_label("", UiTheme.C_TEXT, 8)
	_role.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(_role)
	var buttons := HBoxContainer.new()
	buttons.add_theme_constant_override("separation", 6)
	v.add_child(buttons)
	_upgrade_button = UiTheme.make_button("UPGRADE", "SmallButton")
	_upgrade_button.pressed.connect(func(): GameManager.request_upgrade_selected())
	buttons.add_child(_upgrade_button)
	_repair_button = UiTheme.make_button("REPAIR", "SmallButton")
	_repair_button.pressed.connect(func(): GameManager.request_repair_selected())
	buttons.add_child(_repair_button)
	_hint = UiTheme.make_label("", UiTheme.C_WARN, 8)
	v.add_child(_hint)

func set_hint(text: String) -> void:
	if _hint:
		_hint.text = text

func refresh() -> void:
	if GameManager.gold == null:
		return
	var count := GameManager.selected_units.size()
	var struct := GameManager.selected_structure
	if count == 0 and struct == null:
		_title.text = "NO SELECTION"
		_title.add_theme_color_override("font_color", UiTheme.C_DIM)
		_subtitle.text = "LEFT CLICK TO SELECT  -  DRAG THE GROUND TO MOVE THE MAP"
		_hp_bar.visible = false
		_hp_label.text = ""
		_role.text = "RIGHT CLICK MOVES  -  WHEEL ZOOMS  -  E SELECTS ALL"
		_upgrade_button.visible = false
		_repair_button.visible = false
		return

	if count > 1:
		var total_hp := 0.0
		var total_max := 0.0
		for u in GameManager.selected_units:
			if is_instance_valid(u):
				total_hp += u.hp
				total_max += u.max_hp
		_title.text = "%d UNITS SELECTED" % count
		_title.add_theme_color_override("font_color", UiTheme.C_ACCENT)
		_subtitle.text = "GROUP ORDER READY"
		_hp_bar.visible = true
		_hp_bar.max_value = total_max
		_hp_bar.value = total_hp
		_hp_label.text = "TOTAL INTEGRITY %d / %d" % [int(total_hp), int(total_max)]
		_role.text = "RIGHT CLICK TO MOVE THE FORMATION  -  SHIFT CLICK ADDS UNITS"
		_upgrade_button.visible = false
		_repair_button.visible = false
		return

	var target = struct if struct != null else GameManager.selected_units[0]
	if target == null or not is_instance_valid(target) or target.get("dead") == true:
		GameManager.clear_selection()
		return
	_hp_bar.visible = true
	_hp_bar.max_value = target.max_hp
	_hp_bar.value = target.hp
	_hp_label.text = "INTEGRITY %d / %d" % [int(target.hp), int(target.max_hp)]
	if target is MilitaryUnitBase:
		var d := GameConfig.unit(target.def_id)
		_title.text = String(d.get("name", target.def_id))
		_title.add_theme_color_override("font_color", UiTheme.C_TEXT)
		_subtitle.text = "LVL %d  -  DMG %d  -  RNG %d  -  %s" % [
			target.level, int(target.damage), int(target.weapon_range),
			"UPGRADED" if target.level > 1 else "STANDARD"]
		_role.text = String(d.get("role", ""))
	else:
		var dd := GameConfig.defense(target.def_id)
		_title.text = String(dd.get("name", target.def_id))
		_title.add_theme_color_override("font_color", UiTheme.C_ACCENT)
		_subtitle.text = "LVL %d  -  %s" % [target.level,
			"AUTOMATIC FIRE" if target.damage > 0.0 else "BLOCKING POSITION"]
		_role.text = String(dd.get("role", ""))
	var up_cost := GameManager.upgrade_cost()
	_upgrade_button.visible = true
	_upgrade_button.text = "UPGRADE %d" % up_cost
	_upgrade_button.disabled = target.level >= 2 or not GameManager.gold.can_afford(up_cost)
	_repair_button.visible = true
	var r_cost := GameManager.repair_cost_for(target)
	_repair_button.text = "REPAIR %d" % r_cost
	_repair_button.disabled = target.health_ratio() >= 0.999 or not GameManager.gold.can_afford(r_cost)

func _process(_delta: float) -> void:
	if GameManager.selected_units.size() == 1 or GameManager.selected_structure != null:
		var target = GameManager.selected_structure if GameManager.selected_structure != null \
				else GameManager.selected_units[0]
		if target != null and is_instance_valid(target) and not target.get("dead"):
			_hp_bar.max_value = target.max_hp
			_hp_bar.value = target.hp
			_hp_label.text = "INTEGRITY %d / %d" % [int(target.hp), int(target.max_hp)]
			_upgrade_button.disabled = target.level >= 2 or not GameManager.gold.can_afford(
					GameManager.upgrade_cost())
			var r := GameManager.repair_cost_for(target)
			_repair_button.text = "REPAIR %d" % r
			_repair_button.disabled = target.health_ratio() >= 0.999 \
					or not GameManager.gold.can_afford(r)
