extends Control

var threats: Array = []
var _font: Font
var _pulse := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_font = load("res://assets/fonts/cc_ops_pixel.ttf")
	z_index = 5

func set_threats(list: Array) -> void:
	threats = list
	queue_redraw()

func _process(delta: float) -> void:
	if threats.is_empty():
		return
	_pulse += delta
	queue_redraw()

func _draw() -> void:
	if threats.is_empty():
		return
	var vp := get_viewport_rect().size
	var ct := get_viewport().get_canvas_transform()
	var frame := Rect2(Vector2(54, 84), vp - Vector2(108, 260))
	var centre := vp * 0.5
	for t in threats:
		var pos: Vector2 = t["pos"]
		var sp: Vector2 = ct * pos
		var col: Color = t.get("color", Color(1, 0.5, 0.4))
		if frame.has_point(sp):
			var p := sp + Vector2(0, -30)
			var s := 4.0 + sin(_pulse * 6.0) * 1.2
			var pts := PackedVector2Array([p + Vector2(0, -s), p + Vector2(s, 0),
					p + Vector2(0, s), p + Vector2(-s, 0)])
			draw_colored_polygon(pts, col)
			continue
		var dir := (sp - centre)
		if dir.length() < 0.01:
			continue
		dir = dir.normalized()
		var half := frame.size * 0.5
		var scale_x: float = half.x / maxf(0.001, absf(dir.x))
		var scale_y: float = half.y / maxf(0.001, absf(dir.y))
		var edge := centre + dir * minf(scale_x, scale_y)
		var ang := dir.angle()
		var size_px := 9.0
		var tip := edge + dir * size_px
		var back := edge - dir * size_px * 0.6
		var side := Vector2(-dir.y, dir.x) * size_px * 0.75
		draw_colored_polygon(PackedVector2Array([tip, back + side, back - side]), col)
		draw_circle(edge - dir * 16.0, 3.0, Color(col.r, col.g, col.b, 0.5))
		var label: String = t.get("label", "")
		if label != "" and _font:
			var txt_pos := edge - dir * 34.0
			draw_string(_font, txt_pos + Vector2(-30, 4), label, HORIZONTAL_ALIGNMENT_LEFT,
					-1, 8, Color(col.r, col.g, col.b, 0.95))
