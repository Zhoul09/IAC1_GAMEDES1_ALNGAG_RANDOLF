extends Node2D
class_name CityMap

const TILE := 32
const ATLAS_PATH := "res://assets/sprites/tiles/city_tiles.png"
const BUILDING_DIR := "res://assets/sprites/buildings/"
const PROP_DIR := "res://assets/sprites/props/"
const FONT_PATH := "res://assets/fonts/cc_ops_pixel.ttf"

const TILE_MAP := {
	"a": [0, 1, 2], "c": [3], "l": [4], "v": [5], "x": [6], "u": [7],
	"s": [8, 9], "e": [19], "p": [11, 12], "m": [13], "g": [14, 15],
	"d": [16], "b": [17], "w": [18], "k": [20, 21], "L": [23], "G": [24],
	"P": [22],
}

signal map_ready

var layout: Dictionary = {}
var pathfinder: Pathfinder
var world_size := Vector2.ZERO
var spawn_points: Array = []
var districts: Array = []
var sites: Array = []
var defense_positions: Array = []
var player_start := Vector2.ZERO

var lamp_positions: Array = []
var emergency_positions: Array = []

var ground: TileMapLayer
var decals: Node2D
var obstacles: Node2D
var _font: Font
var _buildings: Dictionary = {}
var _props_meta: Dictionary = {}
var _rng := RandomNumberGenerator.new()

func build(world_root: Node2D, obstacle_root: Node2D) -> void:
	layout = GameConfig.city
	_rng.seed = 20261029
	_font = load(FONT_PATH)
	world_size = Vector2(int(layout.get("grid_w", 100)) * TILE, int(layout.get("grid_h", 75)) * TILE)
	_build_tileset()
	_build_ground(world_root)
	_build_decals(world_root)
	_build_obstacle_layer(obstacle_root)
	_build_buildings(world_root)
	_build_props(world_root)
	_build_labels(world_root)
	_collect_points()
	pathfinder = Pathfinder.new()
	pathfinder.setup(int(layout["grid_w"]), int(layout["grid_h"]), TILE, layout["blocked"])
	saved_blocked = layout["blocked"]
	map_ready.emit()

var saved_blocked: Array = []

func _build_tileset() -> void:
	var ts := TileSet.new()
	ts.tile_size = Vector2i(TILE, TILE)
	var src := TileSetAtlasSource.new()
	src.texture = SpriteLib.texture(ATLAS_PATH)
	src.texture_region_size = Vector2i(TILE, TILE)
	var cols := int(src.texture.get_width() / TILE)
	var rows := int(src.texture.get_height() / TILE)
	for y in rows:
		for x in cols:
			src.create_tile(Vector2i(x, y))
	ts.add_source(src, 0)
	ground = TileMapLayer.new()
	ground.name = "Ground"
	ground.tile_set = ts
	ground.z_index = -100
	ground.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func _build_ground(world_root: Node2D) -> void:
	world_root.add_child(ground)
	var grid: Array = layout["ground"]
	for y in grid.size():
		var row: String = grid[y]
		for x in row.length():
			var ch := row[x]
			var opts: Array = TILE_MAP.get(ch, [0])
			var idx: int = opts[_rng.randi() % opts.size()]
			ground.set_cell(Vector2i(x, y), 0, Vector2i(idx % 8, idx / 8))
	ground.set_cell(Vector2i(-1, -1), -1)

func _build_decals(world_root: Node2D) -> void:
	decals = Node2D.new()
	decals.name = "Decals"
	decals.z_index = -60
	decals.y_sort_enabled = false
	world_root.add_child(decals)

func _build_obstacle_layer(obstacle_root: Node2D) -> void:
	obstacles = Node2D.new()
	obstacles.name = "Obstacles"
	obstacle_root.add_child(obstacles)

func _add_box_collider(rect: Rect2, parent: Node2D) -> StaticBody2D:
	var body := StaticBody2D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var shape := CollisionShape2D.new()
	var rect_shape := RectangleShape2D.new()
	rect_shape.size = rect.size
	shape.shape = rect_shape
	shape.position = rect.position + rect.size * 0.5
	body.add_child(shape)
	parent.add_child(body)
	return body

func _build_buildings(world_root: Node2D) -> void:
	var list: Array = layout["buildings"]
	list.sort_custom(func(a, b): return (a["ty"] + a["th"]) < (b["ty"] + b["th"]))
	for b in list:
		var spr_path := BUILDING_DIR + String(b["sprite"]) + ".png"
		var tex := SpriteLib.texture(spr_path)
		if tex == null:
			continue
		var sprite := Sprite2D.new()
		sprite.texture = tex
		sprite.centered = false
		sprite.offset = Vector2(-tex.get_width() * 0.5, -tex.get_height())
		var foot_w: int = int(b["tw"]) * TILE
		var foot_h: int = int(b["th"]) * TILE
		sprite.position = Vector2(float(b["tx"]) * TILE + foot_w * 0.5,
				float(b["ty"]) * TILE + foot_h + 10.0)
		sprite.name = "B_" + String(b["sprite"])
		world_root.add_child(sprite)
		_add_box_collider(Rect2(Vector2(b["tx"] * TILE, b["ty"] * TILE),
				Vector2(foot_w, foot_h)), obstacles)

func _build_props(world_root: Node2D) -> void:
	var prop_sizes: Dictionary = _load_prop_sizes()
	var list: Array = layout["props"]
	list.sort_custom(func(a, b): return a["y"] < b["y"])
	for p in list:
		var spr_name := String(p["sprite"])
		var tex := SpriteLib.texture(PROP_DIR + spr_name + ".png")
		if tex == null:
			continue
		var sprite := Sprite2D.new()
		sprite.texture = tex
		sprite.centered = false
		sprite.offset = Vector2(-tex.get_width() * 0.5, -tex.get_height() + 6.0)
		sprite.position = Vector2(float(p["x"]), float(p["y"]))
		sprite.name = "P_" + spr_name
		if p.get("rot", 0) != 0:
			sprite.rotation_degrees = float(p["rot"])
		if spr_name.begins_with("debris") or spr_name.begins_with("spawn_dirt") or spr_name == "helipad":
			decals.add_child(sprite)
			continue
		world_root.add_child(sprite)
		if spr_name.begins_with("streetlight"):
			lamp_positions.append({"pos": sprite.position,
					"broken": spr_name.contains("broken")})
		elif spr_name == "traffic_light":
			lamp_positions.append({"pos": sprite.position, "broken": false})
		elif spr_name.begins_with("hospital_tent"):
			emergency_positions.append({"pos": sprite.position, "kind": "red"})
		elif spr_name == "helipad":
			emergency_positions.append({"pos": sprite.position, "kind": "cold"})
		if bool(p.get("blocks", false)):
			var size: Array = prop_sizes.get(spr_name, [32, 32])
			var w := minf(float(size[0]) * 0.8, TILE * 0.85)
			var h := minf(maxf(16.0, float(size[1]) * 0.5), TILE * 0.8)
			var cx: float = sprite.position.x
			var cy: float = sprite.position.y - h * 0.5
			var cell_x0 := float(int(floor(cx / TILE)) * TILE)
			var cell_y0 := float(int(floor(cy / TILE)) * TILE)
			var x0 := clampf(cx - w * 0.5, cell_x0, cell_x0 + TILE - w)
			var y0 := clampf(cy - h * 0.5, cell_y0, cell_y0 + TILE - h)
			_add_box_collider(Rect2(Vector2(x0, y0), Vector2(w, h)), obstacles)

func _load_prop_sizes() -> Dictionary:
	if not _props_meta.is_empty():
		return _props_meta
	var text := FileAccess.get_file_as_string("res://data/props.json")
	var data = JSON.parse_string(text)
	if typeof(data) == TYPE_DICTIONARY:
		_props_meta = data
	return _props_meta

func _build_labels(world_root: Node2D) -> void:
	districts = layout["districts"]
	for d in districts:
		var r: Array = d["rect"]
		var center := Vector2((float(r[0]) + float(r[2]) + 1) * 0.5 * TILE,
				(float(r[1]) + float(r[3]) + 1) * 0.5 * TILE)
		if d["id"] == "PLAZA":
			continue
		var label := Label.new()
		label.text = String(d["label"])
		if _font:
			label.add_theme_font_override("font", _font)
		label.add_theme_font_size_override("font_size", 13)
		label.add_theme_color_override("font_color", Color(0.85, 0.82, 0.7, 0.30))
		label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.45))
		label.add_theme_constant_override("shadow_offset_x", 1)
		label.add_theme_constant_override("shadow_offset_y", 1)
		label.position = center + Vector2(-70, -float(r[1]) * 0.0 - 6)
		label.z_index = -55
		label.name = "Label_" + String(d["id"])
		decals.add_child(label)
		var sub := Label.new()
		sub.text = "CIVILIANS: %d" % int(d.get("civilian_count", d.get("pop", 0)))
		if _font:
			sub.add_theme_font_override("font", _font)
		sub.add_theme_font_size_override("font_size", 9)
		sub.add_theme_color_override("font_color", Color(0.9, 0.55, 0.45, 0.35))
		sub.position = center + Vector2(-52, 10)
		sub.z_index = -55
		decals.add_child(sub)

func _collect_points() -> void:
	spawn_points = layout["spawn_points"]
	sites = layout.get("sites", [])
	defense_positions = layout.get("defense_positions", [])
	var ps: Dictionary = layout.get("player_start", {})
	player_start = Vector2(float(ps.get("x", world_size.x * 0.5)), float(ps.get("y", world_size.y * 0.5)))

func spawns_for_edge(edge: String) -> Array:
	var out: Array = []
	for sp in spawn_points:
		if String(sp["edge"]) == edge:
			out.append(Vector2(float(sp["x"]), float(sp["y"])))
	return out

func is_blocked_world(p: Vector2) -> bool:
	if p.x < 0 or p.y < 0 or p.x >= world_size.x or p.y >= world_size.y:
		return true
	return not pathfinder.walkable(pathfinder.world_to_cell(p))

func clamp_to_world(p: Vector2) -> Vector2:
	return Vector2(clampf(p.x, 16.0, world_size.x - 16.0), clampf(p.y, 16.0, world_size.y - 16.0))

func site_position(id: String) -> Vector2:
	for s in sites:
		if String(s.get("id", "")) == id:
			return Vector2(float(s.get("x", 0)), float(s.get("y", 0)))
	return player_start

func site_list() -> Array:
	return sites

func district_center(id: String) -> Vector2:
	for d in districts:
		if String(d["id"]) == id:
			var r: Array = d["rect"]
			return Vector2((float(r[0]) + float(r[2])) * 0.5 * TILE, (float(r[1]) + float(r[3])) * 0.5 * TILE)
	return player_start

func add_blood_decal(pos: Vector2, index: int = -1) -> void:
	var idx := index if index >= 0 else _rng.randi() % 3
	var tex := SpriteLib.texture("res://assets/sprites/fx/decal_blood_%d.png" % idx)
	if tex == null:
		return
	var s := Sprite2D.new()
	s.texture = tex
	s.position = pos + Vector2(_rng.randf_range(-4, 4), _rng.randf_range(-3, 3))
	s.rotation = _rng.randf_range(-0.4, 0.4)
	s.modulate = Color(1, 1, 1, 0.75)
	decals.add_child(s)

func register_structure_block(cell: Vector2i, on: bool) -> void:
	pathfinder.set_dynamic(cell, on)

func free_spot_near(p: Vector2, radius: float = 9.0, max_radius: int = 4) -> Vector2:
	var space := get_world_2d().direct_space_state
	var shape := CircleShape2D.new()
	shape.radius = radius
	var q := PhysicsShapeQueryParameters2D.new()
	q.shape = shape
	q.collide_with_areas = false
	q.collision_mask = 1
	if _spot_is_clear(space, q, p):
		return p
	var step := float(TILE)
	for ring in range(1, max_radius + 1):
		for k in 16:
			var ang := TAU * float(k) / 16.0
			var cand: Vector2 = p + Vector2(cos(ang), sin(ang)) * step * float(ring)
			cand = clamp_to_world(cand)
			if not pathfinder.walkable_world(cand):
				continue
			if _spot_is_clear(space, q, cand):
				return cand
	return free_cell_near_world(p, max_radius)

func _spot_is_clear(space: PhysicsDirectSpaceState2D, q: PhysicsShapeQueryParameters2D,
		p: Vector2) -> bool:
	q.transform = Transform2D(0.0, p)
	return space.intersect_shape(q, 1).is_empty()

func free_cell_near_world(p: Vector2, max_radius: int = 3) -> Vector2:
	return pathfinder.nearest_walkable_world(p, max_radius)
