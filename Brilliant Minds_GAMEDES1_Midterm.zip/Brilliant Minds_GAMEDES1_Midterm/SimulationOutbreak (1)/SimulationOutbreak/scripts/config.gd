extends Node

const BALANCE_PATH := "res://data/balance.json"
const UNITS_PATH := "res://data/unit_defs.json"
const DEFENSES_PATH := "res://data/defense_defs.json"
const CITY_PATH := "res://data/city_layout.json"
const SETTINGS_PATH := "user://settings.cfg"

signal settings_changed

var balance: Dictionary = {}
var unit_defs: Dictionary = {}
var defense_defs: Dictionary = {}
var city: Dictionary = {}

var master_volume: float = 1.0
var music_volume: float = 0.7
var sfx_volume: float = 0.85
var screen_shake: bool = true
var show_health_bars: bool = false

func _ready() -> void:
	_load_json()
	load_settings()

func _load_json() -> void:
	balance = _read_json(BALANCE_PATH)
	unit_defs = _read_json(UNITS_PATH)
	defense_defs = _read_json(DEFENSES_PATH)
	city = _read_json(CITY_PATH)

func _read_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		push_error("Missing data file: %s" % path)
		return {}
	var text := FileAccess.get_file_as_string(path)
	var data = JSON.parse_string(text)
	if typeof(data) != TYPE_DICTIONARY:
		push_error("Malformed JSON: %s" % path)
		return {}
	return data

func eco(key: String, fallback: float = 0.0) -> float:
	return float(balance.get("economy", {}).get(key, fallback))

func wave_setting(key: String, fallback: float = 0.0) -> float:
	return float(balance.get("waves", {}).get(key, fallback))

func pop_setting(key: String, fallback: float = 0.0) -> float:
	return float(balance.get("population", {}).get(key, fallback))

func start_setting(key: String, fallback: float = 0.0) -> float:
	return float(balance.get("start", {}).get(key, fallback))

func balance_setting(section: String, key: String, fallback: float = 0.0) -> float:
	return float(balance.get(section, {}).get(key, fallback))

func camera_setting(key: String, fallback: float = 0.0) -> float:
	return float(balance.get("camera", {}).get(key, fallback))

func game_over_rule(key: String, fallback: bool = true) -> bool:
	return bool(balance.get("game_over", {}).get(key, fallback))

func unit_ids() -> Array:
	return unit_defs.keys()

func defense_ids() -> Array:
	return defense_defs.keys()

func unit(id: String) -> Dictionary:
	return unit_defs.get(id, {})

func defense(id: String) -> Dictionary:
	return defense_defs.get(id, {})

func wave_reward(wave_number: int) -> int:
	var base := eco("wave_reward_base", 25.0)
	var step := eco("wave_reward_step", 5.0)
	return int(base + step * float(wave_number - 1))

func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) == OK:
		master_volume = cfg.get_value("audio", "master", master_volume)
		music_volume = cfg.get_value("audio", "music", music_volume)
		sfx_volume = cfg.get_value("audio", "sfx", sfx_volume)
		screen_shake = cfg.get_value("video", "screen_shake", screen_shake)
		show_health_bars = cfg.get_value("video", "health_bars", show_health_bars)
	apply_audio()

func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("audio", "master", master_volume)
	cfg.set_value("audio", "music", music_volume)
	cfg.set_value("audio", "sfx", sfx_volume)
	cfg.set_value("video", "screen_shake", screen_shake)
	cfg.set_value("video", "health_bars", show_health_bars)
	cfg.save(SETTINGS_PATH)
	apply_audio()
	settings_changed.emit()

func apply_audio() -> void:
	if has_node("/root/Sfx"):
		var sfx := get_node("/root/Sfx")
		sfx.set_bus_volume("Music", music_volume * master_volume)
		sfx.set_bus_volume("SFX", sfx_volume * master_volume)
