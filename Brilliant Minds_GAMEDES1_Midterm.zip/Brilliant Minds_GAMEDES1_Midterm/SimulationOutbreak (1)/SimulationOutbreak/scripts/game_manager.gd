extends Node

signal selection_changed
signal unit_deployed(kind: String, id: String, position: Vector2)
signal defense_deployed(id: String, position: Vector2)
signal unit_died(unit: MilitaryUnitBase)
signal zombie_killed(zombie: Zombie)
signal civilian_killed(civilian: Civilian)
signal defense_destroyed(structure: DefenseStructure)
signal game_over(stats: Dictionary)
signal simulation_paused
signal simulation_resumed
signal feedback(text: String, kind: String)
signal stats_updated
signal site_threat_changed(site_id: String, threat: int, civilians: int)
signal base_integrity_changed(value: float)
signal speed_changed(scale: float)
signal selection_validity_changed(valid: bool, reason: String)

const UNIT_SCENES := {
	"rifle_soldier": "res://scenes/units/RifleSoldier.tscn",
	"heavy_gunner": "res://scenes/units/HeavyGunner.tscn",
	"armored_vehicle": "res://scenes/units/ArmoredVehicle.tscn",
}
const DEFENSE_SCENES := {
	"barricade": "res://scenes/defenses/Barricade.tscn",
	"turret": "res://scenes/defenses/Turret.tscn",
}

var gold: ResourceManager
var population: PopulationManager
var waves: WaveManager

var units: Array = []
var zombies: Array = []
var civilians: Array = []
var defenses: Array = []

var city: CityMap = null
var crowd: Crowd = null
var world_root: Node2D = null
var fx = null
var camera = null
var ui = null

var crowd_tick := 0.0
var site_tick := 0.0

var site_status: Dictionary = {}
var base_integrity := 100.0

var session_active := false
var simulation_over := false
var paused := false
var speed_scale := 1.0
var elapsed := 0.0

var selected_units: Array = []
var selected_structure: DefenseStructure = null

var zombies_killed_total := 0
var military_lost := 0
var civilians_lost := 0
var waves_cleared := 0
var gold_earned := 0
var _no_force_timer := 0.0
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_rng.randomize()
	gold = ResourceManager.new()
	gold.name = "ResourceManager"
	add_child(gold)
	population = PopulationManager.new()
	population.name = "PopulationManager"
	add_child(population)
	waves = WaveManager.new()
	waves.name = "WaveManager"
	add_child(waves)
	waves.wave_warning.connect(_on_wave_warning)
	waves.wave_completed.connect(_on_wave_completed)
	waves.wave_started.connect(_on_wave_started)
	gold.gold_changed.connect(_on_gold_changed)
	population.population_changed.connect(_on_population_changed)
	_connect_wave_spawn()

func _connect_wave_spawn() -> void:
	if not waves.spawn_event.is_connected(_on_spawn_event):
		waves.spawn_event.connect(_on_spawn_event)

func start_session(scene_root: Node, city_map: CityMap, world: Node2D, fx_layer,
		cam, ui_root) -> void:
	world_root = world
	city = city_map
	if crowd == null:
		crowd = Crowd.new()
		crowd.name = "Crowd"
		add_child(crowd)
	fx = fx_layer
	camera = cam
	ui = ui_root
	units.clear()
	zombies.clear()
	civilians.clear()
	defenses.clear()
	selected_units.clear()
	selected_structure = null
	session_active = false
	simulation_over = false
	paused = false
	speed_scale = 1.0
	elapsed = 0.0
	zombies_killed_total = 0
	military_lost = 0
	civilians_lost = 0
	waves_cleared = 0
	gold_earned = 0
	_no_force_timer = 0.0
	base_integrity = 100.0
	site_status.clear()
	Engine.time_scale = 1.0
	get_tree().paused = false
	gold.reset()
	population.reset()
	waves.reset()
	_connect_wave_spawn()
	_deploy_built_positions()
	_refresh_sites()
	selection_changed.emit()
	stats_updated.emit()
	speed_changed.emit(speed_scale)

func _deploy_built_positions() -> void:
	if city == null:
		return
	for p in city.defense_positions:
		var id := String(p.get("id", "barricade"))
		var pos := Vector2(float(p.get("x", 0)), float(p.get("y", 0)))
		var d := _instantiate_defense(id, pos)
		if d:
			d.set_meta("prebuilt", true)

func begin_play() -> void:
	if session_active:
		return
	session_active = true
	_spawn_starting_soldiers()
	waves.begin()
	feedback.emit("SIMULATION ONLINE  -  HOLD THE DISTRICTS", "info")

func _spawn_starting_soldiers() -> void:
	var n := int(GameConfig.start_setting("soldiers", 3))
	var radius := float(GameConfig.start_setting("soldier_offset_radius", 70))
	var center: Vector2 = city.player_start
	var spread := [Vector2(-1.0, -0.35), Vector2(1.05, 0.15), Vector2(-0.15, 1.15),
			Vector2(0.75, -1.0), Vector2(-1.15, 0.75)]
	for i in n:
		var dir: Vector2 = spread[i % spread.size()]
		var pos: Vector2 = center + dir * radius * randf_range(0.85, 1.15)
		pos = city.free_cell_near_world(pos, 5)
		var u := _instantiate_unit("rifle_soldier", pos)
		if u:
			u.level = 1

func end_session() -> void:
	session_active = false

func agents_near(pos: Vector2, radius: float) -> Array:
	if crowd == null:
		return []
	return crowd.near(pos, radius)

func nearest_zombie(pos: Vector2, radius: float) -> Node2D:
	return null if crowd == null else crowd.nearest_zombie(pos, radius)

func nearest_civilian(pos: Vector2, radius: float) -> Node2D:
	return null if crowd == null else crowd.nearest_civilian(pos, radius)

func nearest_unit(pos: Vector2, radius: float) -> Node2D:
	return null if crowd == null else crowd.nearest_unit(pos, radius)

func _physics_process(delta: float) -> void:
	if crowd != null and session_active and not paused:
		crowd_tick -= delta
		if crowd_tick <= 0.0:
			crowd_tick = 0.1
			crowd.rebuild()
		site_tick -= delta
		if site_tick <= 0.0:
			site_tick = 0.25
			_refresh_sites()
			_tick_base_integrity(0.25)

func _refresh_sites() -> void:
	if city == null:
		return
	site_status.clear()
	for site in city.site_list():
		var id := String(site.get("id", ""))
		var pos := Vector2(float(site.get("x", 0)), float(site.get("y", 0)))
		var threat := 0
		for n in agents_near(pos, 260.0):
			if n is Zombie:
				threat += 1
		var district := String(site.get("district", ""))
		var civs := 0
		for c in civilians:
			if c != null and is_instance_valid(c) and not c.dead \
					and (district == "" or String(c.group_id) == district):
				civs += 1
		var entry := {"name": String(site.get("label", id)), "pos": pos,
				"threat": threat, "civilians": civs,
				"kind": String(site.get("kind", "shelter"))}
		site_status[id] = entry
		site_threat_changed.emit(id, threat, civs)

func _tick_base_integrity(dt: float) -> void:
	if not GameConfig.game_over_rule("defeat_on_base_overrun", true):
		return
	var base_pos := city.site_position("BASE")
	var pressure := 0
	for n in agents_near(base_pos, 120.0):
		if n is Zombie and not n.dead:
			pressure += 1
	if pressure > 0:
		base_integrity = maxf(0.0, base_integrity - dt * float(pressure) * 3.2)
		if int(elapsed * 2.0) % 2 == 0:
			fx.shake(1.2)
	else:
		base_integrity = minf(100.0, base_integrity + dt * 4.0)
	base_integrity_changed.emit(base_integrity)
	if base_integrity <= 0.0:
		_finish(false, "COMMAND POST OVERRUN")

func base_under_attack() -> bool:
	return base_integrity < 99.0

func register_unit(u: MilitaryUnitBase) -> void:
	if not units.has(u):
		units.append(u)

func register_zombie(z: Zombie) -> void:
	if not zombies.has(z):
		zombies.append(z)

func unregister_zombie(z: Zombie) -> void:
	zombies.erase(z)

func register_civilian(c: Civilian) -> void:
	if not civilians.has(c):
		civilians.append(c)
		population.register(c.group_id)

func register_defense(d: DefenseStructure) -> void:
	if not defenses.has(d):
		defenses.append(d)

func on_unit_died(u: MilitaryUnitBase) -> void:
	units.erase(u)
	military_lost += 1
	if selected_units.has(u):
		selected_units.erase(u)
		selection_changed.emit()
	unit_died.emit(u)
	stats_updated.emit()

func on_zombie_died(z: Zombie) -> void:
	zombies.erase(z)
	zombies_killed_total += 1
	var reward := gold.kill_reward()
	gold.add_gold(reward, "zombie_kill")
	gold_earned += reward
	fx.floating_text(z.global_position + Vector2(0, -26), "+%d" % reward, Color(0.95, 0.82, 0.35))
	zombie_killed.emit(z)
	stats_updated.emit()

func on_civilian_died(c: Civilian) -> void:
	civilians.erase(c)
	civilians_lost += 1
	population.civilian_died(c.group_id)
	civilian_killed.emit(c)
	stats_updated.emit()

func on_defense_destroyed(d: DefenseStructure) -> void:
	defenses.erase(d)
	if selected_structure == d:
		selected_structure = null
		selection_changed.emit()
	defense_destroyed.emit(d)
	stats_updated.emit()

func spawn_zombie(pos: Vector2, wave_id: int, stats: Dictionary) -> Zombie:
	var scene: PackedScene = load("res://scenes/units/Zombie.tscn")
	if scene == null:
		return null
	var z: Zombie = scene.instantiate()
	z.position = pos
	world_root.add_child(z)
	z.configure(wave_id, stats)
	return z

func request_deploy(kind: String, id: String, pos: Vector2) -> bool:
	if simulation_over:
		return false
	var cost := gold.unit_cost(id) if kind == "unit" else gold.defense_cost(id)
	if not gold.can_afford(cost):
		feedback.emit("INSUFFICIENT GOLD - NEED %d" % (cost - gold.gold), "error")
		Sfx.play("ui_error", -8.0)
		return false
	var check := validate_placement(kind, id, pos)
	if not check["ok"]:
		feedback.emit(check["reason"], "error")
		Sfx.play("ui_error", -8.0)
		return false
	if not gold.spend(cost, kind, id):
		return false
	if kind == "unit":
		var u := _instantiate_unit(id, pos)
		if u == null:
			return false
		unit_deployed.emit(kind, id, pos)
		feedback.emit("DEPLOYED %s" % String(GameConfig.unit(id).get("short", id)), "success")
	else:
		var d := _instantiate_defense(id, pos)
		if d == null:
			return false
		defense_deployed.emit(id, pos)
		feedback.emit("POSITION BUILT %s" % String(GameConfig.defense(id).get("name", id)), "success")
	Sfx.play("deploy", -7.0, 0.05)
	fx.deploy_ping(pos)
	return true

func placement_radius(kind: String, id: String) -> float:
	if kind == "unit":
		return float(GameConfig.unit(id).get("placement_radius", 14.0))
	return float(GameConfig.defense(id).get("placement_radius", 16.0))

func validate_placement(kind: String, _id: String, pos: Vector2) -> Dictionary:
	if city == null:
		return {"ok": false, "reason": "NO BATTLEFIELD"}
	var radius := placement_radius(kind, _id)
	var margin := radius + 8.0
	if pos.x < margin or pos.y < margin or pos.x > city.world_size.x - margin \
			or pos.y > city.world_size.y - margin:
		return {"ok": false, "reason": "OUTSIDE THE OPERATION AREA"}
	var samples: Array = [Vector2.ZERO]
	if radius > 30.0:
		samples.append_array([Vector2(-radius, -radius * 0.7), Vector2(radius, -radius * 0.7),
				Vector2(-radius, radius * 0.7), Vector2(radius, radius * 0.7)])
	else:
		var clear_r := maxf(6.0, radius * 0.55)
		samples.append_array([Vector2(clear_r, 0), Vector2(-clear_r, 0),
				Vector2(0, clear_r), Vector2(0, -clear_r)])
	for off in samples:
		var c2: Vector2i = city.pathfinder.world_to_cell(pos + off)
		if not city.pathfinder.in_bounds(c2) or not city.pathfinder.walkable(c2) \
				or city.pathfinder.dynamic.has(c2):
			return {"ok": false, "reason": "POSITION BLOCKED"}
	var cell: Vector2i = city.pathfinder.world_to_cell(pos)
	for u in units:
		if u and is_instance_valid(u) and not u.dead \
				and u.global_position.distance_to(pos) < radius + placement_radius("unit", u.def_id) + 4.0:
			return {"ok": false, "reason": "TOO CLOSE TO A UNIT"}
	for d in defenses:
		if d and is_instance_valid(d) and not d.dead \
				and d.global_position.distance_to(pos) < radius + 24.0:
			return {"ok": false, "reason": "TOO CLOSE TO A POSITION"}
	for c in civilians:
		if c and is_instance_valid(c) and not c.dead and c.global_position.distance_to(pos) < 16.0:
			return {"ok": false, "reason": "CIVILIANS IN THE WAY"}
	if kind == "defense":
		if not _route_stays_open(cell):
			return {"ok": false, "reason": "WOULD SEAL A VITAL ROUTE"}
	return {"ok": true, "reason": ""}

func _route_stays_open(cell: Vector2i) -> bool:
	city.pathfinder.set_dynamic(cell, true)
	var ok := true
	var from: Vector2 = city.pathfinder.nearest_walkable_world(city.player_start, 6)
	for d in city.districts:
		if String(d["id"]) == "PLAZA":
			continue
		var target: Vector2 = city.pathfinder.nearest_walkable_world(
				city.district_center(String(d["id"])), 8)
		var path := city.pathfinder.find_path(from, target, 40000)
		if path.is_empty():
			ok = false
			break
	city.pathfinder.set_dynamic(cell, false)
	return ok

func _instantiate_unit(id: String, pos: Vector2) -> MilitaryUnitBase:
	var path: String = UNIT_SCENES.get(id, "")
	if path == "":
		return null
	var scene: PackedScene = load(path)
	if scene == null:
		return null
	var u: MilitaryUnitBase = scene.instantiate()
	u.position = pos
	world_root.add_child(u)
	return u

func _instantiate_defense(id: String, pos: Vector2) -> DefenseStructure:
	var path: String = DEFENSE_SCENES.get(id, "")
	if path == "":
		return null
	var scene: PackedScene = load(path)
	if scene == null:
		return null
	var d: DefenseStructure = scene.instantiate()
	d.position = pos
	d.setup(id)
	world_root.add_child(d)
	return d

func upgrade_cost() -> int:
	return gold.upgrade_cost()

func request_upgrade_selected() -> bool:
	var target = _selected_target()
	if target == null:
		feedback.emit("NOTHING SELECTED", "error")
		return false
	if target.level >= 2:
		feedback.emit("ALREADY UPGRADED", "error")
		return false
	var cost := gold.upgrade_cost()
	if not gold.can_afford(cost):
		feedback.emit("INSUFFICIENT GOLD - NEED %d" % (cost - gold.gold), "error")
		Sfx.play("ui_error", -8.0)
		return false
	if not gold.spend(cost, "upgrade", target.def_id):
		return false
	target.upgrade()
	Sfx.play("ui_confirm", -6.0)
	fx.floating_text(target.global_position + Vector2(0, -34), "UPGRADED",
			Color(0.55, 0.85, 0.95))
	feedback.emit("UPGRADE COMPLETE", "success")
	selection_changed.emit()
	return true

func repair_cost_for(target) -> int:
	if target == null:
		return 0
	return gold.repair_cost(target.health_ratio())

func request_repair_selected() -> bool:
	var target = _selected_target()
	if target == null:
		feedback.emit("NOTHING SELECTED", "error")
		return false
	if target.health_ratio() >= 0.999:
		feedback.emit("ALREADY AT FULL STRENGTH", "error")
		return false
	var cost := repair_cost_for(target)
	if not gold.can_afford(cost):
		feedback.emit("INSUFFICIENT GOLD - NEED %d" % (cost - gold.gold), "error")
		Sfx.play("ui_error", -8.0)
		return false
	if not gold.spend(cost, "repair", target.def_id):
		return false
	target.repair()
	Sfx.play("ui_confirm", -6.0)
	fx.floating_text(target.global_position + Vector2(0, -34), "REPAIRED",
			Color(0.6, 0.9, 0.6))
	selection_changed.emit()
	return true

func _selected_target():
	if selected_structure != null and is_instance_valid(selected_structure) \
			and not selected_structure.dead:
		return selected_structure
	if selected_units.size() == 1:
		var u = selected_units[0]
		if u != null and is_instance_valid(u) and not u.dead:
			return u
	return null

func select_units(list: Array, additive: bool = false) -> void:
	if not additive:
		for u in selected_units:
			if is_instance_valid(u):
				u.set_selected(false)
		selected_units.clear()
	for u in list:
		if u == null or not is_instance_valid(u) or u.dead:
			continue
		if not selected_units.has(u):
			selected_units.append(u)
		u.set_selected(true)
	if selected_structure != null and is_instance_valid(selected_structure):
		selected_structure.set_selected(false)
	selected_structure = null
	selection_changed.emit()

func select_structure(s: DefenseStructure) -> void:
	for u in selected_units:
		if is_instance_valid(u):
			u.set_selected(false)
	selected_units.clear()
	if selected_structure != null and is_instance_valid(selected_structure):
		selected_structure.set_selected(false)
	selected_structure = s
	if s != null:
		s.set_selected(true)
	selection_changed.emit()

func clear_selection() -> void:
	for u in selected_units:
		if is_instance_valid(u):
			u.set_selected(false)
	selected_units.clear()
	if selected_structure != null and is_instance_valid(selected_structure):
		selected_structure.set_selected(false)
	selected_structure = null
	selection_changed.emit()

func select_all_units() -> void:
	var list := []
	for u in units:
		if u and is_instance_valid(u) and not u.dead:
			list.append(u)
	select_units(list)

func move_selected_to(pos: Vector2) -> void:
	if selected_units.is_empty():
		return
	var count := selected_units.size()
	var radius := 0.0 if count == 1 else 40.0 + 22.0 * sqrt(float(count))
	for u in selected_units:
		if u and is_instance_valid(u):
			radius = maxf(radius, placement_radius("unit", u.def_id) + 34.0)
	var i := 0
	for u in selected_units:
		if u == null or not is_instance_valid(u) or u.dead:
			continue
		var offset := Vector2.ZERO
		if count > 1:
			var ang := TAU * float(i) / float(count) + 0.7
			offset = Vector2(cos(ang), sin(ang) * 0.8) * radius * randf_range(0.8, 1.2)
		var dest: Vector2 = city.clamp_to_world(pos + offset)
		u.order_move(dest)
		i += 1
	fx.move_marker(pos)
	Sfx.play("ui_click", -12.0, 0.1)

func set_paused(on: bool) -> void:
	if simulation_over:
		return
	if paused == on:
		return
	paused = on
	get_tree().paused = on
	if on:
		simulation_paused.emit()
		Sfx.play("ui_click", -6.0)
	else:
		simulation_resumed.emit()
		Sfx.play("ui_click", -6.0)

func toggle_pause() -> void:
	set_paused(not paused)

func cycle_speed() -> void:
	speed_scale = 2.0 if speed_scale < 1.5 else 1.0
	Engine.time_scale = speed_scale if not paused else 1.0
	speed_changed.emit(speed_scale)

func restart() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	paused = false
	simulation_over = false
	session_active = false
	get_tree().change_scene_to_file("res://scenes/main/Main.tscn")

func return_to_menu() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	paused = false
	simulation_over = false
	session_active = false
	Sfx.stop_ambience()
	Sfx.fade_music_out()
	get_tree().change_scene_to_file("res://scenes/main/MainMenu.tscn")

func _on_gold_changed(_g: int, _delta: int) -> void:
	stats_updated.emit()

func _on_population_changed(_remaining: int, _total: int) -> void:
	stats_updated.emit()

func _on_wave_started(wave: int, edges: Array) -> void:
	feedback.emit("WAVE %d - CONTACT FROM %s" % [wave, _edge_names(edges)], "warning")

func _on_wave_warning(wave: int, edges: Array, positions: Array, seconds: float) -> void:
	feedback.emit("INCOMING WAVE %d - %s" % [wave, _edge_names(edges)], "warning")
	if fx:
		fx.spawn_warning(edges, positions, seconds)

func _on_wave_completed(wave: int, reward: int) -> void:
	waves_cleared += 1
	gold.add_gold(reward, "wave_complete")
	gold_earned += reward
	feedback.emit("WAVE %d CLEARED  +%d GOLD" % [wave, reward], "success")
	stats_updated.emit()

func _on_spawn_event(pos: Vector2, _edge: String) -> void:
	if fx:
		fx.spawn_ping(pos)

func _edge_names(edges: Array) -> String:
	var names := {"n": "NORTH", "s": "SOUTH", "e": "EAST", "w": "WEST"}
	var out := []
	for e in edges:
		out.append(names.get(String(e), String(e)))
	return " + ".join(out)

func _process(delta: float) -> void:
	if not session_active or simulation_over or paused:
		return
	elapsed += delta
	if camera and camera.get("zoom"):
		Sfx.camera_position = camera.get_screen_center_position()
		Sfx.camera_zoom = camera.zoom.x
		Sfx.listening = true
	_check_defeat(delta)

func _check_defeat(delta: float) -> void:
	if GameConfig.game_over_rule("defeat_on_zero_civilians", true) and population.remaining <= 0:
		_finish(false, "POPULATION LOST")
		return
	if not GameConfig.game_over_rule("defeat_on_no_forces", true):
		return
	var has_combat_unit := false
	for u in units:
		if u and is_instance_valid(u) and not u.dead:
			has_combat_unit = true
			break
	var has_defense := false
	for d in defenses:
		if d and is_instance_valid(d) and not d.dead:
			has_defense = true
			break
	var can_afford := false
	for id in GameConfig.unit_ids():
		if gold.can_afford(gold.unit_cost(id)):
			can_afford = true
			break
	var threats := not zombies.is_empty() or waves.state in [WaveManager.State.WARNING,
			WaveManager.State.SPAWNING, WaveManager.State.ACTIVE]
	if not has_combat_unit and not has_defense and not can_afford and threats:
		_no_force_timer += delta
		if _no_force_timer > float(GameConfig.balance.get("game_over", {}).get(
				"no_forces_grace_seconds", 20.0)):
			_finish(false, "NO DEFENDERS REMAIN")
	else:
		_no_force_timer = 0.0

func _finish(_victory: bool, reason: String) -> void:
	if simulation_over:
		return
	simulation_over = true
	session_active = false
	waves.stop()
	for u in units:
		if is_instance_valid(u):
			u.set_physics_process(false)
	for z in zombies:
		if is_instance_valid(z):
			z.set_physics_process(false)
	for c in civilians:
		if is_instance_valid(c):
			c.set_physics_process(false)
	Sfx.play("game_over", -5.0, 0.0)
	Sfx.fade_music_out()
	var stats := build_stats()
	stats["reason"] = reason
	game_over.emit(stats)

func build_stats() -> Dictionary:
	var mm := int(elapsed) / 60
	var ss := int(elapsed) % 60
	return {
		"waves_survived": waves_cleared,
		"wave_reached": maxi(0, waves.wave),
		"time_seconds": int(elapsed),
		"time_text": "%02d:%02d" % [mm, ss],
		"civilians_remaining": population.remaining,
		"civilians_total": population.initial,
		"civilians_lost": population.lost,
		"zombies_killed": zombies_killed_total,
		"military_lost": military_lost,
		"military_alive": units.size(),
		"base_integrity": int(round(base_integrity)),
		"gold": gold.gold,
		"gold_earned": gold_earned,
	}

func current_stats() -> Dictionary:
	return build_stats()
