extends Camera2D
class_name CameraController

var zoom_min := 0.55
var zoom_max := 1.9
var pan_speed := 620.0
var zoom_step := 0.12
var world_size := Vector2(3200, 2400)

var _target_zoom := 1.0
var _shake := 0.0
var _shake_offset := Vector2.ZERO

var _panning := false
var _pan_last := Vector2.ZERO

func _ready() -> void:
	zoom_min = GameConfig.camera_setting("zoom_min", 0.55)
	zoom_max = GameConfig.camera_setting("zoom_max", 1.9)
	pan_speed = GameConfig.camera_setting("pan_speed", 620.0)
	zoom_step = GameConfig.camera_setting("zoom_step", 0.12)
	_target_zoom = GameConfig.camera_setting("zoom_default", 1.0)
	zoom = Vector2(_target_zoom, _target_zoom)
	process_mode = Node.PROCESS_MODE_ALWAYS

func setup(bounds: Vector2, start: Vector2) -> void:
	world_size = bounds
	position = start
	_target_zoom = GameConfig.camera_setting("zoom_default", 1.0)
	zoom = Vector2(_target_zoom, _target_zoom)
	_clamp_position()

func _process(delta: float) -> void:
	var move := Vector2.ZERO
	if not _typing():
		if Input.is_action_pressed("cam_left"):
			move.x -= 1.0
		if Input.is_action_pressed("cam_right"):
			move.x += 1.0
		if Input.is_action_pressed("cam_up"):
			move.y -= 1.0
		if Input.is_action_pressed("cam_down"):
			move.y += 1.0
	if move != Vector2.ZERO:
		position += move.normalized() * pan_speed * delta / zoom.x
		_clamp_position()
	if absf(zoom.x - _target_zoom) > 0.001:
		var z: float = lerpf(zoom.x, _target_zoom, minf(1.0, delta * 14.0))
		zoom = Vector2(z, z)
		_clamp_position()
	if _shake > 0.0:
		_shake = maxf(0.0, _shake - delta * 18.0)
		_shake_offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * _shake
		offset = _shake_offset
	elif offset != Vector2.ZERO:
		offset = Vector2.ZERO

func _typing() -> bool:
	return false

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom_at_screen(event.position, zoom_step)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom_at_screen(event.position, -zoom_step)
	elif event is InputEventKey and event.pressed:
		if event.keycode == KEY_EQUAL or event.keycode == KEY_KP_ADD:
			zoom_at_screen(get_viewport().get_mouse_position(), zoom_step)
		elif event.keycode == KEY_MINUS or event.keycode == KEY_KP_SUBTRACT:
			zoom_at_screen(get_viewport().get_mouse_position(), -zoom_step)

func apply_zoom(target: float) -> void:
	var z: float = clampf(target, effective_zoom_min(), zoom_max)
	_target_zoom = z
	zoom = Vector2(z, z)
	_clamp_position()

func zoom_at_screen(screen_pos: Vector2, amount: float) -> void:
	var before: float = zoom.x
	var after: float = clampf(before + amount, effective_zoom_min(), zoom_max)
	if is_equal_approx(before, after):
		return
	var from_centre := screen_pos - get_viewport_rect().size * 0.5
	var world_before: Vector2 = position + from_centre / before
	_target_zoom = after
	zoom = Vector2(after, after)
	position = world_before - from_centre / after
	_clamp_position()

func _zoom_by(delta_zoom: float) -> void:
	_target_zoom = clampf(_target_zoom + delta_zoom, zoom_min, zoom_max)

func begin_pan(screen_pos: Vector2) -> void:
	_panning = true
	_pan_last = screen_pos

func pan_drag(screen_pos: Vector2) -> void:
	if not _panning:
		return
	var delta_screen: Vector2 = screen_pos - _pan_last
	_pan_last = screen_pos
	position -= delta_screen / zoom.x
	_clamp_position()

func end_pan() -> void:
	_panning = false

func is_panning() -> bool:
	return _panning

func world_fit_zoom() -> float:
	var vp := get_viewport_rect().size
	if world_size.x <= 0.0 or world_size.y <= 0.0:
		return zoom_min
	return maxf(vp.x / world_size.x, vp.y / world_size.y)

func effective_zoom_min() -> float:
	return maxf(zoom_min, world_fit_zoom())

func _clamp_position() -> void:
	var vp := get_viewport_rect().size
	var fit := world_fit_zoom()
	if zoom.x < fit:
		zoom = Vector2(fit, fit)
		_target_zoom = maxf(_target_zoom, fit)
	var half := vp * 0.5 / zoom.x
	if world_size.x <= half.x * 2.0:
		position.x = world_size.x * 0.5
	else:
		position.x = clampf(position.x, half.x, world_size.x - half.x)
	if world_size.y <= half.y * 2.0:
		position.y = world_size.y * 0.5
	else:
		position.y = clampf(position.y, half.y, world_size.y - half.y)

func add_shake(amount: float) -> void:
	_shake = clampf(maxf(_shake, amount), 0.0, 6.0)

func screen_center() -> Vector2:
	return position
