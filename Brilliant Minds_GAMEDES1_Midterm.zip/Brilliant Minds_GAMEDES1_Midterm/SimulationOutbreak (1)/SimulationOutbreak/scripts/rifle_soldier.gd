extends MilitaryUnitBase

func _ready() -> void:
	def_id = "rifle_soldier"
	super._ready()
