extends Node2D
class_name Effects

const FX := "res://assets/sprites/fx/"
const FONT := "res://assets/fonts/cc_ops_pixel.ttf"

var _font: Font
var _cache: Dictionary = {}

func _ready() -> void:
	z_index = 5
	y_sort_enabled = false
	_font = load(FONT)

func _frames(file: String, anim: String, count: int, fps: float, loop: bool = false) -> SpriteFrames:
	return SpriteLib.sequence_frames(FX + file, anim, count, fps, loop)

func _oneshot(file: String, count: int, fps: float, pos: Vector2, scale_factor: float = 1.0,
		rotation: float = 0.0, offset: Vector2 = Vector2.ZERO) -> AnimatedSprite2D:
	var s := AnimatedSprite2D.new()
	var key := "%s|%d" % [file, count]
	if not _cache.has(key):
		_cache[key] = _frames(file, "fx", count, fps, false)
	s.sprite_frames = _cache[key]
	s.position = pos + offset
	s.rotation = rotation
	s.scale = Vector2(scale_factor, scale_factor)
	add_child(s)
	s.play("fx")
	s.animation_finished.connect(s.queue_free)
	return s

func muzzle(sprite: AnimatedSprite2D, facing: String) -> void:
	if sprite == null:
		return
	var dir: Vector2 = {"up": Vector2(0, -1), "down": Vector2(0, 1),
			"left": Vector2(-1, 0), "right": Vector2(1, 0)}.get(facing, Vector2(1, 0))
	sprite.visible = true
	sprite.position = dir * 14.0 + Vector2(0, -12)
	sprite.rotation = dir.angle()
	sprite.play("fire")
	register_muzzle_auto_hide(sprite)

func register_muzzle_auto_hide(sprite: AnimatedSprite2D) -> void:
	var timer := get_tree().create_timer(0.16)
	timer.timeout.connect(_hide_muzzle.bind(sprite))

func _hide_muzzle(sprite: AnimatedSprite2D) -> void:
	if is_instance_valid(sprite):
		sprite.visible = false

func tracer(from: Vector2, to: Vector2, speed: float = 1400.0,
		colour: Color = Color(1.0, 0.92, 0.55)) -> void:
	var glow := Line2D.new()
	glow.width = 3.0
	glow.default_color = Color(colour.r, colour.g, colour.b, 0.22)
	glow.add_point(from)
	glow.add_point(to)
	add_child(glow)
	var line := Line2D.new()
	line.width = 1.0
	line.default_color = Color(colour.r, colour.g, colour.b, 0.95)
	line.add_point(from)
	line.add_point(to)
	add_child(line)
	var travel := clampf(from.distance_to(to) / maxf(200.0, speed), 0.02, 0.3)
	var tw := create_tween()
	tw.parallel().tween_property(line, "modulate:a", 0.0, 0.09).set_delay(travel)
	tw.parallel().tween_property(glow, "modulate:a", 0.0, 0.09).set_delay(travel)
	tw.tween_callback(line.queue_free)
	GlowFade.fade_out(self, glow, 0.09, travel)
	var timer := get_tree().create_timer(travel)
	timer.timeout.connect(_tracer_impact.bind(to))

class GlowFade:
	static func fade_out(host: Node, line: Line2D, delay: float, wait: float) -> void:
		var t := host.get_tree().create_timer(wait + delay)
		t.timeout.connect(line.queue_free)

func _tracer_impact(to: Vector2) -> void:
	impact_lite(to)
	if randf() < 0.25:
		shell_casing(to)

func impact_lite(pos: Vector2) -> void:
	_oneshot("impact.png", 4, 22.0, pos)

func spark(pos: Vector2, scale_factor: float = 1.0) -> void:
	var s := _oneshot("fx_spark.png", 6, 26.0, pos, scale_factor)
	if s:
		s.z_index = 2

func muzzle_gas(pos: Vector2, dir: Vector2) -> void:
	var s := _oneshot("fx_gas.png", 6, 18.0, pos, 0.7, 0.0)
	if s:
		var tw := create_tween()
		tw.tween_property(s, "position", pos + dir * 14.0 + Vector2(0, -5), 0.35)

func bite_impact(pos: Vector2, facing: String) -> void:
	var rot: float = {"up": -PI * 0.5, "down": PI * 0.5, "right": 0.0, "left": PI}.get(facing, 0.0)
	_oneshot("fx_bite.png", 5, 22.0, pos, 0.85, rot)

func slam(pos: Vector2) -> void:
	_oneshot("fx_slam.png", 6, 20.0, pos, 1.0)
	shake(3.0)

func dust(pos: Vector2) -> void:
	_oneshot("fx_dust.png", 5, 14.0, pos, 1.0)

func blood_burst(pos: Vector2, scale_factor: float = 1.0, rotation: float = 0.0) -> void:
	_oneshot("blood_burst.png", 5, 18.0, pos, scale_factor, rotation)
	if scale_factor > 0.9:
		_oneshot("fx_blood_spray.png", 6, 20.0, pos, scale_factor, rotation)

func smoke(pos: Vector2) -> void:
	_oneshot("smoke.png", 6, 9.0, pos)

func explosion(pos: Vector2) -> void:
	_oneshot("explosion.png", 7, 16.0, pos, 1.4)
	smoke(pos)

func death_puff(pos: Vector2) -> void:
	smoke(pos + Vector2(0, -6))

func shell_casing(pos: Vector2) -> void:
	var tex := SpriteLib.texture(FX + "shell.png")
	if tex == null:
		return
	var s := Sprite2D.new()
	s.texture = tex
	s.position = pos
	s.z_index = 4
	add_child(s)
	var tw := create_tween()
	var target := pos + Vector2(randf_range(-14, 14), randf_range(4, 14))
	tw.tween_property(s, "position", target, 0.25)
	tw.tween_property(s, "modulate:a", 0.0, 0.4)
	tw.tween_callback(s.queue_free)

func move_marker(pos: Vector2) -> void:
	var s := AnimatedSprite2D.new()
	s.sprite_frames = SpriteLib.sequence_frames(FX + "move_marker.png", "fx", 6, 16.0, false)
	s.position = pos
	s.z_index = -2
	add_child(s)
	s.play("fx")
	s.animation_finished.connect(s.queue_free)

func deploy_ping(pos: Vector2) -> void:
	var s := AnimatedSprite2D.new()
	s.sprite_frames = SpriteLib.sequence_frames(FX + "alert_ping.png", "fx", 5, 14.0, false)
	s.position = pos
	s.modulate = Color(0.6, 0.95, 0.8)
	add_child(s)
	s.play("fx")
	s.animation_finished.connect(s.queue_free)

func spawn_ping(pos: Vector2) -> void:
	var s := AnimatedSprite2D.new()
	s.sprite_frames = SpriteLib.sequence_frames(FX + "alert_ping.png", "fx", 5, 12.0, false)
	s.position = pos
	s.modulate = Color(1.0, 0.45, 0.35)
	add_child(s)
	s.play("fx")
	s.animation_finished.connect(s.queue_free)

func floating_text(pos: Vector2, text: String, color: Color = Color.WHITE) -> void:
	var label := Label.new()
	label.text = text
	if _font:
		label.add_theme_font_override("font", _font)
	label.add_theme_font_size_override("font_size", 8)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	label.add_theme_constant_override("shadow_offset_x", 1)
	label.add_theme_constant_override("shadow_offset_y", 1)
	label.position = pos - Vector2(10, 8)
	label.z_index = 8
	add_child(label)
	var tw := create_tween()
	tw.tween_property(label, "position", label.position + Vector2(0, -16), 0.7)
	tw.parallel().tween_property(label, "modulate:a", 0.0, 0.7).set_delay(0.25)
	tw.tween_callback(label.queue_free)

func spawn_warning(edges: Array, positions: Array, seconds: float) -> void:
	for i in positions.size():
		var pos: Vector2 = positions[i]
		var edge := String(edges[i % edges.size()])
		var rot: float = {"n": PI * 0.5, "s": -PI * 0.5, "e": PI, "w": 0.0}.get(edge, 0.0)
		var s := AnimatedSprite2D.new()
		s.sprite_frames = SpriteLib.sequence_frames(FX + "warning_arrows.png", "fx", 6, 9.0, true)
		s.position = pos
		s.rotation = rot
		s.modulate = Color(1, 0.55, 0.4, 0.9)
		s.z_index = 6
		add_child(s)
		s.play("fx")
		var timer := get_tree().create_timer(seconds + 0.4)
		timer.timeout.connect(_fade_out_warning.bind(s))
	if positions.size() > 0:
		shake(2.5)

func _fade_out_warning(s: AnimatedSprite2D) -> void:
	if not is_instance_valid(s):
		return
	var tw := create_tween()
	tw.tween_property(s, "modulate:a", 0.0, 0.3)
	tw.tween_callback(s.queue_free)

func shake(amount: float) -> void:
	if not GameConfig.screen_shake:
		return
	if GameManager.camera and GameManager.camera.has_method("add_shake"):
		GameManager.camera.add_shake(amount)
