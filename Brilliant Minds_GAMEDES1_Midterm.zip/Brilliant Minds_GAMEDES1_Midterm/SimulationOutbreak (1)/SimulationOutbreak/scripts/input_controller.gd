extends Node2D
class_name InputController

signal deploy_mode_changed(active: bool, kind: String, id: String)

var city: CityMap
var camera: CameraController
var world: Node2D

var deploy_kind := ""
var deploy_id := ""
var _ghost: Sprite2D
var _dragging := false
var _drag_mode := ""
var _drag_start := Vector2.ZERO
var _drag_start_world := Vector2.ZERO
var _drag_now := Vector2.ZERO
var _drag_active := false
var _drag_threshold := 6.0
var _last_invalid_reason := ""
var _cursor_world := Vector2.ZERO

func setup(city_map: CityMap, cam: CameraController, world_root: Node2D) -> void:
	city = city_map
	camera = cam
	world = world_root
	z_index = 200
	_drag_threshold = float(GameConfig.balance.get("selection", {}).get("drag_threshold", 12.0))
	_ghost = Sprite2D.new()
	_ghost.visible = false
	_ghost.modulate = Color(0.7, 1.0, 0.8, 0.75)
	_ghost.z_index = 150
	add_child(_ghost)

func _input(event: InputEvent) -> void:
	if GameManager.simulation_over:
		return
	if event is InputEventMouseButton and event.pressed \
			and event.button_index == MOUSE_BUTTON_RIGHT:
		if _over_panel(event.position):
			return
		_handle_right_click(event.position)
		get_viewport().set_input_as_handled()

func _over_panel(screen_pos: Vector2) -> bool:
	for node in [GameManager.ui.deploy_panel_ref(), GameManager.ui.unit_panel_ref()]:
		if node != null and is_instance_valid(node) and node.visible:
			if node.get_global_rect().has_point(screen_pos):
				return true
	return false

func _handle_right_click(screen_pos: Vector2) -> void:
	if deploy_kind != "":
		cancel_deploy()
		return
	var p := _world_at(screen_pos)
	if not GameManager.selected_units.is_empty():
		GameManager.move_selected_to(p)
	elif GameManager.selected_structure != null:
		GameManager.clear_selection()

func _unhandled_input(event: InputEvent) -> void:
	if GameManager.simulation_over:
		return
	if event is InputEventMouseButton:
		_handle_mouse_button(event)
	elif event is InputEventMouseMotion:
		if _dragging and _drag_mode == "pan":
			camera.pan_drag(event.position)
		elif _dragging:
			if event.position.distance_to(_drag_start) > _drag_threshold:
				_drag_active = true
			_drag_now = _world_at(event.position)
			queue_redraw()
	elif event is InputEventKey and event.pressed and not event.echo:
		_handle_key(event)

func _handle_mouse_button(event: InputEventMouseButton) -> void:
	match event.button_index:
		MOUSE_BUTTON_LEFT:
			if event.pressed:
				_drag_start = event.position
				_drag_start_world = _world_at(event.position)
				_drag_now = _drag_start_world
				_dragging = true
				_drag_active = false
				_drag_mode = _drag_intent(_drag_start_world)
				if _drag_mode == "pan":
					camera.begin_pan(event.position)
			else:
				if _dragging:
					var moved: bool = event.position.distance_to(_drag_start) > _drag_threshold
					if _drag_mode == "pan":
						camera.end_pan()
						if not moved:
							_finish_left_click(event.position)
					else:
						_finish_left_click(event.position)
					_dragging = false
					_drag_active = false
					_drag_mode = ""
					queue_redraw()
		MOUSE_BUTTON_MIDDLE:
			if event.pressed:
				_dragging = true
				_drag_mode = "pan"
				_drag_active = false
				_drag_start = event.position
				camera.begin_pan(event.position)
			elif _dragging and _drag_mode == "pan":
				camera.end_pan()
				_dragging = false
				_drag_mode = ""
				queue_redraw()
		MOUSE_BUTTON_RIGHT:
			pass

func _drag_intent(world_pos: Vector2) -> String:
	if deploy_kind != "":
		return "select"
	if Input.is_key_pressed(KEY_SHIFT) or Input.is_key_pressed(KEY_CTRL):
		return "select"
	if _unit_at(world_pos) != null:
		return "select"
	return "pan"

func _world_at(screen_pos: Vector2) -> Vector2:
	return get_viewport().get_canvas_transform().affine_inverse() * screen_pos

func _finish_left_click(screen_pos: Vector2) -> void:
	var mouse_world := _world_at(screen_pos)
	if _drag_active:
		var r := _rect_from(_drag_start_world, _world_at(screen_pos))
		var picked: Array = []
		for u in GameManager.units:
			if u and is_instance_valid(u) and not u.dead and r.has_point(u.global_position):
				picked.append(u)
		var additive := Input.is_key_pressed(KEY_SHIFT)
		if picked.is_empty():
			var anchor := _unit_at(_drag_start_world)
			if anchor != null:
				GameManager.select_units([anchor], additive)
			elif not additive:
				GameManager.clear_selection()
		else:
			GameManager.select_units(picked, additive)
		return
	if deploy_kind != "":
		_try_place(mouse_world)
		return
	var unit := _unit_at(mouse_world)
	if unit != null:
		var shift := Input.is_key_pressed(KEY_SHIFT)
		if shift and GameManager.selected_units.has(unit):
			var rest := GameManager.selected_units.duplicate()
			rest.erase(unit)
			GameManager.select_units(rest)
		else:
			GameManager.select_units([unit], shift)
		Sfx.play("ui_click", -12.0, 0.08)
		return
	var structure := _structure_at(mouse_world)
	if structure != null:
		GameManager.select_structure(structure)
		Sfx.play("ui_click", -12.0, 0.08)
		return
	GameManager.clear_selection()

func _unit_at(p: Vector2) -> MilitaryUnitBase:
	var best: MilitaryUnitBase = null
	var best_d := INF
	for u in GameManager.units:
		if u == null or not is_instance_valid(u) or u.dead:
			continue
		var d: float = u.global_position.distance_to(p)
		var reach := 30.0 if u.def_id != "armored_vehicle" else 40.0
		if d < reach and d < best_d:
			best = u
			best_d = d
	return best

func _structure_at(p: Vector2) -> DefenseStructure:
	for s in GameManager.defenses:
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		if s.global_position.distance_to(p) < 26.0:
			return s
	return null

func _handle_key(event: InputEventKey) -> void:
	match event.keycode:
		KEY_SPACE:
			if not GameManager.simulation_over:
				GameManager.toggle_pause()
			get_viewport().set_input_as_handled()
		KEY_ESCAPE:
			if deploy_kind != "":
				cancel_deploy()
			elif GameManager.selected_units.size() > 0 \
					or GameManager.selected_structure != null:
				GameManager.clear_selection()
			else:
				GameManager.toggle_pause()
		KEY_E:
			GameManager.select_all_units()
		KEY_T:
			GameManager.cycle_speed()
		KEY_1, KEY_2, KEY_3, KEY_4, KEY_5:
			var idx := event.keycode - KEY_1
			if GameManager.ui and GameManager.ui.has_method("deploy_index"):
				GameManager.ui.deploy_index(idx)

func begin_deploy(kind: String, id: String) -> void:
	deploy_kind = kind
	deploy_id = id
	_ghost.visible = true
	var tex: Texture2D = null
	if kind == "unit":
		var sheet := String(GameConfig.unit(id).get("sheet", ""))
		tex = SpriteLib.texture(sheet)
		if tex:
			_ghost.texture = tex
			_ghost.hframes = 4
			_ghost.vframes = 8
			_ghost.frame = 0
			_ghost.offset = Vector2(0, float(GameConfig.unit(id).get("sprite_offset_y", -13)))
			_ghost.scale = Vector2(1, 1)
	else:
		var def := GameConfig.defense(id)
		tex = SpriteLib.texture(String(def.get("turret_sprite", def.get("sprite", "")))
				if float(def.get("damage", 0)) > 0.0 else String(def.get("sprite", "")))
		_ghost.texture = tex
		_ghost.hframes = 1
		_ghost.vframes = 1
		_ghost.frame = 0
		_ghost.offset = Vector2(0, 10)
	deploy_mode_changed.emit(true, kind, id)
	GameManager.feedback.emit("PLACE %s  -  RIGHT CLICK TO CANCEL"
			% String(GameConfig.unit(id).get("name", id) if kind == "unit"
			else GameConfig.defense(id).get("name", id)), "info")

func cancel_deploy() -> void:
	deploy_kind = ""
	deploy_id = ""
	if _ghost:
		_ghost.visible = false
	deploy_mode_changed.emit(false, "", "")

func _try_place(pos: Vector2) -> void:
	var ok: bool = GameManager.request_deploy(deploy_kind, deploy_id, pos)
	if ok:
		var cost := GameManager.gold.unit_cost(deploy_id) if deploy_kind == "unit" \
				else GameManager.gold.defense_cost(deploy_id)
		if not GameManager.gold.can_afford(cost):
			cancel_deploy()
		else:
			var info := GameManager.validate_placement(deploy_kind, deploy_id, pos)
			if not info["ok"]:
				cancel_deploy()
	else:
		cancel_deploy()

func _process(_delta: float) -> void:
	if deploy_kind == "" or _ghost == null:
		return
	_cursor_world = get_global_mouse_position()
	_ghost.position = _cursor_world
	var check: Dictionary = GameManager.validate_placement(deploy_kind, deploy_id, _cursor_world)
	if check["ok"]:
		_ghost.modulate = Color(0.65, 1.0, 0.75, 0.8)
		if _last_invalid_reason != "":
			_last_invalid_reason = ""
			queue_redraw()
		GameManager.selection_validity_changed.emit(true, "")
	else:
		_ghost.modulate = Color(1.0, 0.45, 0.4, 0.75)
		var reason := String(check["reason"])
		if reason != _last_invalid_reason:
			_last_invalid_reason = reason
			GameManager.selection_validity_changed.emit(false, reason)
			queue_redraw()

func _rect_from(a: Vector2, b: Vector2) -> Rect2:
	var p0 := Vector2(minf(a.x, b.x), minf(a.y, b.y))
	return Rect2(p0, Vector2(absf(a.x - b.x), absf(a.y - b.y)))

func _draw() -> void:
	if deploy_kind != "" and _last_invalid_reason != "" and _ghost != null:
		var font: Font = load("res://assets/fonts/cc_ops_pixel.ttf")
		if font:
			var p := _ghost.position + Vector2(18, 8)
			draw_string(font, p + Vector2(1, 1), _last_invalid_reason,
					HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(0, 0, 0, 0.85))
			draw_string(font, p, _last_invalid_reason, HORIZONTAL_ALIGNMENT_LEFT, -1, 8,
					Color(1.0, 0.55, 0.45))
	if _drag_mode == "pan":
		return
	if not _drag_active or not _dragging:
		return
	var a := get_global_mouse_position()
	var r := _rect_from(_drag_start_world, a)
	draw_rect(r, Color(0.4, 0.85, 0.8, 0.10))
	draw_rect(r, Color(0.55, 1.0, 0.95, 0.7), false, 1.0)
