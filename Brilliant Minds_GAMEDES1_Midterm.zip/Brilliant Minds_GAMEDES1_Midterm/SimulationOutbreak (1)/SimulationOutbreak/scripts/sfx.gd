extends Node

const AUDIO_DIR := "res://assets/audio/"
const POOL_SIZE := 18

var _pool: Array[AudioStreamPlayer] = []
var _next := 0
var _streams: Dictionary = {}
var _last_played: Dictionary = {}

var _music: AudioStreamPlayer
var _ambience: AudioStreamPlayer
var _music_name := ""

var camera_position := Vector2.ZERO
var camera_zoom := 1.0
var listening := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_buses()
	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_pool.append(p)
	_music = AudioStreamPlayer.new()
	_music.bus = "Music"
	add_child(_music)
	_ambience = AudioStreamPlayer.new()
	_ambience.bus = "Music"
	add_child(_ambience)
	if has_node("/root/GameConfig"):
		get_node("/root/GameConfig").apply_audio()

func _setup_buses() -> void:
	for bus_name in ["Music", "SFX"]:
		if AudioServer.get_bus_index(bus_name) == -1:
			var idx := AudioServer.bus_count
			AudioServer.add_bus(idx)
			AudioServer.set_bus_name(idx, bus_name)
			AudioServer.set_bus_send(idx, "Master")

func set_bus_volume(bus_name: String, linear: float) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx == -1:
		return
	AudioServer.set_bus_volume_db(idx, linear_to_db(clampf(linear, 0.0001, 1.0)))
	AudioServer.set_bus_mute(idx, linear <= 0.001)

func stream(name: String) -> AudioStream:
	if _streams.has(name):
		return _streams[name]
	var path := AUDIO_DIR + name + ".wav"
	if not ResourceLoader.exists(path):
		push_warning("Missing sound: " + name)
		_streams[name] = null
		return null
	var s: AudioStream = load(path)
	_streams[name] = s
	return s

func play(name: String, volume_db: float = 0.0, pitch_variation: float = 0.08,
		world_position = null, min_interval: float = 0.0) -> void:
	var s := stream(name)
	if s == null:
		return
	if min_interval > 0.0:
		var now := Time.get_ticks_msec() / 1000.0
		if _last_played.has(name) and now - _last_played[name] < min_interval:
			return
		_last_played[name] = now
	var vol := volume_db
	if world_position != null and listening:
		var dist: float = camera_position.distance_to(world_position) / maxf(0.2, camera_zoom)
		vol -= clampf(dist / 34.0, 0.0, 32.0)
		if vol < -34.0:
			return
	var p := _pool[_next]
	_next = (_next + 1) % POOL_SIZE
	p.stream = s
	p.volume_db = vol
	p.pitch_scale = 1.0 + randf_range(-pitch_variation, pitch_variation)
	p.play()

func play_music(name: String) -> void:
	if _music_name == name and _music.playing:
		return
	var s := stream(name)
	if s == null:
		return
	_music_name = name
	_music.stream = s
	_music.volume_db = -4.0
	_music.play()

func stop_music() -> void:
	_music_name = ""
	_music.stop()

func play_ambience(name: String) -> void:
	var s := stream(name)
	if s == null or _ambience.stream == s:
		return
	_ambience.stream = s
	_ambience.volume_db = -10.0
	_ambience.play()

func stop_ambience() -> void:
	_ambience.stop()

func fade_music_out() -> void:
	if _music.playing:
		var tw := create_tween()
		tw.tween_property(_music, "volume_db", -40.0, 0.8)
		tw.tween_callback(_music.stop)
