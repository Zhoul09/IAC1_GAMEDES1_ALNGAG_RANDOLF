extends CharacterBody2D
class_name Zombie

signal killed(zombie: Zombie)
signal bit(target: Node2D, damage: float)

enum St { DORMANT, HUNT, STALK, WINDUP, STRIKE, RECOVER, FEED, DEAD }

var max_hp: float = 32.0
var hp: float = 32.0
var damage: float = 7.0
var move_speed: float = 42.0
var attack_interval: float = 0.9
var reach: float = 20.0
var variant: int = 0
var dead: bool = false
var wave_id: int = 0
var target: Node2D = null
var state: St = St.DORMANT

var sight_range: float = 210.0
var hearing_range: float = 260.0
var raid_point: Vector2 = Vector2.ZERO
var has_raid: bool = false
var _raid_cd: float = 0.0
var _last_known: Vector2 = Vector2.ZERO
var _has_last_known := false
var _alert: float = 0.0

var _path: PackedVector2Array = PackedVector2Array()
var _path_i: int = 0
var _repath_cd: float = 0.0
var _desired: Vector2 = Vector2.ZERO
var _wander_cd: float = 0.0
var _stuck_timer: float = 0.0
var _stuck_count: int = 0
var _frenzy: float = 0.0
var _strafe_t: float = 0.0
var _strafe_dir: float = 1.0
var _last_pos := Vector2.ZERO
var _think_cd: float = 0.0

var _hurt_anim: float = 0.0
var _attack_cd: float = 0.0
var _windup: float = 0.0
var _recover: float = 0.0
var _stagger: float = 0.0
var _leap_cd: float = 0.0
var _howl_cd: float = 0.0
var _feast: float = 0.0

var _sprite: AnimatedSprite2D
var _facing := "down"
var _face_cd := 0.0
var _anim := ""
var _hit_flash := 0.0
var _growl_cd := 0.0
var _rng := RandomNumberGenerator.new()
var _death_frames: SpriteFrames
var _muzzle_blood: bool = false

func _ready() -> void:
	add_to_group("zombies")
	collision_layer = 4
	collision_mask = 1
	_rng.randomize()
	_last_pos = global_position
	_sprite = AnimatedSprite2D.new()
	_sprite.name = "Body"
	variant = _rng.randi_range(0, 2) if variant == 0 else variant
	_sprite.sprite_frames = SpriteLib.character_frames(
			"res://assets/sprites/chars/zombie_%d.png" % variant)
	_sprite.offset = Vector2(0, -13)
	_sprite.play("breath_down")
	add_child(_sprite)
	var col := get_node_or_null("Collision")
	if col:
		col.position = Vector2(0, -6)
	_growl_cd = _rng.randf_range(1.5, 7.0)
	_think_cd = _rng.randf_range(0.0, 0.2)
	_death_frames = SpriteLib.death_frames("res://assets/sprites/chars/zombie_death.png")
	GameManager.register_zombie(self)

func configure(wave: int, stats: Dictionary) -> void:
	wave_id = wave
	max_hp = float(stats.get("hp", 32.0))
	damage = float(stats.get("damage", 7.0))
	move_speed = float(stats.get("speed", 42.0))
	attack_interval = float(stats.get("attack_interval", 0.9))
	match variant:
		1:
			max_hp *= 0.62
			damage *= 0.8
			move_speed *= 1.5
			attack_interval *= 0.85
			sight_range = 300.0
			hearing_range = 340.0
		2:
			max_hp *= 2.1
			damage *= 1.6
			move_speed *= 0.6
			attack_interval *= 1.25
			sight_range = 170.0
			hearing_range = 220.0
	hp = max_hp
	move_speed *= _rng.randf_range(0.93, 1.08)
	attack_interval *= _rng.randf_range(0.9, 1.1)
	state = St.HUNT

func _physics_process(delta: float) -> void:
	_face_cd = maxf(0.0, _face_cd - delta)
	if dead or GameManager.simulation_over or GameManager.paused:
		return
	_attack_cd = maxf(0.0, _attack_cd - delta)
	_repath_cd -= delta
	_wander_cd -= delta
	_think_cd -= delta
	_stagger = maxf(0.0, _stagger - delta)
	_howl_cd = maxf(0.0, _howl_cd - delta)
	if has_raid and state == St.DORMANT:
		_raid_cd -= delta
		if _raid_cd <= 0.0:
			_raid_cd = _rng.randf_range(2.0, 3.5)
			state = St.HUNT
			_repath_cd = 0.0
	_leap_cd = maxf(0.0, _leap_cd - delta)
	_hit_flash = maxf(0.0, _hit_flash - delta)
	if _hit_flash <= 0.0:
		_sprite.modulate = Color.WHITE
	if _hurt_anim > 0.0:
		_hurt_anim = maxf(0.0, _hurt_anim - delta)
		if _hurt_anim <= 0.0:
			_anim = ""
			_set_anim("breath_" + _facing, true)

	_growl(delta)

	if _stagger > 0.0:
		velocity = velocity.lerp(Vector2.ZERO, 10.0 * delta)
		move_and_slide()
		_set_anim(("hurt_" if _hurt_anim > 0.0 else "action_") + _facing)
		return

	if _think_cd <= 0.0:
		_think_cd = _rng.randf_range(0.15, 0.25)
		_perceive()

	match state:
		St.DORMANT: _do_dormant(delta)
		St.HUNT: _do_hunt(delta)
		St.STALK: _do_stalk(delta)
		St.WINDUP: _do_windup(delta)
		St.STRIKE: _do_strike(delta)
		St.RECOVER: _do_recover(delta)
		St.FEED: _do_feed(delta)
		_: pass

func _perceive() -> void:
	var best: Node2D = null
	var best_score := INF
	var candidates: Array = GameManager.agents_near(global_position, sight_range)
	for n in candidates:
		if n == self:
			continue
		var score := INF
		if n is Civilian:
			if n.dead:
				continue
			var crowd := 0
			for m in GameManager.agents_near(n.global_position, 90.0):
				if m is Civilian:
					crowd += 1
			score = global_position.distance_to(n.global_position) * 0.62 - float(crowd) * 14.0
		elif n is MilitaryUnitBase:
			if n.dead:
				continue
			score = global_position.distance_to(n.global_position) * 0.9
		elif n is DefenseStructure:
			if n.dead:
				continue
			score = global_position.distance_to(n.global_position) * 1.3
		else:
			continue
		var d: float = global_position.distance_to(n.global_position)
		var in_cone := d < 78.0 or _in_cone(n.global_position)
		var noisy: bool = (n is MilitaryUnitBase and n.firing_recently()) \
				or (n is Civilian and n.panicking)
		if not in_cone and not (noisy and d < hearing_range):
			continue
		if score < best_score:
			best_score = score
			best = n
	if best != null:
		var new_target := best != target
		target = best
		_last_known = best.global_position
		_has_last_known = true
		_alert = 1.0
		if new_target and _alert < 0.5:
			_howl()
		if state == St.DORMANT or state == St.FEED:
			state = St.HUNT
		return
	_alert = maxf(0.0, _alert - 0.4)
	if target != null and (not is_instance_valid(target) or target.dead):
		target = null
	if target == null and state in [St.HUNT, St.STALK] and _alert <= 0.0:
		_has_last_known = false

func _in_cone(p: Vector2) -> bool:
	var to := p - global_position
	if to.length_squared() < 1.0:
		return true
	var fwd: Vector2 = {"down": Vector2(0, 1), "up": Vector2(0, -1),
			"right": Vector2(1, 0), "left": Vector2(-1, 0)}.get(_facing, Vector2(0, 1))
	return fwd.dot(to.normalized()) > 0.25

func _howl() -> void:
	if _howl_cd > 0.0:
		return
	_howl_cd = _rng.randf_range(7.0, 13.0)
	Sfx.play("zombie_growl_a" if _rng.randf() < 0.5 else "zombie_growl_b",
			-15.0, 0.1, global_position, 0.5)
	for n in GameManager.agents_near(global_position, 300.0):
		if n is Zombie and n != self and not n.dead:
			n.hear(global_position)

func withdraw_straggler() -> void:
	dead = true
	state = St.DEAD
	set_physics_process(false)
	remove_from_group("zombies")
	GameManager.unregister_zombie(self)
	var col := get_node_or_null("Collision")
	if col:
		col.set_deferred("disabled", true)
	if _sprite == null:
		queue_free()
		return
	var tw := create_tween()
	tw.tween_property(_sprite, "modulate:a", 0.0, 0.8)
	tw.parallel().tween_property(_sprite, "position", _sprite.position + Vector2(0, -6), 0.8)
	tw.finished.connect(queue_free)

func set_raid_point(p: Vector2) -> void:
	raid_point = p
	has_raid = true
	_raid_cd = _rng.randf_range(0.0, 1.5)
	hear(p)

func hear(p: Vector2) -> void:
	if dead or state in [St.WINDUP, St.STRIKE]:
		return
	_alert = maxf(_alert, 0.75)
	_last_known = p
	_has_last_known = true
	if state == St.DORMANT:
		state = St.HUNT
		_repath_cd = 0.0

func _do_dormant(delta: float) -> void:
	_mill(delta, 0.45)

func _do_hunt(delta: float) -> void:
	if not _target_alive():
		if has_raid and global_position.distance_to(raid_point) > 36.0:
			_move_to(raid_point, delta, 0.95)
			_face(raid_point)
			_check_stuck(delta)
			if _raid_cd <= 0.0:
				_raid_cd = _rng.randf_range(2.0, 3.5)
			return
		if _has_last_known and global_position.distance_to(_last_known) > 40.0:
			_move_to(_last_known, delta, 0.9)
			return
		state = St.DORMANT
		return
	var d := global_position.distance_to(target.global_position)
	if d <= reach + _target_radius() + 6.0:
		_begin_windup()
		return
	_frenzy = minf(1.0, _frenzy + delta / 5.0)
	var speed_scale := 1.0 + 0.4 * _frenzy
	if variant == 1 and d > 90.0:
		speed_scale = 1.25
	if variant == 2 and d < 190.0:
		speed_scale = 1.15
	_move_to(target.global_position, delta, speed_scale)
	_face(target.global_position)
	_check_stuck(delta)

func _do_stalk(delta: float) -> void:
	var side := (target.global_position - global_position).orthogonal().normalized()
	_move_to(global_position + side * 90.0, delta, 0.7)
	_face(target.global_position)

func _begin_windup() -> void:
	if _attack_cd > 0.0:
		_stop()
		_face(target.global_position)
		return
	state = St.WINDUP
	_windup = 0.42 if variant != 1 else 0.28
	_stop()
	_face(target.global_position)
	_set_anim("action_" + _facing, true)
	Sfx.play("zombie_attack", -16.0, 0.12, global_position, 0.1)

func _do_windup(delta: float) -> void:
	_windup -= delta
	if variant == 1:
		var dir := (target.global_position - global_position).normalized() if _target_alive() else Vector2.ZERO
		velocity = dir * move_speed * 1.6
		move_and_slide()
	if _windup <= 0.0:
		state = St.STRIKE

func _do_strike(_delta: float) -> void:
	velocity = Vector2.ZERO
	if _target_alive() and global_position.distance_to(target.global_position) <= \
			reach + _target_radius() + 14.0:
		_attack(target)
	_attack_cd = attack_interval
	_recover = 0.32
	state = St.RECOVER

func _do_recover(delta: float) -> void:
	_recover -= delta
	_stop()
	if _recover <= 0.0:
		state = St.HUNT if _target_alive() else St.DORMANT
		_set_anim("breath_" + _facing, true)

func _do_feed(delta: float) -> void:
	_feast -= delta
	_stop()
	_set_anim("action_" + _facing)
	if _feast <= 0.0:
		state = St.DORMANT

func _mill(delta: float, scale: float) -> void:
	if _wander_cd <= 0.0 or _path.is_empty():
		_wander_cd = _rng.randf_range(2.0, 4.5)
		var anchor: Vector2 = global_position
		if _has_last_known:
			anchor = _last_known
		var dest := anchor + Vector2(_rng.randf_range(-70, 70), _rng.randf_range(-60, 60))
		dest = GameManager.city.free_cell_near_world(dest, 3)
		_path = GameManager.city.pathfinder.find_path(global_position, dest)
		_path_i = 0
	if _path.is_empty() or _path_i >= _path.size():
		_stop()
		_set_anim("breath_" + _facing, true)
		return
	_follow(delta, scale)

func _move_to(dest: Vector2, delta: float, speed_scale: float) -> void:
	if _repath_cd <= 0.0:
		_repath_cd = _rng.randf_range(0.45, 0.8)
		_path = GameManager.city.pathfinder.find_path(global_position, dest)
		_path_i = 0
		if _path.is_empty():
			_path = PackedVector2Array([dest])
	if _path.is_empty() or _path_i >= _path.size():
		_steer_towards(dest, delta, speed_scale)
		return
	_follow(delta, speed_scale)

func _follow(delta: float, speed_scale: float) -> void:
	var wp: Vector2 = _path[_path_i]
	if global_position.distance_to(wp) < 14.0:
		_path_i += 1
		return
	_steer_towards(wp, delta, speed_scale)

func _steer_towards(dest: Vector2, delta: float, speed_scale: float) -> void:
	var dir := (dest - global_position)
	if dir.length() < 1.0:
		_stop()
		return
	dir = dir.normalized()
	if _strafe_t > 0.0:
		_strafe_t -= delta
		dir = dir.rotated(_strafe_dir * 1.0)
	var sep := _separation()
	var want := move_speed * speed_scale
	var vel := (dir + sep * 0.9).normalized() * want
	velocity = velocity.lerp(vel, clampf(12.0 * delta, 0.0, 1.0))
	move_and_slide()
	_face(global_position + velocity)
	if _strafe_t <= 0.0 and velocity.length() < want * 0.3 and get_slide_collision_count() > 0:
		var pf := GameManager.city.pathfinder if GameManager.city != null else null
		if pf != null:
			var left_ok: bool = pf.walkable_world(global_position + dir.rotated(-1.0) * 26.0)
			var right_ok: bool = pf.walkable_world(global_position + dir.rotated(1.0) * 26.0)
			if left_ok != right_ok:
				_strafe_dir = -1.0 if left_ok else 1.0
			else:
				_strafe_dir = -_strafe_dir
			_strafe_t = 0.55

func _separation() -> Vector2:
	var push := Vector2.ZERO
	for other in GameManager.agents_near(global_position, 34.0):
		if other == self or not (other is Zombie):
			continue
		var d: Vector2 = global_position - other.global_position
		var dist := d.length()
		if dist > 0.1:
			push += d.normalized() * (1.0 - dist / 34.0)
	return push

func _check_stuck(delta: float) -> void:
	if global_position.distance_to(_last_pos) < 1.0:
		_stuck_timer += delta
	else:
		_stuck_timer = 0.0
		_last_pos = global_position
	if _stuck_timer > 1.4:
		_stuck_timer = 0.0
		_repath_cd = 0.0
		_path = PackedVector2Array()
		_stuck_count += 1
		if _stuck_count >= 2:
			_stuck_count = 0
			_push_through()

func _push_through() -> void:
	var dir := (raid_point - global_position).normalized()
	if dir == Vector2.ZERO or GameManager.city == null:
		return
	var pf := GameManager.city.pathfinder
	for step in [40.0, 72.0, 104.0]:
		var probe: Vector2 = pf.nearest_walkable_world(global_position + dir * step, 3)
		if not GameManager.city.is_blocked_world(probe):
			global_position = probe
			_last_pos = probe
			_path = PackedVector2Array()
			_path_i = 0
			_repath_cd = 0.0
			return

func _target_alive() -> bool:
	if target == null or not is_instance_valid(target):
		return false
	if target.get("dead") == true:
		return false
	return true

func _target_radius() -> float:
	if target is MilitaryUnitBase:
		return 6.0 if target.def_id != "armored_vehicle" else 16.0
	if target is DefenseStructure:
		return 18.0
	return 2.0

func _stop() -> void:
	velocity = velocity.lerp(Vector2.ZERO, 0.35)

func _face(p: Vector2) -> void:
	var d := p - global_position
	if _face_cd > 0.0:
		return
	var f := _facing
	if absf(d.x) > absf(d.y) * 1.35:
		f = "right" if d.x > 0 else "left"
	elif absf(d.y) > absf(d.x) * 1.35:
		f = "down" if d.y > 0 else "up"
	else:
		return
	if f != _facing:
		_face_cd = 0.14
	if f != _facing:
		_facing = f
		if _anim.begins_with("breath_"):
			_set_anim("breath_" + _facing, true)

func _set_anim(anim_name: String, restart: bool = false) -> void:
	if anim_name == _anim and not restart:
		return
	_anim = anim_name
	if _sprite.sprite_frames.has_animation(anim_name):
		_sprite.play(anim_name)

func _attack(t: Node2D) -> void:
	_frenzy = 0.0
	if not is_instance_valid(t):
		return
	Sfx.play("zombie_attack", -13.0, 0.15, global_position, 0.08)
	GameManager.fx.bite_impact(t.global_position + Vector2(0, -10), _facing)
	bit.emit(t, damage)
	if t.has_method("take_damage"):
		t.take_damage(damage, self)
	if variant == 2 and t is MilitaryUnitBase and is_instance_valid(t):
		t.apply_knockback((t.global_position - global_position).normalized() * 26.0)
	if t is Civilian and is_instance_valid(t) and t.get("dead") == true:
		state = St.FEED
		_feast = _rng.randf_range(1.6, 3.0)

func apply_knockback(v: Vector2) -> void:
	if dead:
		return
	global_position += v
	_stagger = maxf(_stagger, 0.18)

func take_damage(amount: float, source: Node = null) -> void:
	if dead:
		return
	hp -= amount
	_hit_flash = 0.09
	_sprite.modulate = Color(1.7, 1.25, 1.25)
	GameManager.fx.blood_burst(global_position + Vector2(0, -12),
			0.7 if amount < 20.0 else 1.0, _rng.randf_range(0, TAU))
	var flinch := clampf(amount / 22.0, 0.12, 0.4)
	_stagger = maxf(_stagger, flinch)
	_hurt_anim = maxf(_hurt_anim, flinch + 0.08)
	if state == St.WINDUP:
		state = St.RECOVER
		_recover = 0.2
	if _rng.randf() < 0.55:
		hear(global_position + Vector2(_rng.randf_range(-40, 40), _rng.randf_range(-40, 40)))
	if source != null and is_instance_valid(source) and source is Node2D:
		if _alert <= 0.0:
			hear(source.global_position)
	if hp <= 0.0:
		_die()

func _die() -> void:
	if dead:
		return
	dead = true
	state = St.DEAD
	velocity = Vector2.ZERO
	set_physics_process(false)
	remove_from_group("zombies")
	var col := get_node_or_null("Collision")
	if col:
		col.set_deferred("disabled", true)
	Sfx.play("zombie_death_a" if _rng.randf() < 0.5 else "zombie_death_b", -8.0, 0.1,
			global_position)
	GameManager.city.add_blood_decal(global_position)
	GameManager.city.add_blood_decal(global_position + Vector2(_rng.randf_range(-10, 10), 0))
	GameManager.fx.death_puff(global_position)
	GameManager.fx.dust(global_position)
	GameManager.fx.shake(0.9)
	if _sprite:
		_sprite.sprite_frames = _death_frames
		_sprite.play("death")
		var tw := create_tween()
		tw.tween_property(_sprite, "modulate", Color(1, 1, 1, 0.0), 0.55).set_delay(0.5)
	for n in GameManager.agents_near(global_position, 220.0):
		if n is Zombie and n != self and not n.dead:
			n.hear(global_position)
	killed.emit(self)
	GameManager.on_zombie_died(self)
	await get_tree().create_timer(1.05).timeout
	queue_free()

func _growl(delta: float) -> void:
	_growl_cd -= delta
	if _growl_cd > 0.0:
		return
	_growl_cd = _rng.randf_range(4.0, 12.0)
	if state == St.DORMANT:
		return
	Sfx.play("zombie_growl_a" if _rng.randf() < 0.5 else "zombie_growl_b",
			-21.0, 0.14, global_position, 0.45)
