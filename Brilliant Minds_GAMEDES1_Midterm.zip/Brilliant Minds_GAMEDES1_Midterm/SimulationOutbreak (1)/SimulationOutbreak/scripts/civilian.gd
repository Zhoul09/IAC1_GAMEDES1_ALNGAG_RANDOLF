extends CharacterBody2D
class_name Civilian

signal killed(civilian: Civilian)

enum St { WANDER, ALERT, FLEE, COWER, HUDDLE, DEAD }

var group_id: String = "C1"
var variant: int = 0
var max_hp: float = 26.0
var hp: float = 26.0
var move_speed: float = 58.0
var dead: bool = false
var panicking := false
var state: St = St.WANDER

var nerve: float = 0.5
var sight_range: float = 118.0

var _sprite: AnimatedSprite2D
var _home: Vector2
var _threat: Node2D = null
var _threat_pos := Vector2.ZERO
var _path: PackedVector2Array = PackedVector2Array()
var _path_i := 0
var _think_cd := 0.0
var _idle_cd := 0.0
var _repath_cd := 0.0
var _facing := "down"
var _hurt_anim: float = 0.0
var stamina: float = 100.0
const STAMINA_MAX := 100.0
const STAMINA_DRAIN := 15.0
const STAMINA_REGEN := 9.0
var _anim := ""
var _rng := RandomNumberGenerator.new()
var _scream_cd := 0.0
var _hit_flash := 0.0
var _cower := 0.0
var _settle := 0.0
var _face_cd := 0.0
var _huddle_spot := Vector2.ZERO
var _huddle_cd := 0.0
var _huddling := false

func _ready() -> void:
	add_to_group("civilians")
	collision_layer = 8
	collision_mask = 1
	_rng.randomize()
	_home = global_position
	nerve = _rng.randf_range(0.15, 0.95)
	move_speed = _rng.randf_range(0.88, 1.12) * float(GameConfig.balance_setting("population", "civilian_speed", 58.0))
	_sprite = AnimatedSprite2D.new()
	_sprite.sprite_frames = SpriteLib.character_frames(
			"res://assets/sprites/chars/civilian_%d.png" % variant)
	_sprite.offset = Vector2(0, -13)
	_sprite.play("breath_down")
	add_child(_sprite)
	var col := get_node_or_null("Collision")
	if col:
		col.position = Vector2(0, -6)
	_idle_cd = _rng.randf_range(0.5, 3.5)
	_think_cd = _rng.randf_range(0.0, 0.3)
	_scream_cd = _rng.randf_range(2.0, 8.0)
	GameManager.register_civilian(self)

func _physics_process(delta: float) -> void:
	if dead or GameManager.simulation_over or GameManager.paused:
		return
	_think_cd -= delta
	_idle_cd -= delta
	_repath_cd -= delta
	_scream_cd -= delta
	_face_cd = maxf(0.0, _face_cd - delta)
	_hit_flash = maxf(0.0, _hit_flash - delta)
	if _hit_flash <= 0.0:
		_sprite.modulate = Color.WHITE
	if state == St.FLEE:
		stamina = maxf(0.0, stamina - STAMINA_DRAIN * delta)
	else:
		stamina = minf(STAMINA_MAX, stamina + STAMINA_REGEN * delta)
	if _hurt_anim > 0.0:
		_hurt_anim = maxf(0.0, _hurt_anim - delta)
		if _hurt_anim <= 0.0:
			_anim = ""

	if _think_cd <= 0.0:
		_think_cd = _rng.randf_range(0.3, 0.45)
		_think()

	match state:
		St.WANDER: _do_wander(delta)
		St.ALERT: _do_alert(delta)
		St.FLEE: _do_flee(delta)
		St.COWER: _do_cower(delta)
		St.HUDDLE: _do_huddle(delta)
		_: _brake(delta)

func _think() -> void:
	var z := GameManager.nearest_zombie(global_position, sight_range)
	_threat = z
	if z != null:
		_threat_pos = z.global_position
		var d: float = global_position.distance_to(z.global_position)
		if state == St.WANDER or state == St.HUDDLE:
			if d < 56.0 or (nerve < 0.3 and d < 90.0):
				_start_flee()
			else:
				state = St.ALERT
		if state != St.FLEE and d < 62.0:
			_start_flee()
		panicking = true
		return
	if state == St.FLEE:
		_settle = _rng.randf_range(0.6, 1.6)
		state = St.COWER
		panicking = false
		return
	if state == St.ALERT:
		state = St.WANDER
		panicking = false
	var u := GameManager.nearest_unit(global_position, 190.0)
	if u != null and not u.dead and state == St.WANDER:
		state = St.HUDDLE
		_path = PackedVector2Array()
	elif state == St.HUDDLE:
		if u == null or u.dead:
			state = St.WANDER
	panicking = false

func hear_scream(p: Vector2) -> void:
	if dead:
		return
	_threat_pos = p
	if state in [St.WANDER, St.HUDDLE]:
		if nerve < 0.75:
			_start_flee()
		else:
			state = St.ALERT
	elif state == St.COWER:
		_start_flee()

func _start_flee() -> void:
	if state == St.FLEE:
		return
	state = St.FLEE
	panicking = true
	_path = PackedVector2Array()
	_repath_cd = 0.0
	_scream()

func _scream() -> void:
	if _scream_cd > 0.0:
		return
	_scream_cd = _rng.randf_range(2.5, 6.0)
	Sfx.play("civilian_scream_a" if _rng.randf() < 0.5 else "civilian_scream_b",
			-16.0, 0.12, global_position, 0.3)
	for n in GameManager.agents_near(global_position, 170.0):
		if n is Civilian and n != self and not n.dead:
			n.hear_scream(global_position)
		elif n is Zombie and not n.dead:
			n.hear(global_position)

func _do_wander(delta: float) -> void:
	if _path.is_empty() or _path_i >= _path.size():
		_brake(delta)
		_set_anim("breath_" + _facing)
		if _idle_cd <= 0.0:
			_idle_cd = _rng.randf_range(2.5, 6.5)
			_wander_step()
		return
	_follow(delta, 1.0, "walk_")

func _do_alert(delta: float) -> void:
	_brake(delta)
	if _threat != null and is_instance_valid(_threat):
		_face(_threat.global_position - global_position)
	_set_anim("action_" + _facing)

func _do_flee(delta: float) -> void:
	var spent := stamina <= 1.0
	if _repath_cd <= 0.0 or _path.is_empty() or _path_i >= _path.size():
		_repath_cd = _rng.randf_range(0.5, 1.0)
		_pick_escape()
	if _path.is_empty():
		var away := (global_position - _threat_pos).normalized()
		velocity = away * move_speed * (0.6 if spent else 1.15)
		move_and_slide()
		_face(velocity)
		_set_anim(("walk_" if spent else "run_") + _facing)
		return
	if spent:
		_follow(delta, 0.55, "walk_")
	else:
		_follow(delta, 1.28, "run_")

func _do_cower(delta: float) -> void:
	_brake(delta)
	_set_anim("action_" + _facing)
	_settle -= delta
	if _settle <= 0.0 and _threat == null:
		state = St.WANDER
		_home = global_position

func _do_huddle(delta: float) -> void:
	var u := GameManager.nearest_unit(global_position, 190.0)
	if u == null or u.dead:
		state = St.WANDER
		return
	_huddle_cd -= delta
	if _huddle_spot == Vector2.ZERO or _huddle_cd <= 0.0 \
			or _huddle_spot.distance_to(u.global_position) > 60.0:
		_huddle_cd = _rng.randf_range(1.6, 3.2)
		_huddle_spot = u.global_position + Vector2(
				_rng.randf_range(-34, 34), _rng.randf_range(20, 40))
		_huddle_spot = GameManager.city.free_cell_near_world(_huddle_spot, 2)
	var d := global_position.distance_to(_huddle_spot)
	if d > 30.0:
		_huddling = true
	elif d < 14.0:
		_huddling = false
	if _huddling:
		_move_direct(_huddle_spot, delta, 0.75)
		_set_anim("walk_" + _facing)
	else:
		_brake(delta)
		_face(u.global_position - global_position)
		_set_anim("breath_" + _facing)

func _pick_escape() -> void:
	var best_score := -INF
	var best := Vector2.ZERO
	var found := false
	for k in 7:
		var ang := (global_position - _threat_pos).angle() + _rng.randf_range(-1.1, 1.1)
		var dist := _rng.randf_range(120.0, 210.0)
		var cand: Vector2 = global_position + Vector2(cos(ang), sin(ang)) * dist
		cand = GameManager.city.clamp_to_world(cand)
		cand = GameManager.city.free_cell_near_world(cand, 4)
		if GameManager.city.is_blocked_world(cand):
			continue
		var score: float = cand.distance_to(_threat_pos) - cand.distance_to(global_position) * 0.25
		for n in GameManager.agents_near(cand, 60.0):
			if n is Civilian:
				score -= 22.0
		if GameManager.city.pathfinder.line_of_sight(global_position, cand):
			score += 60.0
		if score > best_score:
			best_score = score
			best = cand
			found = true
	if not found:
		_path = PackedVector2Array()
		return
	var p := GameManager.city.pathfinder.find_path(global_position, best)
	_path = p if p.size() > 0 else PackedVector2Array([best])
	_path_i = 0

func _wander_step() -> void:
	var dest: Vector2 = _home + Vector2(_rng.randf_range(-120, 120), _rng.randf_range(-100, 100))
	dest = GameManager.city.free_cell_near_world(dest, 2)
	_path = GameManager.city.pathfinder.find_path(global_position, dest)
	_path_i = 0

func _follow(delta: float, speed_scale: float, anim_prefix: String) -> void:
	var wp: Vector2 = _path[_path_i]
	if global_position.distance_to(wp) < 11.0:
		_path_i += 1
		if _path_i >= _path.size():
			_path = PackedVector2Array()
		return
	var sep := _separation()
	var dir := ((wp - global_position).normalized() + sep * 1.35).normalized()
	velocity = velocity.lerp(dir * move_speed * speed_scale, clampf(14.0 * delta, 0.0, 1.0))
	move_and_slide()
	_face(velocity)
	_set_anim(anim_prefix + _facing)

func _move_direct(dest: Vector2, delta: float, speed_scale: float) -> void:
	var dir := (dest - global_position)
	if dir.length() < 1.0:
		return
	velocity = velocity.lerp(dir.normalized() * move_speed * speed_scale,
			clampf(16.0 * delta, 0.0, 1.0))
	move_and_slide()
	_face(velocity)

func _separation() -> Vector2:
	var push := Vector2.ZERO
	for n in GameManager.agents_near(global_position, 46.0):
		if n == self:
			continue
		if not (n is Civilian or n is MilitaryUnitBase or n is Zombie):
			continue
		var d: Vector2 = global_position - n.global_position
		var dist := d.length()
		if dist > 0.1:
			push += d.normalized() * (1.0 - dist / 46.0) * 1.6
	return push

func _brake(delta: float) -> void:
	velocity = velocity.lerp(Vector2.ZERO, clampf(14.0 * delta, 0.0, 1.0))
	if velocity.length() > 4.0:
		move_and_slide()

func _face(v: Vector2) -> void:

	if v.length_squared() < 36.0:
		return
	if _face_cd > 0.0:
		return
	var want: String
	if absf(v.x) > absf(v.y) * 1.35:
		want = "right" if v.x > 0 else "left"
	elif absf(v.y) > absf(v.x) * 1.35:
		want = "down" if v.y > 0 else "up"
	else:
		return
	if want != _facing:
		_facing = want
		_face_cd = 0.14

func _set_anim(a: String, restart: bool = false) -> void:
	if _hurt_anim > 0.0 and not a.begins_with("hurt_"):
		return
	if a == _anim and not restart:
		return
	_anim = a
	if _sprite.sprite_frames.has_animation(a):
		_sprite.play(a)

func take_damage(amount: float, _source: Node = null) -> void:
	if dead:
		return
	hp -= amount
	_hit_flash = 0.08
	_hurt_anim = 0.34
	_sprite.modulate = Color(1.6, 0.8, 0.8)
	if _sprite.sprite_frames != null and _sprite.sprite_frames.has_animation("hurt_" + _facing):
		_set_anim("hurt_" + _facing, true)
	GameManager.fx.blood_burst(global_position + Vector2(0, -12), 0.6)
	_start_flee()
	_scream_cd = 0.0
	_scream()
	if hp <= 0.0:
		_die()

func _die() -> void:
	if dead:
		return
	dead = true
	state = St.DEAD
	velocity = Vector2.ZERO
	set_physics_process(false)
	remove_from_group("civilians")
	var col := get_node_or_null("Collision")
	if col:
		col.set_deferred("disabled", true)
	Sfx.play("civilian_scream_a", -10.0, 0.12, global_position, 0.2)
	GameManager.city.add_blood_decal(global_position)
	GameManager.fx.death_puff(global_position)
	var body := Sprite2D.new()
	body.texture = SpriteLib.texture("res://assets/sprites/chars/civilian_body.png")
	body.centered = true
	if body.texture:
		body.hframes = 2
		body.frame = _rng.randi_range(0, 1)
		body.offset = Vector2(0, -10)
	body.position = global_position
	body.z_index = -1
	GameManager.world_root.add_child(body)
	killed.emit(self)
	GameManager.on_civilian_died(self)
	queue_free()

func health_ratio() -> float:
	return hp / max_hp
