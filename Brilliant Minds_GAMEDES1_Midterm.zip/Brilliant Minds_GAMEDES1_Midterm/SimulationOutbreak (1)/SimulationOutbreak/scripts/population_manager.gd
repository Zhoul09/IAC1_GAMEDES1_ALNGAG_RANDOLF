extends Node
class_name PopulationManager

signal population_changed(remaining: int, total: int)
signal civilian_lost(group_id: String, remaining: int)

var initial: int = 100
var remaining: int = 100
var lost: int = 0
var group_initial: Dictionary = {}
var group_remaining: Dictionary = {}

func reset() -> void:
	initial = int(GameConfig.pop_setting("initial_civilians", 100.0))
	remaining = initial
	lost = 0
	group_initial = {}
	group_remaining = {}
	var groups: Dictionary = GameConfig.balance.get("population", {}).get("groups", {})
	for g in groups.keys():
		group_initial[g] = int(groups[g])
		group_remaining[g] = int(groups[g])
	population_changed.emit(remaining, initial)

func register(group_id: String) -> void:
	if not group_remaining.has(group_id):
		group_remaining[group_id] = 0
		group_initial[group_id] = 0

func civilian_died(group_id: String) -> void:
	if remaining <= 0:
		return
	remaining = maxi(0, remaining - 1)
	lost += 1
	if group_remaining.has(group_id):
		group_remaining[group_id] = maxi(0, int(group_remaining[group_id]) - 1)
	population_changed.emit(remaining, initial)
	civilian_lost.emit(group_id, remaining)

func survival_ratio() -> float:
	return float(remaining) / float(maxi(1, initial))

func summary() -> String:
	return "%d/%d" % [remaining, initial]
