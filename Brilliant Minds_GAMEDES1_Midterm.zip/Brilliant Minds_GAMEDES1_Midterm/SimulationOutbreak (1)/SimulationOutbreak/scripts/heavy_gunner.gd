extends MilitaryUnitBase

func _ready() -> void:
	def_id = "heavy_gunner"
	super._ready()
