extends Node2D
class_name NightLighting

const LIGHT_POOL := "res://assets/sprites/fx/light_pool.png"
const LAMP_CORE := "res://assets/sprites/fx/lamp_core.png"
const FOG := "res://assets/sprites/fx/fog.png"

const NIGHT_TINT := Color(0.78, 0.82, 0.92)

var _lamp_lights: Array[PointLight2D] = []
var _lamp_phases: Array[float] = []
var _lamp_energy: Array[float] = []
var _fog_sprites: Array[Sprite2D] = []
var _district_dim := {"C1": 1.0, "C2": 1.0, "C3": 1.0}
var _time := 0.0
var canvas: CanvasModulate

func setup(world: Node2D, city: CityMap) -> void:
	name = "NightLighting"
	canvas = CanvasModulate.new()
	canvas.name = "NightTint"
	canvas.color = NIGHT_TINT
	add_child(canvas)

	var tex_pool := SpriteLib.texture(LIGHT_POOL)
	var tex_core := SpriteLib.texture(LAMP_CORE)
	var rng := RandomNumberGenerator.new()
	rng.seed = 90210

	var budget := int(GameConfig.balance_setting("atmosphere", "light_budget", 16))
	var lamps: Array = city.lamp_positions.duplicate()
	var stride: int = maxi(1, int(ceil(float(lamps.size()) / maxf(1.0, float(budget)))))
	var picked: Array = []
	for i in lamps.size():
		if i % stride == 0:
			picked.append(lamps[i])
	if picked.size() > budget:
		picked = picked.slice(0, budget)
	for lamp in picked:
		var head: Vector2 = (lamp["pos"] as Vector2) + Vector2(0, -54)
		var broken: bool = bool(lamp.get("broken", false))
		var core := Sprite2D.new()
		core.texture = tex_core
		core.modulate = Color(1.0, 0.72, 0.38, 0.85 if not broken else 0.30)
		core.position = head
		core.scale = Vector2(0.34, 0.34)
		core.z_index = 6
		add_child(core)
		var light := PointLight2D.new()
		light.texture = tex_pool
		light.color = Color(1.0, 0.78, 0.48) if not broken else Color(0.72, 0.42, 0.22)
		light.energy = 0.0 if broken else float(GameConfig.balance_setting("atmosphere", "lamp_energy", 2.6))
		light.texture_scale = float(GameConfig.balance_setting("atmosphere", "lamp_scale", 2.6))
		light.position = head
		light.shadow_enabled = false
		add_child(light)
		_lamp_lights.append(light)
		_lamp_energy.append(light.energy)
		_lamp_phases.append(rng.randf_range(0.0, TAU))
		if broken:
			_lamp_energy[-1] = 0.9

	for e in city.emergency_positions:
		var lm := PointLight2D.new()
		lm.texture = tex_pool
		var is_red: bool = String(e["kind"]) == "red"
		lm.color = Color(1.0, 0.35, 0.30) if is_red else Color(0.45, 0.75, 1.0)
		lm.energy = 1.6 if is_red else 1.1
		lm.texture_scale = 1.8 if is_red else 1.6
		lm.position = (e["pos"] as Vector2) + Vector2(0, -24 if is_red else -36)
		add_child(lm)

	var tex_fog := SpriteLib.texture(FOG)
	for i in int(GameConfig.balance_setting("atmosphere", "fog_banks", 2)):
		var fog := Sprite2D.new()
		fog.texture = tex_fog
		fog.centered = true
		fog.modulate = Color(0.65, 0.74, 0.92, 0.10)
		fog.scale = Vector2(5.0, 3.6)
		fog.z_index = 20
		fog.position = Vector2(city.world_size.x * rng.randf_range(0.15, 0.85),
				city.world_size.y * rng.randf_range(0.15, 0.85))
		add_child(fog)
		_fog_sprites.append(fog)

	GameManager.population.population_changed.connect(_on_population_changed)

func _process(delta: float) -> void:
	_time += delta
	for i in _lamp_lights.size():
		var light := _lamp_lights[i]
		if not is_instance_valid(light) or light.energy <= 0.01:
			continue
		var ph := _lamp_phases[i]
		var base := _lamp_energy[i]
		var flick := 0.94 + 0.06 * sin(_time * 2.1 + ph) + 0.03 * sin(_time * 7.3 + ph * 2.0)
		if fmod(_time + ph, 11.0) < 0.12:
			flick *= 0.25
		light.energy = base * flick
	for fog in _fog_sprites:
		if not is_instance_valid(fog):
			continue
		fog.position.x += delta * 5.0
		if fog.position.x > GameManager.city.world_size.x + 400.0:
			fog.position.x = -400.0
		fog.modulate.a = 0.08 + 0.035 * sin(_time * 0.4 + fog.position.y)

func _on_population_changed(remaining: int, total: int) -> void:
	var ratio := clampf(float(remaining) / maxf(1.0, float(total)), 0.0, 1.0)
	if canvas:
		canvas.color = NIGHT_TINT.lerp(Color(0.34, 0.36, 0.46), 1.0 - ratio)

func dim_district(_group_id: String) -> void:
	pass
