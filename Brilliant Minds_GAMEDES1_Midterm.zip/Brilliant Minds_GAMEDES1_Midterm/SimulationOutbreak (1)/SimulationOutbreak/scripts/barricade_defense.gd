extends DefenseStructure

func _ready() -> void:
	if def_id == "":
		def_id = "barricade"
	def = GameConfig.defense(def_id)
	super._ready()
