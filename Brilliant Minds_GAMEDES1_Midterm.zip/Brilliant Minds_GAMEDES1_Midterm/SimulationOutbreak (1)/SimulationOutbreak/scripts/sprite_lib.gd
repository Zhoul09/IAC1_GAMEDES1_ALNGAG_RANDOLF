extends Node

const DIRS := ["down", "up", "right", "left"]
const ROW_IDLE_A := 0
const ROW_IDLE_B := 1
const ROW_WALK_A := 2
const ROW_WALK_B := 3
const ROW_ACTION := 4
const ROW_ACTION_B := 5
const ROW_HURT_A := 6
const ROW_HURT_B := 7

var _frames_cache: Dictionary = {}
var _tex_cache: Dictionary = {}
var _muzzle_cache: Dictionary = {}
var _atlas_cache: Dictionary = {}
const MUZZLE_MANIFEST := "res://assets/sprites/chars/muzzle_offsets.json"

func texture(path: String) -> Texture2D:
	if _tex_cache.has(path):
		return _tex_cache[path]
	var tex: Texture2D = load(path)
	if tex == null:
		push_error("Missing texture: %s" % path)
		return null
	_tex_cache[path] = tex
	return tex

func _cell_tex(tex: Texture2D, cw: int, ch: int, index: int, cols: int = 4) -> AtlasTexture:
	var key := "%s|%dx%d|%d|%d" % [tex.resource_path, cw, ch, cols, index]
	if _atlas_cache.has(key):
		return _atlas_cache[key]
	var at := AtlasTexture.new()
	at.atlas = tex
	at.region = Rect2((index % cols) * cw, int(index / cols) * ch, cw, ch)
	at.filter_clip = true
	_atlas_cache[key] = at
	return at

func _clip(sf: SpriteFrames, anim: String, tex: Texture2D, rows: Array,
		fps: float, loop: bool) -> void:
	var cell := int(tex.get_width() / 4)
	sf.add_animation(anim)
	for d in DIRS.size():
		for r in rows:
			sf.add_frame(anim, _cell_tex(tex, cell, cell, int(r) * 4 + d), 1.0)
	sf.set_animation_speed(anim, fps)
	sf.set_animation_loop(anim, loop)

func character_frames(sheet_path: String) -> SpriteFrames:
	var key := "char|" + sheet_path
	if _frames_cache.has(key):
		return _frames_cache[key]
	var tex := texture(sheet_path)
	if tex == null:
		return null
	var cell := tex.get_width() / 4
	var rows := int(tex.get_height() / maxf(1.0, float(cell)))
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	for c in DIRS.size():
		var d: String = DIRS[c]
		sf.add_animation("idle_" + d)
		sf.add_frame("idle_" + d, _cell_tex(tex, cell, cell, ROW_IDLE_A * 4 + c), 1.0)
		sf.set_animation_speed("idle_" + d, 1.0)
		sf.set_animation_loop("idle_" + d, false)
		sf.add_animation("breath_" + d)
		sf.add_frame("breath_" + d, _cell_tex(tex, cell, cell, ROW_IDLE_A * 4 + c), 1.0)
		sf.add_frame("breath_" + d, _cell_tex(tex, cell, cell, ROW_IDLE_B * 4 + c), 1.0)
		sf.set_animation_speed("breath_" + d, 1.2)
		sf.set_animation_loop("breath_" + d, true)
		sf.add_animation("action_" + d)
		sf.add_frame("action_" + d, _cell_tex(tex, cell, cell, ROW_ACTION * 4 + c), 1.0)
		if rows >= 6:
			sf.add_frame("action_" + d, _cell_tex(tex, cell, cell, ROW_ACTION_B * 4 + c), 1.0)
		sf.set_animation_speed("action_" + d, 14.0)
		sf.set_animation_loop("action_" + d, false)
		if rows >= 8:
			sf.add_animation("hurt_" + d)
			sf.add_frame("hurt_" + d, _cell_tex(tex, cell, cell, ROW_HURT_A * 4 + c), 1.0)
			sf.add_frame("hurt_" + d, _cell_tex(tex, cell, cell, ROW_HURT_B * 4 + c), 1.0)
			sf.set_animation_speed("hurt_" + d, 16.0)
			sf.set_animation_loop("hurt_" + d, false)
	for c in DIRS.size():
		var d2: String = DIRS[c]
		sf.add_animation("walk_" + d2)
		sf.add_frame("walk_" + d2, _cell_tex(tex, cell, cell, ROW_WALK_A * 4 + c), 1.0)
		sf.add_frame("walk_" + d2, _cell_tex(tex, cell, cell, ROW_WALK_B * 4 + c), 1.0)
		sf.set_animation_speed("walk_" + d2, 7.0)
		sf.set_animation_loop("walk_" + d2, true)
		sf.add_animation("run_" + d2)
		sf.add_frame("run_" + d2, _cell_tex(tex, cell, cell, ROW_WALK_A * 4 + c), 1.0)
		sf.add_frame("run_" + d2, _cell_tex(tex, cell, cell, ROW_WALK_B * 4 + c), 1.0)
		sf.set_animation_speed("run_" + d2, 13.0)
		sf.set_animation_loop("run_" + d2, true)
	_frames_cache[key] = sf
	return sf

func muzzle_offsets(sheet_path: String) -> Dictionary:
	var key := sheet_path.get_file()
	if _muzzle_cache.has(key):
		return _muzzle_cache[key]
	var table := {}
	if FileAccess.file_exists(MUZZLE_MANIFEST):
		var f := FileAccess.open(MUZZLE_MANIFEST, FileAccess.READ)
		var parsed: Variant = JSON.parse_string(f.get_as_text())
		if parsed is Dictionary:
			table = parsed
	_muzzle_cache[key] = table
	return table

func muzzle_offset(sheet_path: String, facing: String, fallback: Vector2) -> Vector2:
	var table := muzzle_offsets(sheet_path)
	var entry: Variant = table.get(sheet_path.get_file(), null)
	if entry is Dictionary and entry.has(facing):
		var v: Array = entry[facing]
		if v.size() >= 2:
			return Vector2(float(v[0]), float(v[1]))
	return fallback

func sequence_frames(sheet_path: String, anim_name: String, count: int,
		fps: float = 10.0, loop: bool = false) -> SpriteFrames:
	var key := "%s|%s|%d" % [sheet_path, anim_name, count]
	if _frames_cache.has(key):
		return _frames_cache[key]
	var tex := texture(sheet_path)
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	sf.add_animation(anim_name)
	var cw := maxi(1, int(tex.get_width() / maxi(1, count)))
	var ch := int(tex.get_height())
	for i in count:
		sf.add_frame(anim_name, _cell_tex(tex, cw, ch, i, maxi(1, count)), 1.0)
	sf.set_animation_speed(anim_name, fps)
	sf.set_animation_loop(anim_name, loop)
	_frames_cache[key] = sf
	return sf

func death_frames(sheet_path: String, fps: float = 9.0) -> SpriteFrames:
	var key := "death|" + sheet_path
	if _frames_cache.has(key):
		return _frames_cache[key]
	var tex := texture(sheet_path)
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	sf.add_animation("death")
	var count := int(tex.get_width() / 48)
	for i in count:
		sf.add_frame("death", _cell_tex(tex, 48, 48, i, count), 1.0)
	sf.set_animation_speed("death", fps)
	sf.set_animation_loop("death", false)
	_frames_cache[key] = sf
	return sf
