extends Node
class_name Crowd

const CELL := 64.0

var _buckets: Dictionary = {}
var _built_for: int = -1

func rebuild() -> void:
	_buckets.clear()
	_bin(GameManager.zombies)
	_bin(GameManager.civilians)
	_bin(GameManager.units)
	_bin(GameManager.defenses)

func _bin(list: Array) -> void:
	for n in list:
		if n == null or not is_instance_valid(n):
			continue
		if n.get("dead") == true:
			continue
		var p: Vector2 = n.global_position
		var key := Vector2i(int(floor(p.x / CELL)), int(floor(p.y / CELL)))
		if not _buckets.has(key):
			_buckets[key] = []
		(_buckets[key] as Array).append(n)

func near(pos: Vector2, radius: float) -> Array:
	var out: Array = []
	var r := int(ceil(radius / CELL))
	var base := Vector2i(int(floor(pos.x / CELL)), int(floor(pos.y / CELL)))
	for dy in range(-r, r + 1):
		for dx in range(-r, r + 1):
			var key := base + Vector2i(dx, dy)
			if not _buckets.has(key):
				continue
			for n in _buckets[key]:
				if is_instance_valid(n) and n.global_position.distance_squared_to(pos) <= radius * radius:
					out.append(n)
	return out

func nearest_zombie(pos: Vector2, radius: float) -> Node2D:
	var best: Node2D = null
	var best_d := radius * radius
	for n in near(pos, radius):
		if not (n is Zombie):
			continue
		var d: float = n.global_position.distance_squared_to(pos)
		if d < best_d:
			best_d = d
			best = n
	return best

func nearest_civilian(pos: Vector2, radius: float) -> Node2D:
	var best: Node2D = null
	var best_d := radius * radius
	for n in near(pos, radius):
		if not (n is Civilian):
			continue
		var d: float = n.global_position.distance_squared_to(pos)
		if d < best_d:
			best_d = d
			best = n
	return best

func nearest_unit(pos: Vector2, radius: float) -> Node2D:
	var best: Node2D = null
	var best_d := radius * radius
	for n in near(pos, radius):
		if not (n is MilitaryUnitBase):
			continue
		var d: float = n.global_position.distance_squared_to(pos)
		if d < best_d:
			best_d = d
			best = n
	return best

func count_zombies(pos: Vector2, radius: float) -> int:
	var c := 0
	for n in near(pos, radius):
		if n is Zombie:
			c += 1
	return c
