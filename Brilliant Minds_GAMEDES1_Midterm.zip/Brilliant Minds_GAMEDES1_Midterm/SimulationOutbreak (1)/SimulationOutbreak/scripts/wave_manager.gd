extends Node
class_name WaveManager

signal wave_warning(wave: int, edges: Array, positions: Array, seconds: float)
signal wave_started(wave: int, edges: Array)
signal wave_completed(wave: int, reward: int)
signal intermission_tick(seconds_left: float, wave_next: int)
signal spawn_event(position: Vector2, edge: String)
signal wave_progress(wave: int, alive: int, total: int)

enum State { IDLE, WARNING, SPAWNING, ACTIVE, INTERMISSION, STOPPED }

const EDGES := ["n", "s", "e", "w"]
const PAIRS := [["n", "s"], ["n", "e"], ["n", "w"], ["s", "e"], ["s", "w"], ["e", "w"]]
const TRIPLES := [["n", "s", "e"], ["n", "s", "w"], ["n", "e", "w"], ["s", "e", "w"]]

var state: State = State.IDLE
var wave: int = 0
var active_edges: Array = []
var zombies_total: int = 0
var zombies_spawned: int = 0
var _alive: Dictionary = {}
var _spawn_timer: float = 0.0
var _stall_timer: float = 0.0
var _last_alive_count: int = -1
const STALL_SECONDS := 55.0
var _warning_left: float = 0.0
var _intermission_left: float = 0.0
var _pending_edges: Array = []
var _spawn_points: Array = []
var _started_once := false
var _reward_paid_for: int = -1
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()

func reset() -> void:
	state = State.IDLE
	wave = 0
	active_edges = []
	zombies_total = 0
	zombies_spawned = 0
	_alive.clear()
	_spawn_timer = 0.0
	_warning_left = 0.0
	_intermission_left = 0.0
	_pending_edges = []
	_spawn_points = []
	_started_once = false
	_reward_paid_for = -1

func begin() -> void:
	if _started_once:
		return
	_started_once = true
	state = State.IDLE
	_intermission_left = float(GameConfig.wave_setting("first_wave_delay", 6.0))
	state = State.INTERMISSION
	emit_intermission()

func emit_intermission() -> void:
	intermission_tick.emit(_intermission_left, wave + 1)

func pick_edges(wave_number: int) -> Array:
	var early_until := int(GameConfig.balance.get("edge_rules", {}).get("early_waves_until", 3))
	var mid_until := int(GameConfig.balance.get("edge_rules", {}).get("mid_waves_until", 6))
	if wave_number <= early_until:
		var e: String = EDGES[_rng.randi_range(0, 3)]
		return [e]
	elif wave_number <= mid_until:
		if _rng.randf() < 0.7:
			return [EDGES[_rng.randi_range(0, 3)]]
		var pair: Array = PAIRS[_rng.randi_range(0, PAIRS.size() - 1)]
		return pair.duplicate()
	else:
		var r := _rng.randf()
		if r < 0.2:
			return [EDGES[_rng.randi_range(0, 3)]]
		elif r < 0.8:
			var pair2: Array = PAIRS[_rng.randi_range(0, PAIRS.size() - 1)]
			return pair2.duplicate()
		else:
			var triple: Array = TRIPLES[_rng.randi_range(0, TRIPLES.size() - 1)]
			return triple.duplicate()

func zombie_count_for(wave_number: int) -> int:
	var base := GameConfig.wave_setting("zombie_count_base", 5.0)
	var per := GameConfig.wave_setting("zombie_count_per_wave", 2.0)
	var curve := GameConfig.wave_setting("zombie_count_curve", 0.22)
	var n := base + per * float(wave_number - 1) + curve * pow(float(wave_number - 1), 2.0)
	return maxi(3, int(round(n)))

func zombie_stats_for(wave_number: int) -> Dictionary:
	var w := float(wave_number - 1)
	return {
		"hp": GameConfig.wave_setting("zombie_hp_base", 32.0)
				+ GameConfig.wave_setting("zombie_hp_per_wave", 7.0) * w,
		"damage": minf(GameConfig.wave_setting("zombie_damage_max", 20.0),
				GameConfig.wave_setting("zombie_damage_base", 7.0)
				+ GameConfig.wave_setting("zombie_damage_per_wave", 0.55) * w),
		"speed": minf(GameConfig.wave_setting("zombie_speed_max", 58.0),
				GameConfig.wave_setting("zombie_speed_base", 40.0)
				+ GameConfig.wave_setting("zombie_speed_per_wave", 0.9) * w),
		"attack_interval": GameConfig.wave_setting("zombie_attack_interval", 0.9),
	}

func spawn_interval_for(wave_number: int) -> float:
	var base := GameConfig.wave_setting("spawn_interval_base", 0.85)
	var per := GameConfig.wave_setting("spawn_interval_per_wave", -0.025)
	var mn := GameConfig.wave_setting("spawn_interval_min", 0.18)
	return maxf(mn, base + per * float(wave_number - 1))

func group_size_for(wave_number: int) -> int:
	var g := GameConfig.wave_setting("group_size_base", 2.0) \
			+ GameConfig.wave_setting("group_size_per_wave", 0.18) * float(wave_number - 1)
	return clampi(int(round(g)), 1, 6)

func pick_spawn_for(edge: String) -> Vector2:
	var city: CityMap = GameManager.city
	var points: Array = city.spawns_for_edge(edge)
	if points.is_empty():
		return city.player_start
	var safe_min := 230.0
	var best: Vector2 = points[0]
	var best_score := -1.0
	for p in points:
		var score := _min_threat_distance(p)
		if score >= safe_min:
			if _rng.randf() < 0.5:
				best = p
				best_score = score
				break
			best = p
			best_score = score
		elif score > best_score:
			best = p
			best_score = score
	return best

func _min_threat_distance(p: Vector2) -> float:
	var d := 9999.0
	for u in GameManager.units:
		if u and is_instance_valid(u) and not u.dead:
			d = minf(d, p.distance_to(u.global_position))
	for c in GameManager.civilians:
		if c and is_instance_valid(c) and not c.dead:
			d = minf(d, p.distance_to(c.global_position))
	for s in GameManager.defenses:
		if s and is_instance_valid(s) and not s.dead:
			d = minf(d, p.distance_to(s.global_position))
	return d

func _process(delta: float) -> void:
	if GameManager.simulation_over:
		return
	match state:
		State.INTERMISSION:
			_intermission_left = maxf(0.0, _intermission_left - delta)
			emit_intermission()
			if _intermission_left <= 0.0:
				_launch_wave()
		State.WARNING:
			_warning_left = maxf(0.0, _warning_left - delta)
			if _warning_left <= 0.0:
				_start_spawning()
		State.SPAWNING, State.ACTIVE:
			_spawn_timer -= delta
			if zombies_spawned < zombies_total and _spawn_timer <= 0.0:
				_spawn_timer = spawn_interval_for(wave)
				_spawn_group()
			if zombies_spawned >= zombies_total:
				state = State.ACTIVE
			wave_progress.emit(wave, _alive.size(), zombies_total)
			if zombies_spawned >= zombies_total and _alive.is_empty():
				_complete_wave()
			elif zombies_spawned >= zombies_total:
				_tick_stall(delta)

func _tick_stall(delta: float) -> void:
	if _alive.size() != _last_alive_count:
		_last_alive_count = _alive.size()
		_stall_timer = 0.0
		return
	_stall_timer += delta
	if _stall_timer < STALL_SECONDS:
		return
	_stall_timer = 0.0
	for z in GameManager.zombies:
		if z == null or not is_instance_valid(z) or z.dead:
			continue
		_alive.erase(z.get_instance_id())
		z.withdraw_straggler()
	wave_progress.emit(wave, 0, zombies_total)
	_complete_wave()

func start_next_wave_now() -> bool:
	if state != State.INTERMISSION:
		return false
	if GameManager.simulation_over:
		return false
	_intermission_left = 0.0
	_launch_wave()
	return true

func _launch_wave() -> void:
	if state != State.INTERMISSION:
		return
	wave += 1
	active_edges = pick_edges(wave)
	zombies_total = zombie_count_for(wave)
	zombies_spawned = 0
	_alive.clear()
	_reward_paid_for = -1
	_spawn_points = []
	for e in active_edges:
		_spawn_points.append({"edge": e, "pos": pick_spawn_for(e)})
	_warning_left = GameConfig.wave_setting("spawn_warning_seconds", 3.0)
	state = State.WARNING
	var positions: Array = []
	for sp in _spawn_points:
		positions.append(sp["pos"])
	wave_warning.emit(wave, active_edges.duplicate(), positions,
			GameConfig.wave_setting("spawn_warning_seconds", 3.0))
	Sfx.play("wave_alert", -6.0, 0.0)

func _start_spawning() -> void:
	state = State.SPAWNING
	_spawn_timer = 0.0
	wave_started.emit(wave, active_edges.duplicate())

func _spawn_group() -> void:
	if GameManager.city == null:
		return
	var remaining := zombies_total - zombies_spawned
	var n := mini(group_size_for(wave), remaining)
	var stats := zombie_stats_for(wave)
	for i in n:
		var sp: Dictionary = _spawn_points[i % _spawn_points.size()]
		var base: Vector2 = sp["pos"]
		var scatter := GameConfig.wave_setting("spawn_scatter", 46.0)
		var pos := base + Vector2(_rng.randf_range(-scatter, scatter),
				_rng.randf_range(-scatter, scatter))
		pos = GameManager.city.clamp_to_world(pos)
		var z: Zombie = GameManager.spawn_zombie(pos, wave, stats)
		if z:
			z.wave_id = wave
			var sites: Array = GameManager.city.site_list()
			if not sites.is_empty():
				var target_site: Dictionary = sites[_rng.randi() % sites.size()]
				var ring := Vector2(_rng.randf_range(-74, 74), _rng.randf_range(-74, 74))
				z.set_raid_point(Vector2(float(target_site.get("x", 0.0)),
						float(target_site.get("y", 0.0))) + ring)
			z.killed.connect(_on_zombie_killed)
			_alive[z.get_instance_id()] = true
			zombies_spawned += 1
			spawn_event.emit(pos, String(sp["edge"]))
	wave_progress.emit(wave, _alive.size(), zombies_total)

func _on_zombie_killed(z: Zombie) -> void:
	_stall_timer = 0.0
	_last_alive_count = -1
	if z == null:
		return
	_alive.erase(z.get_instance_id())
	wave_progress.emit(wave, _alive.size(), zombies_total)
	if state in [State.SPAWNING, State.ACTIVE] and zombies_spawned >= zombies_total and _alive.is_empty():
		_complete_wave()

func _complete_wave() -> void:
	if state == State.INTERMISSION or state == State.IDLE or state == State.STOPPED:
		return
	if _reward_paid_for == wave:
		return
	_reward_paid_for = wave
	state = State.INTERMISSION
	var reward: int = GameConfig.wave_reward(wave)
	_intermission_left = float(GameConfig.wave_setting("intermission_seconds", 15.0))
	Sfx.play("wave_complete", -6.0, 0.0)
	wave_completed.emit(wave, reward)
	emit_intermission()

func stop() -> void:
	state = State.STOPPED
	active_edges = []

func seconds_to_next() -> float:
	return _intermission_left if state == State.INTERMISSION else 0.0

func state_name() -> String:
	match state:
		State.IDLE: return "STANDBY"
		State.WARNING: return "INCOMING"
		State.SPAWNING: return "CONTACT"
		State.ACTIVE: return "ENGAGED"
		State.INTERMISSION: return "INTERMISSION"
		_: return "STOPPED"

func alive_count() -> int:
	return _alive.size()
